#include <stdio.h>
int main() {	
	int a = 5;
	int *ptr;
	ptr = &a;
	printf("input a number");
	scanf("%d",ptr);
	printf("%d %d\n", a ,*ptr);
}
