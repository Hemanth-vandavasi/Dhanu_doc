#include <stdio.h>
int main() {
	float (*ptr)(int ,int );
	float add(int , float) , result
