#include<stdio.h>
int main()
{
	int num1 = 9;
	int num2 = 5;
	float div =(float) num1 / num2 ;
	printf(" %f " , div);
}
