#include<stdio.h>
int main()
{
int num;
	for(num= 97 ;num <= 122; num++)\
	printf(" %c ",(char) num);
}

