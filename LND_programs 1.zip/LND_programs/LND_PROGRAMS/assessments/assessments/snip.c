//include<stdio.h> 
int main()
{
	signed char ch1 = 130;
	signed char ch2 = -130;
	printf(" %c %c " , ch1 , ch2 );
}
