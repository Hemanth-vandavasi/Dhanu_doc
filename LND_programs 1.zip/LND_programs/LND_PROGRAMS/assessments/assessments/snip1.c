#include<stdio.h>
int num1 =3; 
/*int num2 ;
int num3 ;
int num4 ;
int num5 ;*/
int arr[5] = { 1 , 2, 3 ,4 ,5};
int main() {
	printf("%d",arr[num1]);
//	printf("%d",num1);
}
