#include<stdio.h>
int main()
{
	FILE *fptr;
	fptr = fopen("NEWFILE.txt","rw");

