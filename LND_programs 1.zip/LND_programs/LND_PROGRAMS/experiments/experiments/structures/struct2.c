#include<stdio.h>
struct student { 
				char name[10];
				int age;
				int rollnum;
				int height;
				};
int main()
{
	struct student std1;
	printf("enter the data name , age , rollnum , height :\n");
	scanf("%s%d%d%d", std1.name , &std1.age , &std1.rollnum , &std1.height );
	
	printf("name is :%s\n" , std1.name);
	printf("age is :%d\n" , std1.age);
	printf("rollno is :%d\n" , std1.rollnum);
	printf("height is :%d\n" , std1.height);
}
/*
struct	student {
				char name[20];
				int age;
				int rollno;
				float height;
			};
int main()
{
	struct student std1 ;
	printf(" enter student name , age , rollno , height :");
	scanf("%s %d %d %e ",std1.name, &std1.age, &std1.rollno,&std1.height);

	printf("name:%s\n", std1.name);
	printf("age:%d\n", std1.age);
	printf("rollno:%d\n", std1.rollno);
	printf("height:%f\n", std1.height);
}
*/
