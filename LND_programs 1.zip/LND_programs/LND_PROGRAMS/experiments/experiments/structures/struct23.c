#include<stdio.h>
struct student {
                                char name[20];
                                int age;
                                int rollnum;
                                float height;
                        };
int main()
{
        struct student std1;
        printf("Enter the details of student : name, age, rollnum, height :\n");
        scanf("%s %d %d %f", std1.name, &std1.age, &std1.rollnum, &std1.height);



       printf("Name of the student is : %s\n", std1.name);
        printf("Age of student is : %d\n", std1.age);
        printf("Rollnum of student is : %d\n", std1.rollnum);
        printf("Height of student is : %.2f\n", std1.height);
}
