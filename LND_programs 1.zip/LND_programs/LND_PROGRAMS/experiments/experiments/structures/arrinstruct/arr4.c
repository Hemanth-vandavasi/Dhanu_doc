#include<stdio.h>
struct employ {
			char name[10];
			int empno;
			struct details {
							int sal;
							int experience;
							} emp;
			} org;
int main() 
{
	printf("Enter the name of the employ ");
	scanf("%s",org.name);	
	printf("enter the empno of employ");
	scanf("%d",&org.empno);
	printf("Enter the salary of employ");
	scanf("%d",&org.emp.sal);
	printf("Enter the years of experience");
	scanf("%d",&org.emp.experience);
	printf("%s %d %d %d",org.name,org.empno,org.emp.sal,org.emp.experience);
}
	
