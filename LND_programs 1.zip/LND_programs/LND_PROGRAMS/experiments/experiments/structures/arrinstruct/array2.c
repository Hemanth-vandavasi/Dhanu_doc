#include<stdio.h>
struct student {
				char name[20];
				int rollnum;
				int submarks[4];
				};
int main()
{
	int row ;
	int col ;
	struct student stuarr[3];
	for(row=0 ; row<3 ; row++) {
		printf("Enter data for students %d\n" , row+1);
		printf("enter name : ");
		scanf("%s" , stuarr[row].name);
		printf("enter roll number :");
		scanf("%d", &stuarr[row].rollnum);
		for(col = 0 ; col < 4 ;col++) {
			printf("enter marks for subject %d :", col+1);
			scanf("%d",&stuarr[row].submarks[col]);
		} 
	}
	for(row = 0; row < 3 ;row++) {
		printf("Data of student %d\n",row+1);
		printf("Name : %s , rollnum : %d\nmarks : ",stuarr[row].name , stuarr[	row].rollnum);
		for(col = 0 ; col < 4 ; col++)
			printf("%d ",stuarr[row].submarks[col]);
		printf("\n");
	}
}
