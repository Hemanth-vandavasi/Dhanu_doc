#include<stdio.h>
struct cricketer {
		char name[20];
		float strike_rate;
		int Highscore;
		int centuries;
		};
int main()
{
	int i;
	int j;
	struct cricketer cricarr[5];
	for(i = 0; i < 1; i++) {
//		printf("Enter the name of the cricketer :");
		printf("Enter the name of the player %d:",i+1);
		scanf("%s" , cricarr[i].name);
		printf("Enter the sk_rate of the player:\n");
		scanf("%f" , &cricarr[i].strike_rate);
		printf("Enter the highest score of the player:\n");
		scanf("%d" , &cricarr[i].Highscore);
//		for(j = 0; j < 4; j++) {
			printf("Enter the 100 of the player");
			scanf("%d" , &cricarr[i].centuries);
	//		}
 	}
	printf("Score card of INDIA VS ENGLAND T20 SEMI FINAL \n ");
	printf("Player    SR        HS    100/S \n");
	for(i = 0; i < 1; i++) {
	//	printf("Displays the data of cricketer :");
		printf("%s    %.2f    %d    %d\n",cricarr[i].name , cricarr[i].strike_rate ,cricarr[i].Highscore, cricarr[i].centuries);
//		for(j = 0; j < 4; j++) {
//			printf("%d\n" , cricarr[i].scores[j]);
//		printf("\n");
//		}
	}
}

