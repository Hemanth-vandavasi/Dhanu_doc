#include<stdio.h>
struct student {
				char name[20];
				int rollnum;
				int age;
			   };
int main()
{
	int i;
	struct student std1arr[5];
	printf("enter name  , rollnum and marks:");
	for(i = 0 ; i < 5; i++) {
		scanf("%s %d %d ",std1arr[i].name, &std1arr[i].rollnum ,&std1arr[i].age);
	}
	for(i = 0 ; i < 5; i++) {
		printf("%s %d %d ",std1arr[i].name , std1arr[i].rollnum ,std1arr[i].age);
	}
}

