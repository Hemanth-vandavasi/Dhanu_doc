#include<stdio.h>
struct student {
		char name[20];
		int rollnum;
		int rank;
		}stud1;
int main()
{
//	struct student *ptr;
	printf("Enter the name of student:");
	scanf("%s",stud1.name);
	printf("Enter the rollnum of student:");
	scanf("%d",&stud1.rollnum);
	printf("Enter the rank of the student:");
	scanf("%d", &stud1.rank);
	struct student *ptr = &stud1 ;
//	*ptr = &stud1 ;
	printf("%s %d %d",ptr->name , ptr->rollnum , ptr->rank);
}

	
