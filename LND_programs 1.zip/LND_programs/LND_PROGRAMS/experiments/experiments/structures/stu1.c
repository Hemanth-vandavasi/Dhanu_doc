#include<stdio.h>
struct student {
					char name[20];
					int rollnum;
					float marks;
				};
int main()
{
	struct  student stu1 = {"Hemanth" , 123 , 98 };
	struct student stu2;
	stu2=stu1;
	printf("stu1 : %s %d %.2f\n",stu1.name ,stu1.rollnum,stu1.marks);
	printf("stu2 : %s %d %.2f\n",stu2.name ,stu2.rollnum,stu2.marks);
	printf("address of name = %u\n" ,stu1.name);
	printf("address of rollnum = %u\n",&stu1.rollnum);
	printf("address of marks = %u\n",&stu1.marks);
	printf("the size is %d" ,sizeof(stu1));
	printf("the size is %d" ,sizeof(stu2));
}

