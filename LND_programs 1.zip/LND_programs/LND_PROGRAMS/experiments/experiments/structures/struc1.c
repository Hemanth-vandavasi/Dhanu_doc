#include<stdio.h>
#include<string.h>
#if 0
struct student {
	int age;
	int rollno;
	int height;
} student1 = { .age = 22 ,.rollno = 1354 , .height = 155 };
int main()
{ 
	printf("The age of the student is :%d \n ",student1.age);
	printf("The rollno of student is :%d \n ",student1.rollno);
	printf("The height of the student is :%d \n ",student1.height);
//	printf(" %d %d " ,student1.rollno,student1.height);
	return 0;
}
#endif
#if 0
struct	student {
	char name[20];
	int age;
	int rollno;
	float height;
};
int main()
{ 
	struct student std1; 
/*	{
	printf("Enter the name of the student:");
	scanf("%s " , std1.name); 
	}
	{
	printf("Enter the age of the student:");
	scanf("%d " , &std1.age);
	}
	{
	printf("Enter the rollno of the student:");
	scanf("%d " , &std1.rollno);
	}
	{
	printf("Enter the height of the student:");
//	scanf("%c " , &std1.name);
//	scanf("%d " , &std1.age);
//	scanf("%d " , &std1.rollno);
	scanf("%d " , &std1.height);
	} {
	printf("The name of the student is :%s \n ", std1.name);
	printf("The age of student is :%d \n ", std1.age);
	printf("The rollno of the student is :%d \n ", std1.rollno);
	printf("The height of the student is : %d \n ", std1.height);
	}
	return 0;
}
*/
	printf(" enter student name , age , rollno , height :");
	scanf("%s " , std1.name);
	scanf("%d " , &std1.age);
	scanf("%d " , &std1.rollno);
	scanf("%d " , &std1.height);

//	scanf("%s",std1.name);
//	scanf(" %d %d %f ", &std1.age , &std1.rollno ,&std1.height);
	printf("The name of the student is :%s\n", std1.name);
	printf("The age of student is :%d\n", std1.age);
	printf("The rollno of the student is :%d\n", std1.rollno);
	printf("The height of the student is : %f\n", std1.height);
	return 0;
}
#endif
#if 1
struct	student {
	char name[20];
	int age;
	int rollno;
	float height;
	};
int main()
{
	struct student std1 ;
	printf(" enter student name , age , rollno , height :");
	scanf("%s %d %d %d ",std1.name, &std1.age , &std1.rollno ,&std1.height);
	printf("The name of the student is :%s\n", std1.name);
	printf("The age of student is :%d\n", std1.age);
	printf("The rollno of the student is :%d\n", std1.rollno);
	printf("The height of the student is : %f\n", std1.height);
	return 0;
}
#endif
	
  


