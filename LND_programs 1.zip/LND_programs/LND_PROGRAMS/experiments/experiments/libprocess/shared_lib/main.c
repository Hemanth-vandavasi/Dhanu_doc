#include "cal.h"
int main() {
	printf("Addition is : %d\n" , add(23 , 12));
	printf("Subtraction is : %d\n" , sub(23 , 12));
}
