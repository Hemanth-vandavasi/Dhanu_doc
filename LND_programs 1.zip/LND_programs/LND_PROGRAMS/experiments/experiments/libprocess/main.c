//#include<stdio.h>
#include "cal.h"
int main() {
	printf("Addition is : %d\n", add(23 , 11));
	printf("Subtraction is : %d\n", sub(23 , 11));
	return 0;
}
