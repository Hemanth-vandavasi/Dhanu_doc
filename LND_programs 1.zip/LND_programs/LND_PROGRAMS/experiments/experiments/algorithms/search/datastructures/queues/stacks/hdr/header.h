#include<stdio.h>
#include<stdlib.h>
# define SIZE 100
void enqueue();
void dequeue();
void show();
//int inp_arr[SIZE];
//int Rear = - 1;
//int Front = - 1;
