#include<stdio.h>
#include<stdlib.h>
#define SIZE 100
//int Top=-1,
inp_array[SIZE];
void Push();
void Pop();
void show();
