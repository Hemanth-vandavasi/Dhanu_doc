#include<stdio.h>
int b;
int main() {
	int a;
		printf("%d\n",a);
		printf("%d\n",b);
	{
		printf("%d\n", a);
		printf("%d\n", b);
	}
		printf("%d\n",a);
	
}
