#include<stdio.h>
int hello(void);
int main() {
	hello();
}

