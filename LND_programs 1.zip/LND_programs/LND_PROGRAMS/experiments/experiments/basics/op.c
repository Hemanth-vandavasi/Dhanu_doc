#include<stdio.h>
int arr[5] = {1 , 2, 3 , 4, 5};
int main() {
	printf("%d",arr[1]);
}
