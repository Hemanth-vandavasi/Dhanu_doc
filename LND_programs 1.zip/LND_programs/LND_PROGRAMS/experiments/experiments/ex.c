#include <stdio.h>
struct  stu {
	int a;
	int b;
	int c;
	int d;	
	int e;
};
struct stu fun();
int main() {
	struct stu s;
	s = fun();
	printf("%d\n", s.a);
	printf("%d\n", s.b);
	printf("%d\n", s.c);
	printf("%d\n", s.d);
	printf("%d\n", s.e);
}
struct stu fun() {
	struct stu s2;
	s2.a = 10;
	s2.b = 21;
	s2.c = 43;
	s2.d = 40;
	s2.e = 87;

	return s2;
}
