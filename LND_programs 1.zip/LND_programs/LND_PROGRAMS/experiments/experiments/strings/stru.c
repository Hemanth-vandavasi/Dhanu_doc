#include<stdio.h>
str
