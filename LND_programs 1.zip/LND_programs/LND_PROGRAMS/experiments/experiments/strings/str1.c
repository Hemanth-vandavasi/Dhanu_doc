#include<stdio.h>
#include<string.h>
int main() {
	 char *str = "HelloHemanth";
	 char str1 = " ";
	 int pos
