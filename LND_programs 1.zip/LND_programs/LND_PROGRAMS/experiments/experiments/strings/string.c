#include<stdio.h>
#if 0
int main()
{
	char A ;
	printf("enter the string");
	scanf("%s " ,&A);
	printf("%s" , A);
}
#endif
#if 1
int main()
{ 
//	int i;
//	int arr[100] = {[0 ... 20]=1 , [21 ... 30]=2 ,[31 ... 50]=3 ,[51 ... 70]=4 ,[71 ... 80]=4 ,[81 ... 99]=5 };
	int arr[100] = { [0 ... 99] = 100};	
	for(int i = 0 ; i < 100 ; i++) {
//	scanf("%d" , &arr1[i]);
//	for(int i = 0; i< 5 ;i++)
		 printf("%d ",arr[i]);
//	for(int i = 99; i =>  0 ; i--) 
//		printf("%d = %d " , i , arr[i]);
	}
	return 0;
}
#endif
#if 0
struct exp {
	int a;
	int b;
	int c;
	int d;
	int e;

} exp1 ={ .a=4 ,.b=7 };

int main()
{
	printf("%d %d %d %d %d " ,exp1.a ,exp1.b,exp1.c,exp1.d,exp1.e);
}
#endif

