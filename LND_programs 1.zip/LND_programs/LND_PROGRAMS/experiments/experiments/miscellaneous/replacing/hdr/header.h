#include<stdio.h>
#include<string.h>
void replace(char str[],int size)
