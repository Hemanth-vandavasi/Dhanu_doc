#include"header.h"
{
	for (int i=0;i<size;i++) {
		if (str[i]=='a')
		{
			str[i]='k';	
		}
	}
}
