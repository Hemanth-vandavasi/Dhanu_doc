int main()
{
	char str[] = "Hemanth am from ap";
	int size = strlen(str);
	replace(str,size);
	printf("%s \n",str);
	return 0;
}
