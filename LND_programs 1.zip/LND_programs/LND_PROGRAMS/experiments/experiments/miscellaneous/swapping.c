#include <stdio.h>
void swap(int *,int*);
int main()
{
	int num1;
	int num2;
	printf("Swap two numbers using functions :\n");
	printf("Enter the first number :\n");
	scanf("%d" , &num1);
	printf("Enter the second number :\n");
	scanf("%d" , &num2);
	printf("Before swapping : num1 = %d, num2 = %d ", num1 , num2);
	swap(&num1 , &num2);
	printf("\n After swapping : num1 = %d , num2 = %d \n\n" , num1 , num2);
	return 0;
}
void swap(int *ptr,int *ptr1)
{
	*ptr = *ptr + *ptr1;
	*ptr1 = *ptr - *ptr1;
	*ptr = *ptr - *ptr1;
}


