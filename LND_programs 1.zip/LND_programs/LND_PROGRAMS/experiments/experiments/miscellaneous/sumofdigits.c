/*write a program to caluculate the sum of the digit */
#include <stdio.h>
int sumOfDigits(int num)
{
	if (num == 0)
	return 0;
	return (num % 10 + sumOfDigits(num));
	}
	int main()
	{
	int num = 123;
	printf("Sum of the Number is %d \n", sumOfDigits(num));
	}
