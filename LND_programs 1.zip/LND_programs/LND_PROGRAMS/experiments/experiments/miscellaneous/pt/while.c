#include<stdio.h>
#if 1
INT main()
{
	int j;
	while( j <= 10) {
	printf(" \n %d " , j);
	j = j + 1;
	}	
}
#endif 
#if 0
int main()
{
	int i = 1;
	while( i <= 10) {
	printf(" \n %d ", i);
	i++ ;
	}
}
int main()
{
	int x = 1 ;
	while( x == 1) {
	x = x-1;
	printf(" \n %d ",x);
	}
}
#endif
#if 0
int main()
{
	char x;
	for(x=0; x <= 255 ; x++)
	printf(" %d " , x);
	printf(" %c " , x);
	}
#endif
