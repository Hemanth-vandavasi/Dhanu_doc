#include<stdio.h>
int main()
{
	int a = 10;
	int *p = &a ;
//	int *q ;
//	q = p ;
//	*q = 5;
	printf("%d " ,p);
}

