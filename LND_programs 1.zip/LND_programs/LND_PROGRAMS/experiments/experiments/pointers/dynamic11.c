#include<stdio.h>
#include<string.h>
#define SIZE 100
int main()
{
	

