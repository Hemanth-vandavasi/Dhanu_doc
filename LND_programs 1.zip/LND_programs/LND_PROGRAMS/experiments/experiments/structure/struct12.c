#include<stdio.h>
struct  student{
char name ;
int rollno;
float marks;
};
int main()
{
//sizeof(struct student);
printf("%d ",sizeof( struct student));
} ;
