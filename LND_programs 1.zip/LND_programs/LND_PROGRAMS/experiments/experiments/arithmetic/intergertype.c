:wq
	
