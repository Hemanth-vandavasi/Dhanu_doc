#include<stdio.h>
int main()
{
	int arr[10];
	int i;
	int sum =0;
	for(i=0 ; i<=4 ; i++) {
	printf("enter the numbers arr:,");
		scanf("%d" ,&arr[i]);
	}
	for(i=0; i <= 4 ; i++) {
		printf("the array elements are :%d \n" ,arr[i]);
	}
	for(i = 0; i <= 4 ; i++) { 
		sum = sum + arr[i];
		printf("the array elements are: %d\n ",sum);
	}
	return 0;	
}
hellloooo
hgejdhbhckj
