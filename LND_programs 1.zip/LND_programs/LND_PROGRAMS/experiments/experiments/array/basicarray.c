#include<stdio.h>
int main()
{
	int arr[10]={ 34,22,21,44,89,3,1,4};
	int i;
	for(int i=0 ; i<=10 ;i++)
		printf("%d" , arr[i]);
	return 0;
}

