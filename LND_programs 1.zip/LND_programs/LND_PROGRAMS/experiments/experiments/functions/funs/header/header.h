#include<stdio.h>
void fun1();
void fun3();
void fun4();
