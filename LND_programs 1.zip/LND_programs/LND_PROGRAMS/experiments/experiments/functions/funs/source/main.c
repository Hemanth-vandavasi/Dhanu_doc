#include "header.h"
int a = 10;
void main()
{
	fun1();
	fun3();
	fun4();
}

