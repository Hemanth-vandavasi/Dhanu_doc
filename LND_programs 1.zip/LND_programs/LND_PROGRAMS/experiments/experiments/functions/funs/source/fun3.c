#include "header.h"
extern int a;
static int b = 15;
void fun3()
{
	printf("%d %d " , a , b);
}

