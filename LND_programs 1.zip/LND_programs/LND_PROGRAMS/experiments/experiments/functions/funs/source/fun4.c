#include "header.h"
extern int a;
static int c = 25;
void fun4()
{
	printf("%d %d " , a , c);
} 
void fun5()
{
	printf("%d %d " , a , c);
}

