#include <stdio.h>
int main() {
	printf("%ld", 0x55);
}
