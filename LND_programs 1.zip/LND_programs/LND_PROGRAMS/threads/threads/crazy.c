#include <stdio.h>


int main() {	
		int date;
		int day;
		int year;
	:wq

