#include"header.h"
int main()
{
	int num1;
	printf("enter the number:");
	scanf("%d", &num1);
	int num2;
	printf("enter the number:");
	scanf("%d", &num2);
	fun1(num1 , num2);
	fun2(num1 , num2);
	return 0;
}
