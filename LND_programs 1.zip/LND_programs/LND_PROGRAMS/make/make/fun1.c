#include"header.h"
int fun1(int num1 , int num2 )
{
	int num3 = num1 + num2;
	printf("%d",num3);
}
