// Pgm to print duplicate character in the string
#include <stdio.h>
#include <string.h>

//Function declaration
void findDuplicateChar(char str[]);

// main function
int main()
{
	char str[50];
	printf("Enter the string: ");
	fgets(str, sizeof(str), stdin);
	findDuplicateChar(str);
	return 0;
}

//Function Defination
void findDuplicateChar(char str[])
{
	int len = strlen(str);
	int count[len];
	int i;
	int j;
	for (i = 0; i < len; i++) {
		count[i] = 0;
		for (j = 0; j < len; j++) {
			if(str[i] == str[j]) {
				count[i] ++;
			}
		}
		if (count[i] > 1) {
			printf("%c is duplicate char.\n", str[i]);
		}
	}
	
}

