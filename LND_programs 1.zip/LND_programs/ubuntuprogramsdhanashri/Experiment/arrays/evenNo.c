// pgm to find the even nos.

#include <stdio.h>
#if 1
int main()

{
	int arr[10];
	int i;
	printf("Enter any 10 array elements: ");
	for (i = 0; i < 10; i++)
	scanf("%d", &arr[i]);
	printf("\nEven array elements are:\n");
	for (i = 0; i < 10; i++) {
		if (arr[i] % 2 == 0) {
			printf("%d", arr[i]);
		}
	}
	return 0;
}
#endif
#if 0
int main()
{
    int arr[10];
	int i;
	printf("Enter any 10 array elements: ");
	for(i = 0; i < 10; i++)
	scanf("%d", &arr[i]);
	printf("\neven Array elements are:\n");
	for(i=0; i<10; i++) {
		 if(arr[i]%2==0) {
			printf("%d ", arr[i]);
		}
	}
	return 0;
}
#endif
