#include <stdio.h>
// Function declaration

int reverse(int arr[], int n);
void printArr(int arr[], int n);

// Main function
int main()
{
	int arr[6];
	int i;
	int n;
	printf("Enter the elements in array: ");
	for (i = 0;i < 6; i++) {
		scanf("%d", &arr[i]);
	}
	reverse(arr, 6);
	printArr(arr, 6);
	return 0;
}

// Function Defination
void printArr(int arr[], int n)
{
	for (int i = 0; i < n; i++) {
		printf("%d\t", arr[i]);
	}
} 

int reverse(int arr[], int n)
{
	for(int i = 0; i < n/2; i++) {
		int firstVal = arr[i];
		int secondVal = arr[n - i - 1];
		arr[i] = secondVal;
		arr[n - i - 1] = firstVal;
	}
}

