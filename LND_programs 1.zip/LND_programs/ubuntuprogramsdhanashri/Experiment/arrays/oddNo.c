#include <stdio.h>
#if 0
//Function Declaration
int countOdd(int arr[], int n);
//Main function
int main()
{
	int arr[] = {1,2,3,4,5,6};
	printf("%d", countOdd(arr, 6));
    int countOdd(count);
	return 0;
}

//Function defination
int countOdd(int arr[], int n)
{
	float price[10];
	for (int i = 0; i < n; i++) {
		if(arr[i] % 2 != 0) {
	//		count++;
			printf("%d\n",arr[i]);
		}
		}
	//	printf("the count is:%d",);
	
	return countOdd;
}
#endif

#if 0
int countOdd(int arr[], int n);
int main() 
{
	int arr[6] = {1,2,3,4,5,6};
	printf("%d", countOdd (arr,6));
	return 0;
}
int countOdd(int arr[], int n)
{
	int count = 0;
	for (int i = 0; i < n; i++) {
		if (arr[i] % 2 != 0) {
		printf("%d", arr[6]);
			count++;
		}
	}
	return count;
}

#endif

#if 1
int main()
{
	int arr[10], i;
	printf("Enter any 10 array elements: ");
	for(i=0; i<10; i++)
	scanf("%d", &arr[i]);
	printf("\nOdd Array elements are:\n");
	for(i=0; i<10; i++) {
	if(arr[i]%2!=0) {
	printf("%d ", arr[i]);
	 }
  }
  	return 0;
}
#endif
