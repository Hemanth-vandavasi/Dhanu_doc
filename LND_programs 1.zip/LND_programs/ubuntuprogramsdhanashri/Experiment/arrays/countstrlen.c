#include <stdio.h>
#include <string.h>
int length(char *str);

int main() 
{
	char str[20];
	int count1 = 0;
	printf("Enter the string:");
	fgets(str, 20, stdin);
	count1 = length(str);
	printf("length: %d\n",count1);
	return 0;
}
int length(char *str)
{
	int i;
	int count = 0;

	for (i = 0; i < 20; i++) {
		if (*str != '\n') {
			str++;
			count++;
		}
	}
	return count;
}
