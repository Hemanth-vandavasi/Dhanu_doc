#include <stdio.h>
#if 0
int main()
{
	float num1 = 2.1;
	float num2 = 1.1;
	printf("addition:%f", num1 + num2);
	return 0;
}
#endif

#if 0
int main()
{
	float num1 = 2.1;
	float num2 = 1.1;
	printf("substraction:%f", num1 - num2);
	return 0;
}
#endif

#if 0
int main()
{
	float num1 = 2.1;
	float num2 = 1.1;
	printf("multiplication:%f", num1 * num2);
	return 0;
}
#endif

#if 0
int main()
{
	float num1 = 2.1;
	float num2 = 1.1;
	printf("division:%f", num1 / num2);
	return 0;
}
#endif

#if 1
int main()
{
	float num1 = 2.1;
	float num2 = 1.2;
	printf("modulus:%f", num1%num2);
	return 0;
}
#endif
