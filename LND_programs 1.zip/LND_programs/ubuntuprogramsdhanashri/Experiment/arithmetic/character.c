#include <stdio.h>
#if 0
int main()
{
	int num1 = 7;
	int num2 = 5;
	printf("addition:%d ", num1 + num2);
	return 0;
}
#endif

#if 0
int main()
{
	int num1 = 7;
	int num2 = 5;
	printf("substraction:%d", num1 - num2);
	return 0;
}
#endif

#if 0
int main()
{
    int num1 = 7;
	int num2 = 5;
	printf("multiplication:%d", num1 * num2);
	return 0;
}
#endif

#if 0
int main()
{
	int num1 = 7;
	int num2 = 5;
	printf("division:%d", num1 / num2);
	return 0;
}
#endif

#if 1
int main()
{
	int num1 = 7;
	int num2 = 5;
	printf("modulus:%d", num1 % num2);
	return 0;
}
#endif
