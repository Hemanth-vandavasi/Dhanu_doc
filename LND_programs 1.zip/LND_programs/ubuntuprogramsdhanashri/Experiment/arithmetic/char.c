#include <stdio.h>
#if 1
int main()
{
	char num1 = '!';
	char num2 = '"';
	printf("addition:%d", num1 + num2);
	return 0;
}
#endif

#if 0
int main()
{
	char num1 = 'a';
	char num2 = 'b';
	printf("substration:%c", num1 - num2);
	return 0;
}
#endif

#if 0
int main()
{
	char num1 = 'a';
	char num2 = 'b';
	printf("multiplication:%c", num1 * num2);
	return 0;
}
#endif

#if 0
int main()
{
	char num1 = 'a';
	char num2 = 'b';
	printf("division:%c", num1 / num2);
	return 0;
}
#endif
