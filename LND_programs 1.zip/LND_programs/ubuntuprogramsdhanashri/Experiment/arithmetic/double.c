#include <stdio.h>
#if 0
int main()
{
	double num1 = 3;
	double num2 = 4;
	printf("addition:%lf", num1 + num2);
	return 0;
}
#endif

#if 0
int main()
{
	double num1 = 3;
	double num2 = 4;
	printf("substract:%lf", num1 - num2);
	return 0;
}
#endif

#if 0
int main()
{
	double num1 = 3;
	double num2 = 4;
	printf("multiply:%lf", num1 * num2);
	return 0;
}
#endif

#if 0
int main()
{
	double num1 = 3;
	double num2 = 4;
	printf("division:%lf", num1 / num2);
	return 0;
}
#endif

#if 1
int main()
{
	double num1 = 3;
	double num2 = 4;
	printf("modulus:%lf", num1 % num2);
	return 0;
}
#endif
