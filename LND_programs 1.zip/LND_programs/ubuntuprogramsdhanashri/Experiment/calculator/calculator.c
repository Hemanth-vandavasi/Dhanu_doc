#include <stdio.h>
#define SIZE 10
// Function declarations for calculator
int add(int num1, int num2);
int sub(int num1, int num2);
int mult(int num1, int num2);
int div(int num1, int num2);

int main()
{
	char op;
	char snumber1[SIZE];
	int num1;
	int num2;
	int result = 0;
//	fgets(snumber1,SIZE,stdin);

	 // Print welcome message 
	printf("WELCOME TO SIMPLE CALCULATOR\n");
	printf("----------------------------\n");	
	printf("Enter [number 1] [+ - * / !] [number 2]\n");
	scanf("%d %c %d", &num1, &op, &num2);
//	fgets(snumber1,SIZE,stdin);

	 // Input two number and operator from user

	switch(op) {
	    case '+':
			result = add(num1, num2);
			break;
		case '-':
			result = sub(num1, num2);
			break;
		case '*':
			result = mult(num1, num2);
			break;
		case '/':
			result = div(num1, num2);
			break;
	    case '!':
			Exit;
			break;
	    default:
			printf("Invalid input");
			break;
	}
	   // Print the result 
	 printf("%d %d %d = %d", num1, op, num2, result);
	 return 0;
}

//Function to add two numbers
int add(int num1, int num2)
{
    return num1 + num2;
}
//Function to subtract two numbers
int sub(int num1, int num2)
{
    return num1 - num2;
}
// Function to multiply two numbers

int mult(int num1, int num2)
{
    return num1 * num2;
}
//Function to divide two numbers

int div(int num1, int num2)
{
    return num1 / num2;
}
