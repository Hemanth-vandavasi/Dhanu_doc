#include <stdio.h>
#include <stdlib.h>

int main()
{
	char input[100];
	printf("Enter an expression: ");
	fgets(input, sizeof(input), stdin);
	printf("%s", input);
	return 0;
}
