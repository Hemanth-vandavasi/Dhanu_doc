#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <mqueue.h>
#define SIZE 50

int main() {
	mqd_t client;
	
	if((client = mq_open("/server_queue", O_RDONLY | O_CREAT, 0660, 0)) < 0) {
		printf("Error in opening queue\n");
		exit(1);
	}
	char buf[SIZE] = {0};
	if((mq_receive(client, buf, SIZE, 0)) < 0) {
		printf("Error in receiving\n");
		exit(1);
	}
	if((mq_close(client)) < 0) {
		printf("Error in closing\n");
		exit(1);
	}
/*	if((mq_unlink("/server_queue")) < 0) {
		printf("Error in unlink");
		exit(1);
	}*/  
	printf("%s", buf);
	printf("Message received\n");
	exit(0);
	if((mq_unlink("/server_queue")) < 0) {
		printf("Error in unlink");
		exit(1);
	}  
}
