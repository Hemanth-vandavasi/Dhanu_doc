#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <mqueue.h>
#define SIZE 50

int main() {
	mqd_t server;
	struct mq_attr attr;
	attr.mq_flags = 0;
	attr.mq_maxmsg = 10;
	attr.mq_msgsize = SIZE;
	attr.mq_curmsgs = 0;
	
	if((server = mq_open("/server_queue", O_WRONLY | O_CREAT, 0660, &attr)) < 0) {
		printf("Error in opening queue\n");
		exit(1);
	}
	char buf[SIZE];
	printf("The message for receiver :\n");
	fgets(buf, SIZE, stdin);
	if((mq_send(server, buf, strlen(buf), 0)) < 0) {
		printf("Error in sending\n");
		exit(1);
	}
	printf("Server : msg to client\n");
}
