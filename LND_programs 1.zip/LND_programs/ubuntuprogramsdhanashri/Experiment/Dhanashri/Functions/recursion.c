#include <stdio.h>
#if Q == 1
int fact(int n);
int main() {
	int num;
	printf("Enter a no. :");
	scanf("%d",&num);
	printf("Factorial of %d is %d\n", num, fact(num));
}
int fact(int n) {
	if (n == 0)
		return(1);
	else
		return(n * fact(n - 1));
}
#endif

#if Q == 2
long fibo(int n);
int main() {
	int num;
	printf("Enter a no. :");
	scanf("%d", &num);
	for (int i = 1 ; i <= num ; i++ ) {
      printf("%ld\n", fibo(i));
      //i++; 
    }
//	printf("Fibonessis of %d is %ld\n", num, fibo(num));
}
long fibo(int n) {
	if ( n == 0 )
		return 0;
	else if ( n == 1 )
      	return 1;
   	else
      return ( fibo(n-1) + fibo(n-2) );
}
#endif


