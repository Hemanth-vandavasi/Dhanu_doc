#include <stdio.h>
#if Q == 1
int Reverse(int arr[]);
int main() {
	int arr[10];
	int i;
	for(i = 0; i < 10; i++) {
		printf("Enter the elements :");
		scanf("%d", &arr[i]);
	}
	Reverse(arr);
	
}
int Reverse(int arr[]) {
	int i;
	for(i = 9; i >= 0; i--) {
		printf("Reverse is :%d\n", arr[i]);
	}
}
#endif

#if Q == 2
int Reverse(char arr[]);
int main() {
	char arr[5];
	int i;
//	printf("Enter the characters :\n");
	for(i = 0; i < 5 ; i++) {
		printf("Enter the characters:");
		scanf("%s", &arr[i]);
	}
//	printf("\n");
	Reverse(arr);
}
int Reverse(char arr[]) {
	int i;
	for(i = 4; i >= 0; i--) {
		printf("Reverse is :%c\n", arr[i]);
	}
}
#endif

