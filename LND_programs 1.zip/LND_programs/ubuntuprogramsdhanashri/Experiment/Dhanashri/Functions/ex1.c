#include <stdio.h>
#include <string.h>
int Monkey(char* name  , int  age );
int main() {
	char name[10];
	int age;
	printf("Enter a name :");
	scanf("%s", name);
	printf("Enter age :");
	scanf("%d", &age);
	Monkey(name, age);
	printf("Enter a name2 :");
	scanf("%s", name);
	printf("Enter age :");
	scanf("%d", &age);
//	Monkey(name , age);
	Monkey(name , age);
	return 0;
}
int Monkey(char* name, int age ) {
	printf("%s\n", name);
	printf("%d\n", age);
}
