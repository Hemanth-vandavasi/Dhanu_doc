#include <stdio.h>
int a;
char c = 'a';
char d;
char f;
char h;
char g;
char t;
char r;
char z;
int m;
int main() {
//	int m;
	int m = 12;
	return 0;
}
