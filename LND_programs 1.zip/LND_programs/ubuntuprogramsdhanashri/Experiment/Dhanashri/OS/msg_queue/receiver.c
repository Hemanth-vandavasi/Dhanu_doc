#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <mqueue.h>
#define SIZE 256
int main() {
	char buf[SIZE];
	mqd_t receiver;
	
	if((receiver = mq_open("/hi", O_RDONLY | O_CREAT, 0660, NULL)) == -1) {
		printf("Queue is not created");
		exit(1);
	}
	
	if((mq_receive(receiver, buf, SIZE, 0)) == -1) {
		printf("Not receiving");
		exit(1);
	}
	if((mq_close(receiver)) == -1) {
		printf("Error in closing");
		exit(1);
	}
	printf("%s", buf);
	printf("Message received\n");
	exit(0);
	if((mq_unlink("/hi")) == -1) {
		printf("Error in unlink");
		exit(1);
	}
}
