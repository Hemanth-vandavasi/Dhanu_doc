#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <mqueue.h>
#define SIZE 256
int main() {
	char buf[SIZE];
	mqd_t sender;
	struct mq_attr attr;
	attr.mq_flags = 0;
	attr.mq_maxmsg = 10;
	attr.mq_msgsize = 256;
	attr.mq_curmsgs = 0;
	
	if((sender = mq_open("/hi", O_CREAT | O_WRONLY, 0660, &attr)) == -1) {
		printf("Queue is not created");
		exit(1);
	}
	printf("Enter the message :");
	fgets(buf, SIZE, stdin);
	
	if((mq_send(sender, buf, strlen(buf), 0)) == -1) {
		printf("Not sending");
		exit(1);
	}
	printf("Message to receiver");
	if((mq_close(sender)) == -1) {
		printf("error in closing");
		exit(1);	
	}
}
