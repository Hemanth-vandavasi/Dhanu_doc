#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#define SIZE 20

int main() {
	int fd[2];
	pid_t child;
	int	i = pipe(fd);
	char buf[SIZE];
	printf("Enter the message :");
	fgets(buf, SIZE, stdin);
	if(i == -1) {
		printf("pipe is not created");
		exit(1);
	}
	child = fork();
	if(child == 0) {
		close(fd[1]);
		read(fd[0], buf, strlen(buf));
		printf("%s", buf);
	} else {
		close(fd[0]);
		write(fd[1], buf, SIZE);
	}
	return 0;
}
