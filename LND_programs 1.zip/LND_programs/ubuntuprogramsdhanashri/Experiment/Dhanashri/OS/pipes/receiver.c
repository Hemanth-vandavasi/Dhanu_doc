#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#define SIZE 20

int main() {
	char buf[SIZE];
	int fd1 = open("fifo", O_RDONLY, 0660);
	read(fd1, buf, SIZE);
	printf("%s", buf);
//	fgets(buf, SIZE, stdin);
 //	write(fd1, buf, SIZE);
	close(fd1);
}
