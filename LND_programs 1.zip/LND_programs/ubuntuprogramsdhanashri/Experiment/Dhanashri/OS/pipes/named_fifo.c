#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#define SIZE 20

int main() {
	char buf[SIZE];
	int fd = mkfifo("fifo", 0660);
	int fd1 = open("fifo", O_WRONLY, 0660);
	printf("Enter the message :");
	fgets(buf, SIZE, stdin);
 	write(fd1, buf, SIZE);
	close(fd1);
}
