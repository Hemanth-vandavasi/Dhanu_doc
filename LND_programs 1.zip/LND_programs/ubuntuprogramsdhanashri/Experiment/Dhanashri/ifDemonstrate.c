#include <stdio.h>
#if QUES == 1
int main() {
	int num;
	printf("Enter the number :");
	scanf("%d\n", &num);
	if (num <= 10) 
		printf("What an obedient servant you are !\n");
}
#endif

#if QUES == 2
int main() {
	int dis = 0;
	int qty;
	float rate;
	float tot;

	printf("Enter the Quantity and Rate :");
	scanf("%d %f", &qty, &rate);
	if (qty >= 1000) 
		dis = 10;
	tot = (qty * rate) - (qty * rate * dis / 100);
	printf("Toatal :%f\n", tot);
}
#endif
#if QUES == 3
int main() {
	int age;
	printf("Enter age :");
	scanf("%d", &age);
	if (age > 20 && age < 30) { 
		printf("Your age is : %d", age);
		printf("You acn go coffee with me");
	}
	if (age > 15) { 
		printf("Your age is %d:", age);
		printf("Its time to go home:");
	}
	return 0;
}
#endif
