#include <stdio.h>
#define SIZE 10
void reverse(int arr[], int );
int main() {
	int arr[SIZE];
	int num;
	int i;
	printf("Enter the Size of array :");
	scanf("%d", &num);
	for(i = 0; i < num; i++) {
		printf("Enter the elements of array :");
		scanf("%d", &arr[i]);
	}
	reverse(arr, num);
	return 0;
}
void reverse(int arr[], int num) {
	int i;
	for(i = num - 1; i >= 0 ; i--) {
		printf("The reverse elements are :%d\n", arr[i]);
	} 
}
		
