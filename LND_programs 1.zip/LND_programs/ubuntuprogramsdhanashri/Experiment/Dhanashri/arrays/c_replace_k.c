#include <stdio.h>
#define SIZE 10
int main() {
	char arr[SIZE] ;
	char ch = 'c';
	int i;
	int num;
	printf("enter the no of elements to be entered:");
	scanf("%d", &num);
	printf("Enter the character:");

	for(i = 0; i < num; i++) {
		scanf("%c", &arr[i]);
	}
	for(i = 0; i < num; i++) {
		if(ch == arr[i]) {
			arr[i] = 'k';
		}
	}
	for(i = 0; i < num; i++) {
		printf("The array is :%c\n", arr[i]);
	}
}
