#include <stdio.h>
#define SIZE 20
void copy(int src[], int dest[], int num);
int main() {
	int src[SIZE];
	int dest[SIZE];
	int num;
	int i;
	printf("Enter the size of array :");
	scanf("%d", &num);
	for(i = 0; i < num; i++) {
		printf("Enter the elements of array :");
		scanf("%d", &src[i]);
	}
	copy(src, dest, num);
	return 0;
}
void copy(int src[], int dest[], int num) {
	int i;
	printf("\nThe source elements are :");
	for(i = 0; i < num; i++) {
		printf("%-5d", src[i]);
	}
	for(i = 0; i < num; i++) {
		dest[i] = src[i];
	}
	printf("\nThe destination elements are :");
	for(i = 0; i < num; i++) {
		printf("%-5d", dest[i]);
	}
}
	
