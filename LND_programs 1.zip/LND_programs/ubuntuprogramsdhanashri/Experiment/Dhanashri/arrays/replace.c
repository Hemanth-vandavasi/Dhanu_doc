#include <stdio.h>
int main() {
	int i;
	int arr[5];

	for(i = 0; i < 5; i++) {
		printf("Enter the elements are :");
		scanf("%d", &arr[i]);
	}
	arr[2] = 'D';
	for(i = 0; i < 5; i++) {
		printf("The elements are :%d\n", arr[i]);
	}

}
