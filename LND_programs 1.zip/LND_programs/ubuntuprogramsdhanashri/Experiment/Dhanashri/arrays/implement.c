#include <stdio.h>
#define SIZE 10
void Integer(int arr[], int num);
void Char(char ch[], int num);
void Float(float Ft[], int num);

int main() {
	int arr[SIZE];
	char ch[SIZE];
	float Ft[SIZE];
	int i;
	int num;
	printf("Enter the size of array :");
	scanf("%d", &num);
	for(i = 0; i < num; i++) {
		printf("Enter the elements of array :");
		scanf("%d", &arr[i]);
	}
	Integer(arr, num);
	for(i = 0; i < num; i++) {
		printf("Enter the Characters for array :");
		scanf("%s", &ch[i]);
	}
	Char(ch, num);
	for(i = 0; i < num; i++) {
		printf("Enter the Floats for array :");
		scanf("%f", &Ft[i]);
	}
	Float(Ft, num);
	return 0;
}
void Integer(int arr[], int num) {
	int i;
	for(i = 0; i < num; i++) {
		printf("The Integers are : %d\n", arr[i]);
	}
}
void Char(char ch[], int num) {
	int i;
	for(i = 0; i < num; i++) {
		printf("The Charcters are : %c\n", ch[i]);
	}
}
void Float(float Ft[], int num) {
	int i;
	for(i = 0; i < num; i++) {
		printf("The Floats are : %f\n", Ft[i]);
	}
}
