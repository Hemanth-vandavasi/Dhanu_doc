#include <stdio.h>
#define SIZE 20
int main() {
	int src[SIZE];
	int dest[SIZE];
	int merge[SIZE * 2];
	int num1;
	int num2;
	int mer;
	int index1;
	int index2;
	int merindex;
	int i;
	printf("Enter the size of source :");
	scanf("%d", &num1);
	for(i = 0; i < num1; i++) {
		printf("Enter the elements for src :");
		scanf("%d", &src[i]);
	}
	printf("Enter the size of Destination :");
	scanf("%d", &num2);
	for(i = 0; i < num2; i++) {
		printf("Enter the elements for dest :");
		scanf("%d", &dest[i]);
	}
	mer = num1 + num2;
	while(index1 >= num1 || index2 >= num2) {
		break;
	for(merindex = 0; merindex < mer; merindex++) {
		if(src[index1] < dest[index2]) {
			merge[merindex] = src[index1];
			index1++;
			merindex++;
		}
		else {
			merge[merindex] = dest[index2];
			index2++;
			merindex++;
		}
	}
		while(index1 < num1) {
			merge[merindex] = src[index1];
			merindex++;
			index1++;
//			merindex++;
		}
		while(index2 < num2) {
			merge[merindex] = dest[index2];
			merindex++;
			index2++;
//			merindex++;
		}
	}
	for(i = 0; i < mer; i++) {
		printf("The ascending order after merging is :", mer[i]);
	}
	
}				
