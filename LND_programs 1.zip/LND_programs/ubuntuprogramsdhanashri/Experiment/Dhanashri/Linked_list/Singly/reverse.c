#include <stdio.h>
#include <stdlib.h>
void Insert(int data1);
void Print();
void Reverse();
struct node {
	int data;
	struct node *next;
};
struct node* head = NULL;
struct node* temp;

int main() {
	int num = 0;
	int i = 0;
	int data1 = 0;
	printf("How many numbers you want?");
	scanf("%d", &num);
	for(i = 0; i < num; i++) {
		printf("Enter the data : ");
		scanf("%d", &data1);
		Insert(data1);
	}
	Print();
	Reverse();
	Print();
}
void Insert(int data1) {
	struct node* new = (struct node*)malloc(sizeof(struct node));
	new -> data = data1;
	new -> next = NULL;
	
	if(head == NULL) {
		head = new;
	} else {
		temp = head;
		while(temp -> next != NULL) {
			temp = temp -> next;
		}
		temp -> next = new;
	}
}
void Reverse() {
	temp = head;
	struct node* temp2 = temp -> next;
	struct node* temp3 = temp2 -> next;
	temp -> next = NULL;
	temp2 -> next = temp;
	while(temp3 != NULL) {
		temp = temp2;
		temp2 = temp3;
		temp3 = temp3 -> next;
		temp2 -> next = temp;
	}
	head = temp2;
}
void Print() {
	temp = head;
	printf("List is :");
	while(temp != NULL) {
		printf(" %d", temp -> data);
		temp = temp -> next;
	}
	printf("\n");
}
