#include <stdio.h>
#include <stdlib.h>
void enqueue(int ele);
void dequeue();
void peek();
void Display();
void freelist();

struct node {
	int data;
	struct node* next;
};
struct node* rear = 0;
struct node* front = 0;
struct node* temp;
int main() {
	int choice = 0;
	int ele = 0;
	while(1) {
		printf("\n1.Enqueue\n2.Dequeue\n3.peek\n4.Display\n5.exit\n");
		printf("Enter the choice :");
		scanf("%d", &choice);
		switch(choice) {
			case 1:
				printf("Enter the data :");
				scanf("%d", &ele);
				enqueue(ele);
				break;
			case 2:
				dequeue();
				break;
			case 3:
				peek();
				break;
			case 4:
				Display();
				break;
			case 5:
				exit(1);
				break;
			default :
				printf("Enter the correct choice\n");
		}
	}
	freelist();
	return 0;
}
void enqueue(int ele) {
	struct node* new = (struct node*)malloc(sizeof(struct node));
	if(NULL == new) {
		printf("Queue is overflow");
	}
	new -> data = ele;
	new -> next = NULL;
	if(rear == 0) {
		rear = new;
		front = new;
	} else {
		rear -> next = new;
		rear = new;
	}
}
void peek() {
	if(rear == 0) {
		printf("Queue is empty");
	} else {
		printf("peek is :%d\n", front -> data);
	}
}
void dequeue() {
	temp = front;
	if(front == 0) {
		printf("Queue is underflow");
	} else {
		front = front -> next;
		free(temp);
		temp = 0;
	}
}
void Display() {
	temp = front;
	while(temp != NULL) {
		printf(" %d\t", temp -> data);
		temp = temp -> next;
	}
	printf("\n");
}
void freelist() {
	while(front != 0) {
		temp = front;
		front = front -> next;
		free(temp);
		temp = 0;
	}
}
