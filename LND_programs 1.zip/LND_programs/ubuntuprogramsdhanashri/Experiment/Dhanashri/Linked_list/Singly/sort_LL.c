#include <stdio.h>
#include <stdlib.h>
void Display();
void Create(int ele);
void Sort();

struct node {
	int data;
	struct node* next;
};

struct node* head;
struct node* temp;

int main() {
	int num = 0;
	int ele = 0;
	int i = 0;
	head = NULL;
	printf("How many nodes u want ? :");
	scanf("%d", &num);
	
	for(i = 0; i < num; i++) {
		printf("Enter the elements in list :");
		scanf("%d", &ele);
		Create(ele);
	}
	Display();
	Sort();
	Display();
	return 0;
}
void Create(int ele) {
	struct node* new = (struct node*)malloc(sizeof(struct node));
	new -> data = ele;
	new -> next = NULL;
	
	if(head == NULL) {
		head = new;
	} else {
		temp = head;
		while(temp -> next != NULL) {
			temp = temp -> next;
		}
		temp -> next = new;
		new->next = NULL;
	}
}
void Display() {
	temp = head;
	printf("List is :");
	while(temp != NULL) {
		printf(" %d", temp -> data);
		temp = temp -> next;
	}
	printf("\n");
}
void Sort() {
	struct node* temp2;
	int temp3;
	temp = head;
	temp2 = temp -> next;
	
	if(head == NULL) {
		printf("List is empty :");
	} else {
		 while(temp != NULL) {
			temp2 = temp -> next;
		}
		while(temp2 != NULL) {
			if(temp -> data > temp2 -> data) {
				temp3 = temp -> data;
				temp -> data = temp2 -> data;
				temp2 -> data = temp3;
			}
			temp2 = temp2 -> next;
		}
		temp = temp -> next;
	}
}		
