#include <stdio.h>
#include <stdlib.h>
void push(int ele);
void pop();
void peek();
void Display();
void freelist();

struct node {
	int data;
	struct node* next;
};
struct node* top = 0;

int main() {
	int choice = 0;
	int num = 0;
	while(1) {
		printf("\n1.Push\n2.Peek\n3.Pop\n4.Display\n5.Exit\n");
		printf("Enter the Choice : ");
		scanf("%d", &choice);
		switch(choice) {
			case 1:
				printf("Enter the data");
				scanf("%d", &num);
				push(num);
				break;
			case 2:
				peek();
				break;
			case 3:
				pop();
				break;
			case 4:
				Display();
				break;
			case 5:
				exit(1);
				break;
			default :
				printf("Enter correct choice");
		}
	}
	freelist();
	return 0;
}
void push(int num) {
	struct node* new = (struct node*)malloc(sizeof(struct node));
	if(NULL == new) {
		printf("Stack is overflow");
	}
	if(top == 0) {
		new -> data = num;
		new -> next = top;
		top = new;
	} else {
		new -> data = num;
		new -> next = top;
		top = new;
	}
}
void peek() {
	if(top == 0) {
		printf("List is empty");
	} else {
		printf("Peek is : %d\n", top -> data);
	}
}
void pop() {
	struct node* temp = top;
	if(top == 0) {
		printf("Stack is underflow");
	} else {
		top = top -> next;
		free(temp);
		temp = 0;
	}
}
void Display() {
	struct node* temp = top;
	while(temp != NULL) {
		printf(" %d\t", temp -> data);
		temp = temp -> next;
	}
	printf("\n");
}
void freelist() {
	struct node* temp;
	while(top != NULL) {
		temp = top;
		top = top -> next;
		free(temp);
		temp = 0;
	}
}
