#include <stdio.h>
#include <stdlib.h>
void Insert(int data1);
void Insert_beg(int data1);
void Insert_end(int data1);
void Insert_pos(int data1);
void Delete_beg();
void Delete_end();
void Delete_pos();
void Reverse();
void Print();
void Swap();
void freelist();
struct node {
	int data;
	struct node *next;
};
struct node* head = NULL;
struct node* temp;

int main() {
	int num = 0;
	int i = 0;
	int data1 = 0;
	printf("How many numbers you want?");
	scanf("%d", &num);
	for(i = 0; i < num; i++) {
		printf("Enter the data : ");
		scanf("%d", &data1);
		Insert(data1);
	}
	Print();
	Insert_beg(data1);
	Print();
	Insert_end(data1);
	Print();
	Insert_pos(data1);
	Print();
	Delete_beg();
	Print();
	Delete_end();
	Print();
	Delete_pos();
	Print();
	Swap();
	Print();
	Reverse();
	Print();
	freelist();
}
void Insert(int data1) {
	struct node* new = (struct node*)malloc(sizeof(struct node));
	new -> data = data1;
	new -> next = NULL;
	
	if(head == NULL) {
		head = new;
	} else {
		temp = head;
		while(temp -> next != NULL) {
			temp = temp -> next;
		}
		temp -> next = new;
	}
}
void Insert_beg(int data1) {
	printf("Enter num for beg :");
	scanf("%d", &data1);
	struct node* new = (struct node*) malloc(sizeof(struct node));
	new -> data = data1;
	new -> next = head;
	head = new;
}
void Insert_end(int data1) {
	printf("Enter the node at end:");
	scanf("%d", &data1);
	struct node* new = (struct node*) malloc(sizeof(struct node));
	new -> data = data1;
	new -> next = NULL;
	temp = head;
	while(temp -> next != NULL) {
		temp = temp -> next;
	}
	temp -> next = new;
}
void Insert_pos(int data1) {
	int pos = 0;
	int i = 0;
	printf("Enter the new node at pos :");
	scanf("%d", &data1);
	printf("Enter the pos :");
	scanf("%d", &pos);
	struct node* new = (struct node*)malloc(sizeof(struct node));
	new -> data = data1;
	new -> next = NULL;
	temp = head;	
	for(i = 0; i < pos - 1; i++) {
		temp = temp -> next;
	}
	new -> next = temp -> next;
	temp -> next = new;
}
void Delete_beg() {
	temp = head;
	head = head -> next;
	free(temp);
}
void Delete_end() {
	struct node* temp1 = head;
	temp = head;
	while(temp1 -> next != NULL) {
		temp = temp1;
		temp1 = temp1 -> next;
	}
	temp -> next = NULL;
	free(temp1);
}
void Delete_pos(int num) {
	int pos = 0;
	printf("Enter the pos :");
	scanf("%d", &pos);
	struct node* temp1 = head;
	temp = head;
	if(pos == 0) {
		head = head -> next;
		free(temp);
	}
	for(int i = 0; i < pos - 1; i++) {
		temp1 = temp;
		temp = temp -> next;
	}
	temp1 = temp -> next;
	temp -> next = temp1 -> next;
	free(temp1);
}
void Print() {
	temp = head;
	printf("List is :");
	while(temp != NULL) {
		printf("%d\t", temp -> data);
		temp = temp -> next;
	}
	printf("\n");
}
void freelist() {
	while(head != NULL) {
		temp = head;
		head = head -> next;
		free(temp);
		temp = NULL;
	}
}

void Reverse() {
	temp = head;
	struct node* temp2 = temp -> next;
	struct node* temp3 = temp2 -> next;
	temp -> next = NULL;
	temp2 -> next = temp;
	while(temp3 != NULL) {
		temp = temp2;
		temp2 = temp3;
		temp3 = temp3 -> next;
		temp2 -> next = temp;
	}
	head = temp2;
}
void Swap() {
	temp = head;
	struct node* temp1;
	struct node* temp2 = head;
	while(temp -> next != NULL) {
		temp1 = temp;
		temp = temp -> next;
	}
	temp1 -> next = temp2;
	temp -> next = temp2 -> next;
	temp2 -> next = NULL;
	head = temp;
}
