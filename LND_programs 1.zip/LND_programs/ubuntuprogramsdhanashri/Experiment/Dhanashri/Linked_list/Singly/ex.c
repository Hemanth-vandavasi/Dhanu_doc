#include <stdio.h>
struct abc {
	char a;
	int b;
	int c;
	long double d;
	char e;
	int f;
};
int main() {
	printf("%ld", sizeof(struct abc));
}
