#include<stdio.h>
#include<stdlib.h>
struct node {
    int data;
    struct node * left;
    struct node * right;
};
struct node* insert_node(struct node* root, int data);
struct node* search_node(struct node *root,int data);
void inorder(struct node *root);
void preorder(struct node *root);
struct node *delete(struct node *root, int data);
struct node *Pre(struct node *root);
int main() {
    struct node *root = NULL;
    int data;
    int option;
    while(1) {
        printf("\n");
        printf("1. Insert an element into tree\n");
        printf("2. Search an element in the tree\n");
        printf("3. Traverse in inorder in the tree\n");
        printf("4. Delete a element in the tree\n");
        printf("5. Exit\n");
        printf("Enter your option : ");
        scanf("%d", &option);
        switch(option) {
            case 1:
                printf("Enter the data to be inserted : ");
                scanf("%d", &data);
                root = insert_node(root, data);
                break;
            case 2:
                printf("Enter the data to be searched : ");
                scanf("%d", &data);
                search_node(root,data);
            case 3:
              //  printf("Traverse in inorder in the tree :");
                inorder(root);
               // preorder(root);
                break;
            case 4: {
                printf("Delete a element in the tree :");
                scanf("%d", &data);
                root = delete(root, data);
                break;
                }
            case 5:
                exit(0);
                break;
            default:
                printf("Invalid option\n");
                break;
        }
        
    }
    return 0;
    
}
struct node* insert_node(struct node* root, int data) {
    if(root == NULL){
        root = (struct node*)malloc(sizeof(struct node));
        root->left = NULL;
        root->right = NULL;
        root -> data = data;
    } else if(data < root->data) {
        root->left = insert_node(root->left, data);
    } else if(data > root->data) {
        root->right = insert_node(root->right, data);
    } else {
        printf("Duplicate element not Allowed\n");
    }
    return root;
}
struct node* search_node(struct node* root,int data) {
    if(root == NULL) {
        printf("Root is empty");
    } else if (data == root -> data) {
        printf("Element found");
    } else if(data < root -> data) {
        root -> left = search_node(root -> left, data);
    } else if(data > root -> data) {
        root -> right = search_node(root -> right, data);
    } else {
        printf("Element not found");
    }
    return root;
}
struct node *delete(struct node *root, int data) {
    if(root == NULL) {
        printf("Empty tree\n");
    } else if( data < root -> data) {
        root -> left = delete(root -> left, data);
    } else if(data > root -> data) {
        root -> right = delete(root -> right, data);
    } else {
        if(root -> left == NULL && root -> right == NULL){ 
			free(root);
            root = NULL;
        }  else if(root -> left == NULL) {
            struct node* temp = root;
            root = root -> right;
            free(temp);
            temp = NULL;
        } else if(root -> right == NULL) {
            struct node *temp1 = root;
            root = root -> left;
            free(temp1);
            temp1 = NULL;
        } else {
            struct node* temp2 = Pre(root);
            root -> data = temp2 -> data;
            free(temp2);
            temp2 = NULL;
        }
    }
    return root;
}
struct node *Pre(struct node*root) {
    if(root == NULL) {
        printf("Tree empty\n");
    } else {
        root = root -> left;
        while (root -> right != NULL) {
            root = root -> right;
        }
    }
    return root;
}
void inorder(struct node *root) {
    if(root != NULL) {
        inorder(root->left);
        printf(" %d ", root->data);
        inorder(root->right);
    }
}
void preorder(struct node *root) {
    if (root != NULL) {
        printf(" %d ", root->data);
        preorder(root->left);
        preorder(root->right);
    }
}
