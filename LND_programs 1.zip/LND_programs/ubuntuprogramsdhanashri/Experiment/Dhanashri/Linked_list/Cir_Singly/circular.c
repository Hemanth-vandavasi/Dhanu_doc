#include <stdio.h>
#include <stdlib.h>
void Create(int ele);
void Print();
struct node { 
	int data;
	struct node* next;
};
struct node* head;
struct node* temp;

int main() {
	int i = 0;
	int num = 0;
	int ele = 0;
	head = NULL;
	printf("How many nodes u want? ");
	scanf("%d", &num);
	for(i = 0; i < num; i++) {
		printf("Enter the elements :");
		scanf("%d", &ele);
		Create(ele);
	}
	Print();
}
void Create(int ele) {
	struct node* new = (struct node*)malloc(sizeof(struct node));
	new -> data = ele;
	new -> next = NULL; 
	if(head == NULL) {
		head = new;
		new -> next = head;
	} else {
		temp = head;
		while(temp -> next != head) {
			temp = temp -> next;
		}
		temp -> next = new;
		new -> next = head;
	}
}
void Print() {
	temp = head;
	if(head == NULL) {
		printf("empty");
	}else {
		printf("The lis is:");
		do{
			printf("%d\t", temp -> data);
			temp = temp -> next;
		}while(temp != head);
	}
	printf("\n");
}
