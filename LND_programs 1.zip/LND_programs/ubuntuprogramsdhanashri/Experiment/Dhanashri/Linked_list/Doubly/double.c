#include <stdio.h>
#include <stdlib.h>
void Create(int ele);
void Insert_beg(int ele);
void Insert_end(int ele);
void Insert_pos(int ele);
void Delete_beg();
void Delete_end();
void Delete_pos();
void Print();
void freelist();
void Reverse();
struct node {
	int data;
	struct node* prev;
	struct node* next;
};
struct node* head;
struct node* temp;

int main() {
	int num = 0;
	int i = 0;
	int ele = 0;
	head = NULL;
	printf("How many node you want? ");
	scanf("%d", &num);
	for(i = 0; i < num; i++) {
		printf("Enter the elements : ");
		scanf("%d", &ele);
		Create(ele);
	}
	Print();
	Insert_beg(ele);
	Print();
	Insert_end(ele);
	Print();
	Insert_pos(ele);
	Print();	
	Delete_beg();
	Print();
	Delete_end();
	Print();
	Delete_pos();
	Print();
	Reverse();
	freelist();
}
void Create(int ele) {
	struct node* new = (struct node*)malloc(sizeof(struct node));
	new -> data = ele;
	new -> next = NULL;
	new -> prev = NULL;
	
	if(head == NULL) {
		head = new;
	} else {
		temp = head;
		while(temp -> next != NULL) {
			temp = temp -> next;
		}
		temp -> next = new;
		new -> next = NULL;
		new -> prev = temp;
	}
}
void Insert_beg(int ele) {
	printf("Enter the element ");
	scanf("%d", &ele);
	struct node* new = (struct node*) malloc(sizeof(struct node));
	new -> data = ele;
	new -> next = head;
	head -> prev = new;
	head = new;
}
void Insert_end(int ele) {
	printf("Enter the data :");
	scanf("%d", &ele);
	struct node* new = (struct node*) malloc(sizeof(struct node));
	new -> data = ele;
	new -> next = NULL;
	temp = head;
	while(temp -> next != NULL) {
		temp = temp -> next;
	}
	temp -> next = new;
	new -> prev = temp;
}
void Insert_pos(int ele) {
	int i = 0;
	int pos = 0;
	printf("Enter the pos :");
	scanf("%d", &pos);
	printf("Enter the data ;");
	scanf("%d", &ele);
	struct node *new = (struct node*)malloc(sizeof(struct node));
	new -> data = ele;
	new -> next = NULL;
	new -> prev = NULL;
	
	if(pos == 1) {
		if(head == NULL) {
			head = new;
		} else {
			new -> next = head;
			head -> prev = new;
			head = new;
		}
	} else {
		temp = head;
		for(i = 0; i < pos - 1; i++) {
			temp = temp -> next;
		}
		new -> prev = temp;
		new -> next = temp -> next;
		temp -> next = new;
		new -> next -> prev = new;
	}
}	
void Delete_beg() {
	if(head == NULL) {
		printf("List is empty :");
	} else {
		temp = head;
		head = head -> next;
		head -> prev = NULL;
		free(temp);
		temp = NULL;
	}
}
void Delete_end() {
	if(head == NULL) {
		printf("List is empty ");
	} else {
		struct node* temp1 = head;
		temp = head;
		while(temp -> next != NULL) {
			temp1 = temp;
			temp = temp -> next;
		}
		temp1 -> next = NULL;
		free(temp);
	}
}
void Delete_pos() {
	int pos = 0;
	int i = 0;
	printf("Enter pos to delete :");
	scanf("%d", &pos);
	if(head == NULL) {
		printf("List is empty :");
	} else if(pos == 1) {
		temp = head;
		head = head -> next;
		head -> prev = NULL;
		free(temp);
	} else {
		struct node* temp1 = head;
		temp = head;
		for(i = 0; i < pos - 1; i++) {
			temp1 = temp;
			temp = temp -> next;
		}
		temp1 -> next = temp -> next;
		temp -> next -> prev = temp1;
		free(temp);
	}
}
		
void Print() {
	temp = head;
	printf("The list is :");
	while(temp != NULL) {
		printf(" %d", temp -> data);
		temp = temp -> next;
	}
	printf("\n");
}
void freelist() {
	while(head != NULL) {
		temp = head;
		head = head -> next;
		free(temp);
		temp = NULL;
	}
}										
void Reverse() {
	temp = head;
	printf("Reverse list is :");
	if(head == NULL) {
		printf("List is empty \n");
	} else {
		while(temp->next != NULL) {
			temp = temp -> next;
		}
		while(temp != NULL) {
			printf(" %d", temp  -> data);
			temp  = temp -> prev;
		}
		printf("\n");
	}
} 	
