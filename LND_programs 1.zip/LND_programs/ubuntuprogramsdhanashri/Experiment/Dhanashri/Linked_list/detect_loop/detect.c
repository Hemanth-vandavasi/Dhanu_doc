#include <stdio.h>
#include <stdlib.h>
struct node {
    int data;
    struct node *next;
};
struct node *head = NULL;
void create (int);
void findloop(struct node *);
void display(struct node *);
void freelist(struct node *);
int main() {
    int num;
    printf(" how many nodes you want :");
    scanf("%d", &num);
    create(num);
    findloop(head);
    display(head);
    return 0;
}
void create(int num) {
    int ele;
    head = NULL;
    struct node *newnode;
    struct node *temp;
    for(int i = 0; i < num; i++) {
        printf("Enter the element:");
        scanf("%d", &ele);
        newnode = (struct node*) malloc(sizeof(struct node));
        newnode->data = ele;
        newnode->next = NULL;
        if (head == NULL) {
            head = newnode;
        } else {
            temp = head;
            while (temp->next != NULL) {
                temp = temp->next;
            }
            temp->next = newnode;
        }
    }
    newnode->next = head->next->next->next;
    return;
}
void findloop(struct node *head) {
    struct node *slow, *fast;
    slow = head;
    fast = head;
    while(slow != NULL && fast != NULL && fast->next != NULL) {
        slow = slow->next;
        fast = fast->next->next;
        if (slow == fast) {
            printf("Loop found!\n");
            printf("Loop meet node:%d\n", slow -> data);
            break;
        }
    }
    if (slow == fast) {
        slow = head;
        while(slow->next != fast-> next) {
            slow = slow->next;
            fast = fast->next;
        }
        fast -> next = NULL;
        printf("loop started node is:%d\n", slow->data);
        fast -> next = NULL;
        printf("Remove loop :");
    }
}
/*void remove_loop(struct node *head) {
    struct node *ptr1 = start_node(head);
    struct node *ptr2 = meet_node(head
    while (ptr2->next != ptr1) {
        ptr2 = ptr2->next;
    }
    ptr2->next = NULL;}*/
void display(struct node *head){
    struct node *ptr = head;
    while (ptr != NULL) {
        printf("%d ", ptr->data);
        ptr = ptr->next;
    }
}
void freelist(struct node *head){
    struct node *temp;
    while(head != NULL) {
        temp = head;
        head = head->next;
        free(temp);
		temp = NULL;
    }
}
