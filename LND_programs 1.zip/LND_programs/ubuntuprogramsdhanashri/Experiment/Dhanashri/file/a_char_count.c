#include <stdio.h>
#include <string.h>
int main() {
	FILE *fd;
	int count = 0;
	char ch;
	fd = fopen("input.txt", "r");
	while((ch = fgetc(fd)) != EOF) {
		if(ch == 'a') {
			count++;
		}
	}
	printf("%d\n", count);
	fclose(fd);
	return 0;
}
