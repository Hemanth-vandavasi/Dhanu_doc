#include <stdio.h>
#include <stdlib.h>

int main() {
	FILE *fd;
	int count = 0;
	char ch;
	fd = fopen("input.txt", "r");
	if(fd == NULL) {
		printf("Error");
		exit(1);
	}
	fseek(fd, 0, SEEK_END);
	count = ftell(fd);
	printf("%d\n", count);
	fclose(fd);
	return 0;
}
