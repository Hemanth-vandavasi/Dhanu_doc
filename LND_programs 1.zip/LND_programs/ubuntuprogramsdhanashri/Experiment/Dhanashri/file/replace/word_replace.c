#include <stdio.h>
#include <stdio_ext.h>
#define SIZE 40

int main() {
	FILE *fd;
	fd = fopen("input.txt", "r");
	char search;
	char replace;
	char buf[SIZE];
	char c;
	printf("Enter the word to search");
	__fpurge(stdin);
	printf("Enter the word to replace");
	__fpurge(stdin);
	
	while((c = fscanf(fd, "%s", buf)) != EOF) {
		if(c == search) {
//			fseek(fd, -1, SEEK_CUR);
			fprintf(fd, "%s", replace);
			break;
		}
	}
	fclose(fd);
}
