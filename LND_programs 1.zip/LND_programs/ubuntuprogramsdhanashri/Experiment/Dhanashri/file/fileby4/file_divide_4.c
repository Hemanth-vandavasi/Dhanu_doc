#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdio_ext.h>
#define SIZE 5

int main() {
	FILE *fd_1;
	FILE *fd_2;
	FILE *fd_3;
	FILE *fd_4;
	FILE *fd_5;
	char ch;
	int i = 0;
	int count = 0;
	char buff[SIZE];
	printf("Enter the data :\n");
	fread(buff, SIZE, 1, stdin);
	fd_1 = fopen("file_1.txt", "w+");
	if(fd_1 == NULL) {
		printf("Error in file 1 opening\n");
		exit(1);
	}
	
	fd_2 = fopen("file_2.txt", "w");
	if(fd_2 == NULL) {
		printf("Error in file 2 opening\n");
		exit(1);
	}

	fd_3 = fopen("file_3.txt", "w");
	if(fd_3 == NULL) {
		printf("Error in file 3 opening\n");
		exit(1);
	}
	fd_4 = fopen("file_4.txt", "w");
	if(fd_4 == NULL) {
		printf("Error in file 4 opening\n");
		exit(1);
	}
	fd_5 = fopen("file_5.txt", "w");
	if(fd_5 == NULL) {
		printf("Error in file 5 opening\n");
		exit(1);
	}
	fwrite(buff, strlen(buff), 1, fd_1);
	fseek(fd_1, 0, SEEK_END);
	count = ftell(fd_1);
	fseek(fd_1, 0, SEEK_SET);
	count = count / 4;	
	while((ch = fgetc(fd_1)) != EOF) {
		if(i <= count) {
			fputc(ch, fd_2);
		} else if((i > count) && (i <= count * 2)) {
			fputc(ch, fd_3);
		} else if((i > count * 2) && (i <= count * 3)) {
			fputc(ch, fd_4);
		} else if((i > count * 3) && (i <= count * 4)) {
			fputc(ch, fd_5);
		}
		i++;
	}
	fclose(fd_1);
	fclose(fd_2);
	fclose(fd_3);
	fclose(fd_4);
	fclose(fd_5);
	return 0;
}
