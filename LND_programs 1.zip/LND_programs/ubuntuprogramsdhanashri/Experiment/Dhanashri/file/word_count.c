#include <stdio.h>
#include <string.h>
int main() {
	FILE *fd;
	int count = 0;
	int count1 = 0;
	char ch;
	char buf[30];
	char buf2[30] = "Dhanashri..";
	fd = fopen("input.txt", "r");
	while((ch = fscanf(fd, "%s", buf)) != EOF) {
			count++;
		if((strcmp(buf, buf2) == 0)) {
			count1++;
		}
	}
	printf("%d\n", count);
	printf("%d\n", count1);
	fclose(fd);
	return 0;
}
