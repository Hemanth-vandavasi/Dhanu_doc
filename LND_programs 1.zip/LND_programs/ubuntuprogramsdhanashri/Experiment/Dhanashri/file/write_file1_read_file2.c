#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define SIZE 20
 int main() {
	FILE *fd;
	FILE *fd1;
	char buf[SIZE];
	char buf2[SIZE];
	printf("Enter the string : ");
	fgets(buf, SIZE, stdin);
	
	fd = fopen("File_1.txt", "w+");
	if(fd == NULL) {
		printf("Error in file opening\n");
		exit(1);
	}
	fwrite(buf, sizeof(buf), 1, fd);
	fseek(fd, 0, SEEK_SET);
	fread(buf2, sizeof(buf2), 1, fd);
	fd1 = fopen("File_2.txt", "w+");
	if(fd == NULL) {
		printf("Error in file2 opening\n");
		exit(1);
	}
	fwrite(buf, sizeof(buf), 1, fd1);
	fseek(fd1, 0, SEEK_SET);
	fscanf(fd, "%s", buf2);	
	printf("The string is : %s\n", buf2);	
	fclose(fd);
	fclose(fd1);
	return 0;
}
	
