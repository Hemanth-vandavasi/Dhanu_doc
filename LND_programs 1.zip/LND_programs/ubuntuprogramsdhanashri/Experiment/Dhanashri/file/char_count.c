#include <stdio.h>
#include <string.h>
int main() {
	FILE *fd;
	int count = 0;
	char ch;
	fd = fopen("input.txt", "r");
	while((ch = fgetc(fd)) != EOF) {
		count++;
	}
	printf("%d\n", count);
	fclose(fd);
	return 0;
}
