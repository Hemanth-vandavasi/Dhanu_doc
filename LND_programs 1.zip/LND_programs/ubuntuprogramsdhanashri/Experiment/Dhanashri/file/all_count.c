#include <stdio.h>
#include <stdlib.h>

int main() {
	FILE *fd;
	int count = 0;
	int count1 = 0;
	int count2 = 0;
	char ch;
	fd = fopen("input.txt", "r");
	if(fd == NULL) {
		printf("Error");
		exit(1);
	}
	while((ch = fgetc(fd)) != EOF) {
		count++;
		if((ch == ' ') || (ch == '\n')) {
			count1++;
		}
		if(ch == '\n') {
			count2++;
		}
	}
	printf("%d\n", count);
	printf("%d\n", count1);
	printf("%d\n", count2);
	fclose(fd);
	return 0;
}
