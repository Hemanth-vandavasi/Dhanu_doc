#include <stdio.h>
#include <stdlib.h>
#define SIZE 30
int main() {
	FILE *fd;
	fd = fopen("input.txt", "w");
	if(fd == NULL) {
		printf("File is not exist");
		exit(1);
	}
	int i = 0;
/*	for(i = 1; i <= 100; i++) {
		fprintf(fd, "%d\n", i);
	}*/
	char buf[SIZE];
	for(i = 0; i < 10; i++) {
		fgets(buf, SIZE, stdin);
		fputs(buf, fd);	
	}	
	fclose(fd);
	return 0;
}
