#include <stdio.h>
int main() {
	FILE *fd;
	int count = 0;
	char ch;
	char buf[30];
	fd = fopen("input.txt", "r");
	while(ch = fgets(buf,30,fd) != NULL) {
		count++;
	}
	printf("%d\n", count);
	fclose(fd);
	return 0;
}
