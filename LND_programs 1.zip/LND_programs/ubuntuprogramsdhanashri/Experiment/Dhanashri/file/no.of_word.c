#include <stdio.h>
#include <stdlib.h>

int main() {
	FILE *fd;
	char ch;
	int count = 0;
	fd = fopen("input.txt", "r");
	if(fd == NULL) {
		printf("error");
		exit(1);
	}
	while((ch = fgetc(fd)) != EOF) {
		if(ch == ' ' || ch == '\n') {
			count++;
		}
	}
	printf("%d\n", count);
	fclose(fd);
	return 0;
}
