#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define SIZE 50
int main() {
	FILE *fd;
	FILE *f_temp;
	char buf[SIZE];
	int count = 0;

	fd = fopen("Input.txt", "w");
	if(fd == NULL) {
		printf("Error in opening file");
		exit(1);
	}
//	fwrite(buf , 0 , 1, fd); 
	fclose(fd);
	return 0;
}
