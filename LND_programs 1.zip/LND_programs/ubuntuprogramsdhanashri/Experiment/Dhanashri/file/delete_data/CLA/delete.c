#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAX 50
int main(int argc, char *argv[])
{
    FILE *fp;
    FILE *fp1;
    char ch;
    int count = 0;
    //char buf[MAX];
    int deleteLine;
    int temp = 1;
    fp = fopen(argv[1], "r");
    if (fp == NULL) {
        printf("Error in file opening");
        exit(0);
    }
    while ((ch = fgetc(fp)) != EOF) {
        printf("%c", ch);
        ch = fgetc(fp);
    }
    rewind(fp);
    printf("Enter the line:\n");
    scanf("%d", &deleteLine);
    fp1 = fopen("output.txt", "w");
    while((ch = fgetc(fp)) != EOF) {
        if(ch == '\n') {
            temp++;
        }
        if(temp != deleteLine) {
            fputc(ch, fp1);
        }
    }
    fclose(fp);
    fclose(fp1);
    remove(argv[1]);
    rename("output.txt", argv[1]);
    fp = fopen(argv[1], "r");
//  printf("pointer are at position:%ld", ftell(fp1));
//  rewind(fp1);
    while((ch = fgetc(fp)) != EOF) {
        printf("%c", ch);
        ch = fgetc(fp);
    }
    fclose(fp);
    return 0;
}   
