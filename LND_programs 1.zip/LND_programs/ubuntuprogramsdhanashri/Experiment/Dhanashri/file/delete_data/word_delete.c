#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define SIZE 50
int main() {
	FILE *fd;
	FILE *f_temp;
	char buf[SIZE];
	char buf1[SIZE] = "paper";
	int count = 0;

	fd = fopen("Input.txt", "r");
	if(fd == NULL) {
		printf("Error in opening file");
		exit(1);
	}
	
	f_temp = fopen("Output.txt", "a");
	if(f_temp == NULL) {
		printf("Error in opening file");
		exit(1);
	}
	
	while((fscanf(fd, "%s", buf)) != EOF) {
		if(strcmp(buf, buf1) == 0) {
			continue;
		} else { 
			fprintf(f_temp , "%s\n" , buf);
		}
	}
	fclose(fd);
	fclose(f_temp);
	return 0;
}
