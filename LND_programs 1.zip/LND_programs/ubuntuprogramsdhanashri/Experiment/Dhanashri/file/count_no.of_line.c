#include <stdio.h>
#include <stdlib.h>
#define SIZE 100
int main() {
	int count = 0;
	char ch;
	char buf[SIZE];
	FILE *fd;
	fd = fopen("input.txt", "r");
	if(fd == NULL) {
		printf("Error in file opening");
		exit(1);
	}
	while((ch = fgetc(fd)) != EOF) {
		if(ch == '\n') {
			count++;
		}
	}
	printf("%d\n", count);
	return 0;
}
