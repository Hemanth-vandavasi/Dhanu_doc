#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define SIZE 100

int main() {
	FILE *fd;
	FILE *ptr;
	char buf[SIZE];
	fd = fopen("Input.txt", "a");
	if(fd == NULL) {
		printf("Error in file");
		exit(1);
	}

	ptr = fopen("output.txt", "r");
	if(ptr == NULL) {
		printf("Error in file");
		exit(1);
	}

/*	fread(buf, SIZE, 1, ptr);
	fwrite(buf, strlen(buf), 1, fd);*/
	
	while((fgets(buf, SIZE, ptr)) != NULL) {
		fputs(buf, fd);
	}
	
	fclose(fd);
	fclose(ptr);
	return 0;
}
