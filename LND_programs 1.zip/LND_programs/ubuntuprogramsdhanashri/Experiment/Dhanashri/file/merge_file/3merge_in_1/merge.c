#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define SIZE 100
int main() {
	FILE *fd_1;
	FILE *fd_2;
	FILE *fd_3;
	FILE *my_f;
	char buf[SIZE];
	char buf2[SIZE];
	char buf3[SIZE];

	fd_1 = fopen("input_1.txt", "r");
	if(fd_1 == NULL) {
		printf("Error");
		exit(1);
	}

	fd_2 = fopen("input_2.txt", "r");
	if(fd_2 == NULL) {
		printf("Error");
		exit(1);
	}

	fd_3 = fopen("input_3.txt", "r");
	if(fd_3 == NULL) {
		printf("Error");
		exit(1);
	}

	my_f = fopen("ouput.txt", "a");
	if(my_f == NULL) {
		printf("Error");
		exit(1);
	}
	
	fread(buf, SIZE, 1, fd_1);
	fwrite(buf, strlen(buf), 1, my_f);
	fread(buf2, SIZE, 1, fd_2);
	fwrite(buf2, strlen(buf2), 1, my_f);
	fread(buf3, SIZE, 1, fd_3);
	fwrite(buf3, strlen(buf3), 1, my_f);

	fclose(fd_1);
	fclose(fd_2);
	fclose(fd_3);
	fclose(my_f);
	return 0;
}
