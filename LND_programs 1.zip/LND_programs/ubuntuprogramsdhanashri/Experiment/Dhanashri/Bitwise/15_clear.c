#include <stdio.h>
void Set_bit(unsigned int, unsigned int, unsigned int);
void Display(unsigned int);

int main() {
	unsigned int num;
	unsigned int pos1;
	unsigned int pos2;
	printf("Enter the num : ");
	scanf("%d", &num);
	Display(num);
	printf("Enter the pos 1 :");
	scanf("%d", &pos1);
	printf("Enter the pos 2 :");
	scanf("%d", &pos2);
	Set_bit(num, pos1, pos2);
	return 0;
}
void Set_bit(unsigned int num, unsigned int pos1, unsigned int pos2) {
	int i = 0;
	for(i = pos1 - 1; i < pos2; i++) {
		num = num & ~(1 << i);
	}
	Display(num);
	printf("%d\n", num);
}
void Display(unsigned int num) {
	unsigned int i = 8;
	while(i) {
		if(num & 0x80) {
			printf(" 1");
		} else {
			printf(" 0");
		}
		num = num << 1;
		i--;
	}
	printf("\n");
}
