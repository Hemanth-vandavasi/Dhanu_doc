#include <stdio.h>
void Endian(unsigned int num);

int main() {
	unsigned int num;
	printf("Enter the num :");
	scanf("%d", &num);
	Endian(num);
	return 0;
}
void Endian(unsigned int num) {
	int *ptr;
	ptr = &num;
	if(*ptr == num) {
		printf("This is little endian");
	} else {
		printf("This is big endian");
	}
}
