#include <stdio.h>
void Display(unsigned int num);
int main() {
	unsigned int num1;
	unsigned int num2;
	int i = 0;
	printf("Enter the num 1 :");
	scanf("%d", &num1);
	Display(num1);
	printf("Enter the num 2 :");
	scanf("%d", &num2);
	Display(num2);
	if((num1 ^ num2) > 0) {
		printf("%d is greater %d\n", num1, num2);
	} else if((num1 ^ num2) == 0) {
		printf("%d is equal %d\n", num1, num2);
	} else {
		printf("%d is less to %d\n", num1, num2);
	}
	return 0; 
}

void Display(unsigned int num) {
	int i = 32;
	while(i) {
		if(num & 0x80000000) {
			printf(" 1");
		} else {
			printf(" 0");
		}
		num = num << 1;
		i--;
	}
	printf("\n");
}
