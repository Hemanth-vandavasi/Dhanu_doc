#include <stdio.h>
void clear_bit(unsigned int, unsigned int);
void Display(unsigned int);

int main() {
	unsigned int num;
	unsigned int pos;
	printf("Enter the num :");
	scanf("%d", &num);
	Display(num);
	printf("Enter the pos :");
	scanf("%d", &pos);
	clear_bit(num, pos);
//	Display(num);
//	printf("%d\n", num);
	return 0;
}
void clear_bit(unsigned int num, unsigned int pos) {
	num = num &  ~(1 << pos);
	Display(num);
	printf("%d\n", num);
}
void Display(unsigned int num) {
	unsigned int i = 8;
	while(i) {
		if(num & 0x80) {
			printf("1");
		} else {
			printf("0");
		}
		num = num << 1;
		i--;
	}
	printf("\n");
}
