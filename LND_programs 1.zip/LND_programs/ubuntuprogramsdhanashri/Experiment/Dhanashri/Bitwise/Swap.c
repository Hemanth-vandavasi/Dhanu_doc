#include <stdio.h>
void display(unsigned short num);
unsigned short swap_bits(unsigned short num);
int main()
{
    unsigned short num;
    num = 0xABCD;
   // printf("%x\n",num);
    printf("Bit representation\n");
    display(num);
    printf("\n");
    swap_bits(num);
    return 0;
}
unsigned short swap_bits(unsigned short num)
{
	unsigned int num1 = num;
	unsigned int num2;
	unsigned int num3;
    num = (((num << 12) | (num >> 12))) | (num & 0x0ff0); 
    display(num);
}
void display(unsigned short num)
{
    for(int i = 0 ; i < 16 ; i++) {
        if(num & 0x8000) {
            printf(" 1");
        } else {
            printf(" 0");
        }
        num = num << 1;
    }   
}
