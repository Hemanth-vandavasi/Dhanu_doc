#include <stdio.h>
void Display(unsigned int);
int main() {
	unsigned int num;
	printf("Enter the number :");
	scanf("%d", &num);
	Display(num);
	return 0;
}

void Display(unsigned int num) {
	unsigned int i = 16;
	while(i) {
		if(num & 0x8000) {
			printf("1");
		} else { 
			printf("0");
		}
		num = num << 1;
		i--;
	}
	printf("\n");
}
