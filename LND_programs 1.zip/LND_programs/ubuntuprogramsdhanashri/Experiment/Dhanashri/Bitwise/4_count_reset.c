#include <stdio.h>
unsigned int Display(unsigned int num);

int main() {
	unsigned int num;
	printf("Enter the num :");
	scanf("%d", &num);
	Display(num);
	return 0;
}
unsigned int Display(unsigned int num) {
	unsigned int i = 32;
	unsigned int count = 0;
	while(i) {
		if(num & 8888) {
			printf("1");
		} else {
			printf("0");
			count++;
		}
		num = num << 1;
		i--;
	}
	printf("\n");
	printf("%d\n", count);
}
