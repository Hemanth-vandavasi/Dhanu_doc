#include <stdio.h>
int Display(unsigned int num);

int main() {
	unsigned int num;
	printf("Enter the num :");
	scanf("%d", &num);
	Display(num);
	return 0;
}
int Display(unsigned int num) {
	unsigned int i = 8;
	unsigned int count = 0;
	while(i) {
		if(num & 0x80) {
			printf("1");
			count++;
		} else {
			printf("0");
		}
		num = num << 1;
		i--;
	}
	printf("\n");
	printf("%d\n",count);
}
	
