#include <stdio.h>
void Display(unsigned int num);
int main() {
	unsigned int num1;
	unsigned int num2;
	int i = 0;
	printf("Enter the num 1 :");
	scanf("%d", &num1);
	Display(num1);
	printf("Enter the num 2 :");
	scanf("%d", &num2);
	Display(num2);
	for(i = 31; i >= 0; i--) {
		if((num1 & (1 << i)) && (!(num2 & (1 << i)))) {
			printf("Num 1 is greater\n");
			break;
		} else if(!(num1 & (1 << i)) && ((num2 & (1 << i)))) {
				printf("num 2 is greater\n");
				break;	
		}
	}
	if(i < 0) {
		printf("Numbers are equal \n"); 
	}
}

void Display(unsigned int num) {
	int i = 32;
	while(i) {
		if(num & 0x80000000) {
			printf(" 1");
		} else {
			printf(" 0");
		}
		num = num << 1;
		i--;
	}
	printf("\n");
}
