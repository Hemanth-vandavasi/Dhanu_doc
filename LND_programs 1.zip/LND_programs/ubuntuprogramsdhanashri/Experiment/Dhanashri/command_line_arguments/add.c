#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main(int argc, char * argv[]) {
	int a;
	int b;
	int sum = a + b;
	printf("%d\n", atoi(argv[1]) + atoi(argv[2]));
}
