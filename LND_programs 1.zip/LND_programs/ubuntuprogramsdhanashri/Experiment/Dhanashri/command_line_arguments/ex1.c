#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {
/*	printf("%s\n", argv[1]);
	printf("%s\n", argv[2]);
	printf("%s\n", argv[3]);
	printf("%s\n", argv[4]);*/
	for(int i = 1; i < argc; i++) {
		printf("%s\n", argv[i]);
	}
	return 0;
}
