#include <stdio.h>
#include <stdlib.h>
//void display(int a, int b);
void sum(int, int);
//void sub(int, int);

int main(int argc, char *argv[]) {
	int a = atoi(argv[1]);
	int b = atoi(argv[2]);
	sum(a , b);
	sub(a , b);
}
void sum(int a, int b) {
	printf("Sum is :%d\n", a+b);
}

void sub(int a, int b) {
	printf("Sub is :%d\n", a-b);
}
/*
void display(int a, int b) {
	void (*ptr) (int, int);
	(*ptr) (30, 20);
}*/
