#include <stdio.h>

int main()
{
	char x, y;
	int z;
	x = 'a';
	y = 'b';
	z = x + y;
	printf("Addition of nos. %d\n", z);
}

