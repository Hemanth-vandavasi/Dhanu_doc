#include <stdio.h>
int add(int , int);
int sub(int , int);
int div(int , int);
int main() {
	int num1;
	int num2;
	printf("enter the number1:");
	scanf("%d%d",&num1, &num2);
//	printf("enter the number2:");
//	scanf("%d",&num2);
	printf("%d\n",add(num1 , num2));
	printf("%d\n",sub(num1 , num2));
	printf("%d\n",div(num1 , num2));
}
int add(int x , int y) {
	return x + y;
}
int sub(int num1, int num2) {
	return num1 - num2;
}
int div(int num1, int num2) {
	return num1 % num2;
}

