// calcilatiom of simple interest
#include <stdio.h>
#if 0
int main()
{
	int p, n;
	float r, si;

	p = 1000;
	n = 3;
	r = 8.5;
	si = p * n * r / 100;

	printf("%f\n", si);
}
#endif

#if 1
int main()
{
	int p, n;
	float r, si;
	printf("Enter the values:\n");
	scanf("%d%d\n", &p, &n);
	scanf("%f", &r);
	si = p * n * r / 100;
	printf("Simple intrest is: %f\n", si);
}
#endif
