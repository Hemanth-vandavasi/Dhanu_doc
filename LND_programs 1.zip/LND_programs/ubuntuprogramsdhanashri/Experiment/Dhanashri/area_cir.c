/*Program for finding the area of circle*/
#include <stdio.h>
#define PI 3.1415
//Function declaration
int Area(float r);

//Main function
int main() {
	float rad;
	float area;
	
	printf("Enter the value of radius :");
	scanf("%f", &rad);
	area = Area(rad);
	printf("The area of circle is :%f", area);
}
//Function defination
int Area(float r) {
	float area;
	area = PI * r * r;
	return (area); //Return result
}
