#include <stdio.h>
#if Q == 1
int main() {
	int a;
	int i = 3;
	a = ++i + ++i;  // 4 + 5.... 5 + 5 = 10
	printf("%d", a);
	return 0;
}
#endif

#if Q == 2
int main() {
	int a = 10;
	int i = ++a;  //11
	int j = a++;  //11
	printf("%d%d", i, j);
}
#endif

#if Q == 3
int main() {
	int a;
	int i = 5;
	a = ++i + i++;  // 6 + 7 = 13
	printf("%d\n", a);
	printf("%d\n", i);
}
#endif
