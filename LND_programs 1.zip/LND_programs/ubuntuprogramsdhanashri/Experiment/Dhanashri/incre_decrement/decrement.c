#include <stdio.h>

#if Q == 1
int main() {	
	int a = 7;
//	int i = --a; // 6
//	int i = a--; // 7
//	int i = --a + --a; // 6 + 5... 5+5 = 10
//	int i = --a - --a;  // 6 - 5... 5 - 5 = 0
	int i = --a - a--;  // 6 - 6.. 5 - 6 = -1
	printf("i is :%d\n", i);
	printf("a is :%d\n", a);
}
#endif


