#include <stdio.h>
int main() {
	int a = 32768;
	printf("Number is :%d\n", a);
	return 0;
}
