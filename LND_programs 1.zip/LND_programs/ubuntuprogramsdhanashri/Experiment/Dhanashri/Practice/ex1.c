#include <stdio.h>
int main() {
	double A = 19;
	printf("%.1lf\n", A);
}
