#include <stdio.h>
#if QUES == 1
int main() {
	int sum;
	int i;

	for (i = 10; i <= 50; i++) {
		sum = sum + i;
	}
	printf("Addition : %d\n", sum);
	return 0;
}
#endif

#if QUES == 2
int main() {
 	int sum;
	int i;
	for (i = 10; i <= 50; i++) {
		printf("Enter the nos :%d\n", i);
		sum = sum + i;
	}
	printf("Addition of nos : %d\n", sum);
	return 0;
}
#endif
