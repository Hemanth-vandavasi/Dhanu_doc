#include <stdio.h>
#include <string.h>
char* my_string(char *str,char *ch);

int main() {
	char ch[20];
	char str[30];
//	char copy = 0;
	printf("Enter a string %s:", ch);
	fgets(ch, 20, stdin);
//	scanf("%s", &ch);
	my_string(str,ch);
	printf("%s",ch);
//	return 0;
}

char* my_string(char *str,char *ch)
{
	int i;
//	char copy = 0;
	for (i = 0; i < 20 && ch[i] != '\0'; i++) 
//		printf("copy the character %s\n:", str);
//		printf("%s", str);
	{
		str[i] = ch[i];
	return str;
	}
//	printf("%s\n", str);
//	return 0;
}
