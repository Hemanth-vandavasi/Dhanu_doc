i#include <stdio.h>
#include <string.h>

char* my_string(char *ch, char *str, char freq);

int main() {
	char ch[20];
	char str[10];
	char freq = 0;
	printf("Enter a first string %s\n:", ch);
	fgets(ch, 20, stdin);

	printf("Enter a second string %s\n:", str);
	fgets(str, 30, stdin);
	my_string(ch, str, freq);
}

char* my_string(char *ch, char *str, char freq) {
	int i;
//	int str_len = strlen(str);
	for (i = 0; i < 20 && ch[i] != '\0'; i++) {
		if (str[i] == str)
			freq++;
		str(strlen + 1) = 0 + freq;
		str(strlen + 2) = '\0';
		return str;
	}
}
