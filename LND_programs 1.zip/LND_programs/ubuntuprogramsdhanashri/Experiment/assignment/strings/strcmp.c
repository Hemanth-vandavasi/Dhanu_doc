#include <stdio.h>
#include <string.h>

char* my_string(char *ch, char *str);

int main() {
	char ch[20];
	char str[10];

	printf("Enter a first string %s\n:", ch);
	fgets(ch, 20, stdin);

	printf("Enter a second string %s\n:", str);
	fgets(str, 30, stdin);
	my_string(ch, str);
}

char* my_string(char *ch, char *str) {
	int i;
	for (i = 0; i < 20 && ch[i] != '\0'; i++) {
		ch[i] == str[i];
		return str;
	}
}
