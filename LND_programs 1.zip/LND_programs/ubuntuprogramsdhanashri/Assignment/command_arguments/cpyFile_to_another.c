#include <stdio.h>
#include <stdlib.h>
int main(int argc, char *argv[])
{
	FILE *src, *dest, *fopen();
	int c;
	if (argc != 3) {
		printf("Wrong no. of arguments \n");
		exit(1);
	}
	if ((src = fopen(argv[1], "r")) == NULL) {
		printf("Can't open src file\n");
		exit(1);
	}
	if ((dest = fopen(argv[2], "w")) == NULL) {
		printf("Can't open dest file\n");
		exit(1);
	}
	while ((c = fgetc(src)) != EOF)
		fputc(dest, c);
	fclose(src);
	fclose(dest);
}
