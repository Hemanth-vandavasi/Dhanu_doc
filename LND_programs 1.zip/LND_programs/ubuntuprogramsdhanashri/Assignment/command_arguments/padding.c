#include <stdio.h>
#pragma pack(1)
#if Q == 1
struct size {
	char c;
	double d;
	short s;
}e1;
int main() 
{
	printf("size:%ld",sizeof(e1));
}
#endif
#if Q == 2
struct size {
	char name[10];
	char c;
	short s;
	int b;
	double d;
	long double ld;
	float fq;
//	short s;
};
int main() 
{
	printf("size:%ld",sizeof(struct size));
}
#endif
#if Q == 3
union size {
	char a;
	int b;
}d;
int main() {
	d.a = 'a';
	d.b = 3;
	printf("%d\n", d.a);
}
#endif
#if Q == 4
union size {
	char c;
	short s;
	int j;
}d;
int main() {
	printf("Size : %ld", sizeof(d));
}
#endif
