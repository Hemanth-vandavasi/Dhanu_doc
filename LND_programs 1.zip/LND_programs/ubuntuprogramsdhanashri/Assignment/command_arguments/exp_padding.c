#include <stdio.h>
#include <stdlib.h>
#pragma pack (1)
#if Q == 1
struct ex {
	char q;
	short int b : 12;
	char d;
	int e : 20;
	char h : 2;
}d;
int main() 
{
	printf("%ld\n", sizeof(d));
}
#endif
#if Q == 2
union ed {
	char c ;
	char a ;
	int b ;
	char d;
}d = { 'a' , 'b' , 122 , 'q' };
int main()
{
	printf("%c%c%d" ,d.c , d.a , d.b);
	printf("%ld\n", sizeof(d));
}
#endif
#if Q == 3
struct ex {
	short int a;
	int b : 23;
	char c;
	short d : 10;
	short e : 12;
}d;
int main()
{
	printf("%ld\n", sizeof(d));
}
#endif
#if Q == 4
struct ex {
	int a : 17;
	short b : 12;
	int c : 7;
	char d : 4;
	short f : 12;
	char g : 4;
	int h : 12;
	char i;
}d;
int main()
{
	printf("%ld\n", sizeof(d));
}
#endif

