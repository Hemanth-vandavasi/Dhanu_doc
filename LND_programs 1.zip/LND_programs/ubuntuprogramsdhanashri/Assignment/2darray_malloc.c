#include <stdio.h>
#include <stdlib.h>
#define SIZE 20
#if 0
int main()
{
	int **ptr;
	ptr = (int**) malloc(SIZE * sizeof(int*));
	*ptr = (int*) malloc(SIZE * sizeof(int));
	**ptr = 12;
	printf("%d\n", **ptr);
	return 0;
}
#endif

#if 0
int main() {
	int **ptr;
	int i;
	int j;
	ptr = (int**) malloc(3 * sizeof(int*));
	*ptr = (int*) malloc(3 * sizeof(int));
	for (i = 0; i < 3; i++) {
		*(ptr + i) = (int*) malloc(3 * sizeof(int));
	}
	for (j = 0; j < 1; j++) {
		*(ptr + j) = (int*) malloc(3 * sizeof(int));
	}
	for (i = 0; i < 3; i++) {
		for (j = 0; j < 1; j++) {
			printf("Enter ptr value [%d] [%d] : \n", i, j);
			scanf("%d", *(ptr + i + j));
		}
	}
	for (i = 0; i < 3; i++) {
		for (j = 0; j < 1; j++) {
			printf("Values : %d\n", *(*(ptr + i) + j));
		}
	}
}
#endif
//char* sort_names(char **str, int n);
#if 0

int main() {
	char **str;
	int i;
	int j;
	int num;
	char *temp;
	str = (char**) malloc(20 * sizeof(char*));
	*str = (char*) malloc(3 * sizeof(char));

	printf("Enter the number of string:");
	scanf("%d", &num);

	printf("Enter the names :");
	for (i = 0; i < 6; i++) {
		fgets(str[i], SIZE, stdin);
	}
	
	for (i = 0; i < 5; i++) {
		for (j = i + 1; j < 5; ++j) {
			if (*str[i] > *str[j]) {
				temp = str[i];
				str[i] = str[j];
				str[j] = temp;
			}
		}
	}
	printf("Elements in the ascending order :\n");
	for (i = 0; i < 6; i++) {
		printf("%d\n", str[i]);
	}
	return 0;
}
#endif	

#if 1
int main() 
{
	char **ptr = ((char**) malloc (3 * sizeof(char*)));
	char *temp;
	int i;
//	int num;
	for (i = 0; i < 3; i++) {
		ptr[i] = (char*) malloc(sizeof(char));
	}
//	printf("Enter the number of strings:");
//	scanf("%d", &num);
	
	printf("Enter the names:\n");
	for (i = 0; i < 3; i++) {
		fgets(ptr[i], SIZE, stdin);
	}
	for (i = 0; i < 2; i++) {
		if (*ptr[i] > *ptr[i + 1]) {
			temp = ptr[i];
			ptr[i] = ptr[i + 1];
			ptr[i + 1] = temp;
		}
	}
	printf("Sorted names by ascending order are:\n");
	for (i = 0; i < 3; i++) {
		printf("%s", ptr[i]);
	}
	printf("\n");
	return 0;
}
#endif
#if 0
int main() 
{
	char **ptr = (char**) malloc (3 * sizeof(char*));
//	char *temp;
	int i;
//	int j;
//	int num;
	for (i = 0; i < 3; i++) {
		ptr[i] = (char*) malloc (SIZE * sizeof(char));
	}
	
	printf("Enter the strings:\n");
	for (i = 0; i < 3; i++) {
		fgets(ptr[i], SIZE, stdin);
	}
	for (i = 0; i < 3; i++) {
			printf("%c\n",*(*(ptr + i) + 1));
		//	printf("%c", *(*(ptr + 1) + 1));
		}
	
//	printf("%c\n");
	/*for (i = 0; i < 3; i++) {
		printf("%s", ptr[i]);
	}*/
//	printf("\n");
	for (i = 0; i < 3; i++) {
		free(ptr[i]);
	}
	free(ptr);
	ptr = NULL;
//	return 0;
}
#endif
