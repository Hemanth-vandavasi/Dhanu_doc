#include <stdio.h>
#include <stdlib.h>
#define SIZE 5
void push1();
void push2();
void pop1();
void pop2();
void display1();
void display2();

int arr[SIZE];
//int s2[SIZE];
int t1 = -1;
int t2 = SIZE;
int main() {
	int choice;
	while(1) {
		printf("\n1:push1\n2:pop1\n3:display1\n4:push2\n5:pop2\n6:display2\n7:exit\n");
		printf("Enter the choice : ");
		scanf("%d", &choice);
		switch(choice) {
			case 1 :
				push1();
				break;
			case 2 :
				pop1();
				break;
			case 3 :
				display1();
				break;
			case 4 :
				push2();
				break;
			case 5 :
				pop2();
				break;
			case 6 :
				display2();
				break;
			case 7 :
				exit(1);
				break;
			default :
				printf("Option is not correct\n");
		}
	}
}
void push1() {
	int data;
	if((t1 == SIZE - 1) || (t1 + 1 == t2)) {
			printf("The stack 1 is full");
	} else if (t1 == t2) {
		printf("Overwite");
	} else {
		printf("Enter the data :");
		scanf("%d", &data); 
		t1++;
		arr[t1] = data;
	}
}
void push2() {
	int data;
	if((t2 == -1) || (t2 - 1 == t1)) {
		printf("The stack 2 is full");
	} else if (t2 == t1) {
		printf("Overwrite");
	} else {
		printf("Enter the data :");
		scanf("%d", &data); 
		t2--;
		arr[t2] = data;
	}
}
void pop1() {
	if(t1 == -1) {
		printf("Stack 1 is empty");
	} else {
		t1--;
	}
}
void pop2() {
	if(t2 == SIZE) {
		printf("Stack 2 is empty");
	} else { 
		t2++;
	}
}
void display1() {
	int i;
	for(i = t1; i >= 0; i--) {
		printf("%d\n", arr[i]);
	}
}
void display2() {
	int i;
	for(i = t2; i < SIZE; i++) {
		printf("%d\n", arr[i]);
	}
}
