#include <stdio.h>
#define SIZE 30
int print(int arr[] , int num);
int selection(int arr[], int num);

int main() {
	int arr[SIZE];
    int num;       
	int i;
    printf("Enter the Size of Array :");
    scanf("%d", &num);
    for(i = 0; i < num; i++) {
		printf("Enter the Elements of Array :");
        scanf("%d", &arr[i]);
   	}
	selection(arr, num);
    printf("The sorted elements are :");
    print(arr, num);
    return 0;
}
int selection(int arr[], int num) {
	int i = 0;
	int j = 0;
	int min = 0;
	int temp = 0;
	
	for(i = 0; i < num - 1; i++) {
		min = i;
		for(j = i + 1; j < num; j++) {
			if(arr[j] < arr[min]) {
				min = j;
			}
		}
		
		if(min != i) {
			temp = arr[i];
			arr[i] = arr[min];
			arr[min] = temp;
		}
	}
}
int print(int arr[] , int num) {
        for(int i = 0; i < num; i++) {
                printf("%d ",arr[i]);
        }
}
