#include <stdio.h>
#define SIZE 30

int heap(int arr[], int num);
int max_heapify(int arr[], int num, int i);
int print(int arr[] , int num);

int main() {
	int arr[SIZE];
    int num;       
	int i;
    printf("Enter the Size of Array :");
    scanf("%d", &num);
    for(i = 0; i < num; i++) {
		printf("Enter the Elements of Array :");
        scanf("%d", &arr[i]);
   	}
	heap(arr, num);
    printf("The sorted elements are :");
    print(arr, num);
    return 0;
}
int heap(int arr[], int num) {
	int temp;
	int i;
	for(i = num / 2 - 1; i >= 0; i--) {
		max_heapify(arr, num, i);
	}
	for(i = num - 1; i >= 0; i--) {
		temp = arr[0];
		arr[0] = arr[i];
		arr[i] = temp;
		max_heapify(arr, i, 0);
	}
}
int max_heapify(int arr[], int num, int i) {
	int largest = i;
	int left = 2 * i + 1;
	int right = 2 * i + 2;
	int temp = 0;
	
	if(left < num && arr[left] > arr[largest]) {
		largest = left;
	}
	if(right < num && arr[right] > arr[largest]) {
		largest = right;
	}
	
	if(largest != i) {
		temp = arr[i];
		arr[i] = arr[largest];
		arr[largest] = temp;
		
		max_heapify(arr, num, largest);
	}
}	
int print(int arr[] , int num) {
	for(int i = 0; i < num; i++) {
    	printf("%d ",arr[i]);
    }
	printf("\n");
}
