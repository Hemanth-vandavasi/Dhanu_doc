#include <stdio.h>
#define SIZE 30
int merge_sort(int arr[], int start, int end);
int merge(int arr[], int start,int mid, int end);
int print(int arr[] , int num);

int main() {
	int arr[SIZE];
    int num;       
	int i;
    int start;
    int end;
    int mid;
    printf("Enter the Size of Array :");
    scanf("%d", &num);
    for(i = 0; i < num; i++) {
		printf("Enter the Elements of Array :");
        scanf("%d", &arr[i]);
   	}
    merge_sort(arr, 0, num - 1);
    printf("The sorted elements are :");
    print(arr, num);
    return 0;
}
int merge_sort(int arr[],int start, int end) {
	if(start < end) {
   		int mid = (start + end)/ 2;
        merge_sort(arr, start, mid);  // Left recursion
        merge_sort(arr, mid + 1, end);  // right recursion
        merge(arr, start, mid , end);
    }
}
int merge(int arr[], int start, int mid, int end) {
	int i = start;
    int j = mid + 1;
    int k = start;
    int temp[SIZE];
    while(i <= mid && j <= end) {
		if(arr[i] >= arr[j]) {
        	temp[k] = arr[i];
            i++;
        } else {
          	temp[k] = arr[j];
            j++;
        }
      	k++;
    }
    if(i > mid) {
    	while(j <= end) {
        	temp[k] = arr[j];
           	j++;
            k++;
        }
    } else {
     	 while(i <= mid) {
        	 temp[k] = arr[i];
             i++;
             k++;
         }
     }
     for(k = start; k <= end; k++) {
     	arr[k] = temp[k];
     }
}
int print(int arr[] , int num) {
	for(int i = 0; i < num; i++) {
    	printf("%d ",arr[i]);
    }
}
