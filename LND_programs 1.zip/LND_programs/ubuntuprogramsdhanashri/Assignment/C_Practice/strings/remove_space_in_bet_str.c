#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#define SIZE 50
char*  space(char  *str1);

int main() {
	char *str1 = NULL;

	str1 = (char*) malloc(SIZE * sizeof(char)); //dyanamic memory allocation
	
	if (NULL == str1) {
		printf("Malloc failed !\n");
		exit (0);
	}

	printf("Enter a str1 string :");
	if (NULL == (fgets(str1, SIZE, stdin))) {
		printf("Fgets failed for str1");
	}
	*(str1 + (strlen(str1) - 1)) = '\0';
	printf("string is '%s'\n", str1);
	printf("The final string is :'%s'\n", space(str1));
//	space(str1);
	free(str1);
	str1 = NULL;
	return 0;
}

char* space(char *str1) {
	char *temp = str1 ;
	char *temp1 = str1;

	while(*temp != '\0') {
		if(*temp == ' ') { 
			temp++;
		} else {
			*temp1 = *temp;
			temp1++;
			}
		temp++;
	}
	*temp1 = '\0';
	return str1;
}
