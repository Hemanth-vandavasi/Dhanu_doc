#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#define SIZE 50
char* space(char  *str1);

int main() {
	char *str1 = NULL;

	str1 = (char*) malloc(SIZE * sizeof(char)); //dyanamic memory allocation
	
	if (NULL == str1) {
		printf("Malloc failed !\n");
		exit (0);
	}

	printf("Enter a str1 string :");
	if (NULL == (fgets(str1, SIZE, stdin))) {
		printf("Fgets failed for str1");
	}
	*(str1 + (strlen(str1) - 1)) = '\0';
	printf("string is '%s'\n", str1);
	printf("The final string is :'%s'\n", space(str1));
//	space(str1);
	free(str1);
	str1 = NULL;
	return 0;
}

char* space(char *str1) {
	while(isspace(*str1)) {
//		printf("hi");
		str1++;
	}
	int len = strlen(str1);
	char *end;
	end = str1 + len - 1;
	while(end >= str1 && isspace(*end)) {
//		printf("hi");
		end--;
	}
	*(end + 1) = '\0';
	return str1;
//	printf("'%s'\n", str1);
}

