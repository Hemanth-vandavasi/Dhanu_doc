#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#define SIZE 50
int  strc(char  *str1, char *str2, int len);

int main() {
	char *str1 = NULL;
	char *str2 = NULL;
	int comp;
	int len = 0;

	str1 = (char*) malloc(SIZE * sizeof(char)); //dyanamic memory allocation
	str2 = (char*) malloc(SIZE * sizeof(char));
	
	if (NULL == str1 && NULL == str2) {
		printf("Malloc failed !\n");
		exit (0);
	}

	printf("Enter a str1 string :");
	if (NULL == (fgets(str1, SIZE, stdin))) {
		printf("Fgets failed for str1");
	}
	printf("Enter a str2 string :");
	if (NULL == (fgets(str2, SIZE, stdin))) {
		printf("Fgets failed for str2");
	}
	*(str1 + (strlen(str1) - 1)) = '\0';
	*(str2 + (strlen(str2) - 1)) = '\0';
	
	printf("How many character you want to check :");
	scanf("%d", &len);	

	comp = strc(str1, str2, len);
	if (comp == 1) {
 		printf("The string str1 is greater than string str2 \n");
	} else if (comp == -1) {
		printf("The string str1 is less than string str2 \n");
	} else {
		printf("The string str1 is equal to string str2 \n");
	}
	free(str1);
	free(str2);
	str1 = NULL;
	str2 = NULL;
	return 0;
}

int strc(char *str1, char *str2, int len) {
    unsigned char c1;
	unsigned char c2;
    do {
        c1 = *str1++;
        c2 = *str2++;
       /* if(!c1 || !c2) {
            return -1;
        }
        if (c1 == c2) {
            continue;
        }*/
        c1 = tolower(c1);
        c2 = tolower(c2);
		if(c1 == c2) {
			return 0;
		} else if(c1 > c2) {
            return 1;
        } else {
			return -1;
		}
    } while(--len);
 //   return 0;
}
