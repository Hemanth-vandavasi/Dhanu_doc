#include<stdio.h>
#include<stdlib.h>
struct node
{
    int data;
    struct node *left;
    struct node *right;
};
//struct node *root = NULL;
struct node* create_node(int data);
struct node* createInsert(struct node* root, int num);
struct node* search_node(struct node *root,int data);
void inorder(struct node *root);
struct node *delete(struct node *root, int data);
struct node *Pre(struct node *root); 
int main()
{
	struct node *root = NULL;
    int data;
    int option;
    struct node *temp;

    while(1)
    {
        printf("\n");
		printf("1. Create a tree \n");
        printf("2. Insert an element into tree\n");
        printf("3. Search an element in the tree\n");
        printf("4. Traverse in inorder in the tree\n");
		printf("5. Delete a element in the tree\n");
        printf("6. Exit\n");
        printf("Enter your option : ");
        scanf("%d", &option);
        switch(option)
        {
		case 1:
			printf("Enter a data :");
			scanf("%d", &data);
			root = create_node(data);
			break;
        case 2:
            printf("Enter the data to be inserted : ");
            scanf("%d", &data);
            root = createInsert(root, data);
            break;
        case 3:
            printf("Enter the data to be searched : ");
            scanf("%d", &data);
            temp = search_node(root,data);
            if(temp != NULL)
            {
                printf("Data %d is present in the tree\n", temp->data);
            }
            else
            {
                printf("Data %d is not present in the tree\n", data);
            }
            break;
            case 4:
            {
                printf("Traverse in inorder in the tree :");
                inorder(root);
				break;
            }
		case 5:
		{
			printf("Delete a element in the tree :");
			scanf("%d", &data);
			root = delete(root, data);
			break;
		}
        case 6:
            exit(0);
            break;
        default:
            printf("Invalid option\n");
            break;
        }
    }
    return 0;
}
struct node* create_node(int data)
{
    struct node *new_node;  
	new_node = (struct node*)malloc(sizeof(struct node));
    new_node->data = data;
    new_node->left = NULL;
    new_node->right = NULL;

    return new_node;
//	free(new_node);
}
/*struct node* insert_node(struct node * root,int data)
{
    struct node *temp_node = NULL;
    struct node *current_node = NULL;
    struct node *parent_node = NULL;

    temp_node = create_node(data);

    if(root == NULL)
    {
        root = temp_node;
    }
    else
    {
        current_node = root;
        parent_node = NULL;

        while(1)
        {
            parent_node = current_node;

            if(data <= parent_node->data)
            {
                current_node = current_node->left;

                if(current_node == NULL)
                {
                    parent_node->left = temp_node;
                    return root;
                }
            }
            else
            {
                current_node = current_node->right;

                if(current_node == NULL)
                {
                    parent_node->right = temp_node;
                    return root;
                }
            }
        }
    }*/
struct node* createInsert(struct node* root, int num)
{
        if(root == NULL){
                root = (struct node*)malloc(sizeof(struct node));
                root->left = root->right = NULL;
                root -> data = num;
                return root;
        } else {
                if(num < root->data) {
                        root->left = createInsert(root->left, num);
                }else if(num > root->data) {
                        root->right = createInsert(root->right, num);
                } else {
                        printf("Duplicate element not Allowed\n");
                }
                return root;
        }
}
struct node* search_node(struct node* root,int data)
{
    struct node *current_node = root;
    /*if(root == NULL)
    {
        printf("Tree is empty\n");
        return NULL;
    }
    else
    {
        while(current_node->data != data)
        {
            if(current_node != NULL)
            {
                if(data < current_node->data)
                {
                    current_node = current_node->left;
                }
                else
                {
                    current_node = current_node->right;
                }

                if(current_node == NULL)
                {
                    return NULL;
                }
            }
        }
    }
    return current_node;*/
	if(root == NULL) {
		return NULL;
	}
	if (root -> data == data) {
		return root;
	}
	else if(data < root -> data)	{
		return search_node(root -> left, data);
	}
	else if(data > root -> data) {
		return search_node(root -> right, data);
	}
}
struct node *delete(struct node *root, int data)
{
	if(root == NULL) {
		return root;
	}
	else if( data < root -> data) {
		root -> left = delete(root -> left, data);
	}
	else if(data > root -> data) {
		root -> right = delete(root -> right, data);
	}
	else {
		if(root -> left == NULL && root -> right == NULL) {
			free(root);
			root = NULL;
		}
		else if(root -> left == NULL) {
			struct node* temp = root;
			root = root -> right;
			free(temp);
			temp = NULL;
		}
		else if(root -> right == NULL) {
			struct node *temp2 = root;
			root = root -> left;
			free(temp2);
			temp2 = NULL;
		}
		else {
			struct node* temp3;
			temp3 = Pre(root);
			root -> data = temp3 -> data;
			delete(root -> left, temp3 -> data);
		}
	}
	return root;
}
struct node *Pre(struct node*root) 
{
	root = root -> left;
	while (root -> right != NULL) {
		root = root -> right;
	}
	return root;
}

void inorder(struct node *root) {
    if(root != NULL) {
    inorder(root->left);
    printf(" %d ", root->data);
    inorder(root->right);
	}
}
