#include <stdio.h>
#include <stdlib.h>
struct node {
	int data;
	struct node *left;
	struct node *right;
};
//struct node *head;
struct node *create();
void Preorder(struct node *head);
void Inorder(struct node *head);
void Postorder(struct node *head);
int main() 
{
	struct node *head;
	head = create();
	printf("Preorder is :");
	Preorder(head);
	printf("Inorder is :");
	Inorder(head);
	printf("Postorder is :");
	Postorder(head);
}
struct node *create()
{
	int x;
	struct node *newnode;
	newnode = (struct node*) malloc(sizeof(struct node)); // create a malloc
	printf("Enter data (-1 for no node) :"); // insertion of data, (-1 is for change to left side to right side node)
	scanf("%d", &x);
	if(x == -1) {
		return 0; 
	}
	newnode -> data = x;
	printf("Enter left child of %d\n", x);
	newnode -> left = create();
	printf("Enter right child of %d\n", x);
	newnode -> right = create();
	return newnode;
	free (newnode);
}
void Preorder(struct node *head)
{
	if (head == NULL) {
		return;
	}
	printf(" %d ", head -> data);
	Preorder(head -> left);
	Preorder(head -> right);
}
void Inorder(struct node *head)
{
	if (head == NULL) {
		return;
	}
	Inorder(head -> left);
	printf(" %d ", head -> data);
	Inorder(head -> right);
}
void Postorder(struct node *head)
{
	if (head == NULL) {
		return;
	}
	Postorder(head -> left);
	Postorder(head -> right);
	printf(" %d ", head -> data);
}

