#include <stdio.h>
#include <stdlib.h>
struct node {
	int data;
	struct node *left; // for left side of node
	struct node *right; // for right side of node
};
struct node *create()
{
	int x;
	int data;
	struct node *newnode;
	newnode = (struct node*) malloc(sizeof(struct node)); // create a malloc
	printf("Enter data (-1 for no node) :"); // insertion of data, (-1 is for change to left side to right side node)
	scanf("%d", &x);
	if(x == -1) {
		return 0; 
	}
	newnode -> data = x;
	printf("Enter left child of %d\n", x);
	newnode -> left = create();
	printf("Enter right child of %d\n", x);
	newnode -> right = create();
	return newnode;
	free (newnode);
}
void main()
{
	struct node * head;
	head = 0;
	head = create();
}
