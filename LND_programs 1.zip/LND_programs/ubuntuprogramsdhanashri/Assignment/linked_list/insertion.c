#include <stdio.h>
#include <stdlib.h>
#if Q == 1
struct node {
	int data;
	struct node *link;
};
int main()
{
	struct node *head;
	struct node *newnode;
	newnode = (struct node*) malloc(sizeof(struct node));
	while(choice) {
	printf("Enter data :\n");
	scanf("%d", &newnode -> data);

	newnode -> link = 0;
	if (head == 0) {
		head = newnode;
	}
	else {
		head -> link = newnode;
	}

	printf("Enter data you want to insert :");
	scanf("%d", &newnode -> data);

	newnode -> link = head;
	head = newnode;

}
#endif
#if Q == 2
struct node {
	int data;
	struct node * link;
};
int main() 
{
	struct node *head;
	struct node * newnode;
	struct node * temp;
	int choice;
	
	while (choice) {
		newnode = (struct node*)malloc(sizeof(struct node));
		printf("Enter data :\n");
		scanf("%d", &newnode -> data);

		newnode -> link = NULL;

		if (head == NULL) {
			head = temp = newnode;
		}
		else {
			temp -> link = newnode;
			temp = newnode;
		}
		printf("Do you want to continue (0,1)\n");
		scanf("%d", &choice);
	}
/*	printf("Enter data you want to insert :");
	scanf("%d", &newnode -> data);

	newnode -> link = head;
	head = newnode;*/
	
	temp = head;
	while (temp != 0) {
		printf("The given data is :%d\n", temp -> data);
		temp = temp -> link;
	//	return 0;
	}
	printf("Enter data you want to insert :");
	scanf("%d", &newnode -> data);

	newnode -> link = head;
	head = newnode;
	printf("After insertion the data is :%d\n", head -> data);
	return 0;
}
#endif
