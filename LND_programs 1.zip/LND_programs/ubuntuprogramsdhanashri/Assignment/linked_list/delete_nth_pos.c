#include <stdio.h>
#include <stdlib.h>
struct node {
	int data;
	struct node * next;
};

struct node * head; // node point to the head
void create(int num);
void Delete(int pos);
void Print();

int main()
{
	head = NULL;   //Intially the list is empty.
	int num;
	printf("How many numbers?\n");
	scanf("%d", &num);

	create(num);
	Print();
	int pos;
	printf("Enter the pos: ");
	scanf("%d", &pos);
	Delete(pos);
	Print();
	return 0;
}

void create(int num)
{
	struct node *ptr;
	int index;
	int data;
	for (index = 0; index < num; index++) {
		printf("Enter the data: ");
		scanf("%d", &data);
		ptr = (struct node *)malloc(sizeof(struct node));
		ptr -> data = data;
		ptr -> next = NULL;
		if (head == NULL)	{
		head = ptr;
		} else {
			struct node *temp = head;
			while (temp -> next != NULL) {
				temp = temp -> next;
			}
			temp -> next = ptr;
		}
	}
}

void Delete(int pos)
{
	struct node * temp = head;
	if ( pos == 1) {
		head = temp -> next;  // Now head points to the next node.. Here this is also valid (*temp1).next
		free(temp); 
		return;
	}
	for (int i = 0; i < pos - 1; i++) {
		temp = temp -> next;   // temp1 points to the (pos - 1th) postion
	}
	struct node * temp1 = temp -> next;  // (pos)th node
	temp -> next = temp1 -> next;  // (pos + 1) node
	free(temp1);   // Delete temp2
}

void Print()
{
	struct node * temp = head;
	while (temp != NULL) {
		printf(" %d ", temp -> data);
		temp = temp -> next;
	}
	printf("\n");
}
