#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define SIZE 32
struct Node {
	int id;
    char name[SIZE];
    char lsname[SIZE];
    char gender[SIZE];
    char ocupation[SIZE];
    int age;
    struct Node *next;
};
//typedef struct clubmembership node;
struct Node *head = NULL;
/* declaration of functions */
void gettingvalues(struct Node );
struct Node* List1(FILE *);
struct Node* List2(FILE *);
struct Node* List3(FILE *);
struct Node* List4(FILE *);
void print(struct Node *);
void freeList(struct Node *);
struct Node* sort(struct Node *);
int main()
{
	FILE *fp = NULL;
    /* opening a file */
    fp = fopen("club_Members_record.txt", "r");

    /* condition for opening file */
    if (fp == NULL) {
		printf("File is not open\n");
        exit(1);
    }
	/* for creating a list1 age 21 - 30 */
    printf("\n\n----- List Age (21 - 30) -------\n\n");
    head = List1(fp);
    print(head);
    freeList(head);
    head = NULL;
	/* for creating a list1 age 31 - 40 */
    printf("\n\n----- List Age (31 - 40) -------\n\n");
    head = List2(fp);
    print(head);
    freeList(head);
    head = NULL;
	/* for creating a list1 age 41 - 50 */
    printf("\n\n----- List Age (41 - 50) -------\n\n");
    head = List3(fp);
    print(head);
    freeList(head);
    head = NULL;
	/* for creating a list1 age 51 - 60 */
    printf("\n\n----- List Age (51 - 60) -------\n\n");
    head = List4(fp);
    print(head);
	
	fclose(fp);
	freeList(head);
    head = NULL;
	return 0;
}
void getingvalues(struct Node member)
{
	struct Node *newNode = (struct Node *) malloc (sizeof(struct  Node));
    newNode->id = member.id;
    strcpy(newNode->name, member.name);
    strcpy(newNode->lsname, member.lsname);
    strcpy(newNode->gender, member.gender);
    strcpy(newNode->ocupation, member.ocupation);
    newNode->age = member.age;
    newNode->next = NULL;
	if (head == NULL) {
		head = newNode;
    }
	else {
		struct Node *temp1 = NULL;
        temp1 = head;
        while (temp1 -> next != NULL) {
        	temp1 = temp1 -> next;
        }
        temp1 -> next = newNode;
	}
}
struct Node* List1(FILE *fp)
{
	/* creation o object so that we can acces each members */
	 struct Node member;

    /* we are using fscanf for reading data into file and store all data in
         one node */
    fseek(fp, 0, SEEK_SET);
    while (fscanf(fp, "%d %s %s %s %s %d", &member.id, member.name, \
                                member.lsname, member.gender,\
                                member.ocupation, &member.age) != EOF) {
		if (member.age >= 21 && member.age <= 30) {
			getingvalues(member);
        }
    }
    return head;
}
struct Node* List2(FILE *fp)
{
 /* creation o object so that we can acces each members */
	struct Node member;
    fseek(fp,0,SEEK_SET);
    /* we are using fscanf for reading data into file and store all data in
         one node */
    while (fscanf(fp, "%d %s %s %s %s %d", &member.id, member.name, \
                                member.lsname, member.gender,\
                                member.ocupation, &member.age) != EOF) {
		if (member.age >= 31 && member.age <= 40) {
			getingvalues(member);
        
        }
	}
    fseek(fp, 0, SEEK_SET);
    return head;
}
struct Node* List3(FILE *fp)
{
	/* creation o object so that we can acces each members */
	struct Node member;
   /* we are using fscanf for reading data into file and store all data in
         one node */
    while (fscanf(fp, "%d %s %s %s %s %d", &member.id, member.name, \
                                member.lsname, member.gender,\
                                member.ocupation, &member.age) != EOF) {
		if (member.age >= 41 && member.age <= 50) {
			getingvalues(member);
        }
    }
	fseek(fp, 0, SEEK_SET);
    return head;
}
struct Node* List4(FILE *fp)
{
	struct Node member;
    while (fscanf(fp, "%d %s %s %s %s %d", &member.id, member.name, \
                                member.lsname, member.gender,  \
                                member.ocupation, &member.age) != EOF) {
		if (member.age >= 51 && member.age <= 60) {
			getingvalues(member);
        }
    }
    return head;
}
void print(struct Node *temp)
{
	if (temp == NULL) {
		printf("List is empty !\n\n");
    } 
	else {
		while (temp != NULL) {
			printf("%d\t\t", temp->id);
            printf("%s ", temp->name);
            printf("%s\t\t", temp->lsname);
            printf("%s\t\t", temp->gender);
            printf("%s\t\t", temp->ocupation);
            printf("%d\t\t", temp->age);
            temp = temp->next;
            printf("\n");
		}
	}
}
void freeList(struct Node *head)
{
	struct Node *temp = NULL;
    while (head != NULL) {
		temp = head;
        head = head->next;
        free(temp);
    }
}
