#include <stdio.h>
#include <stdlib.h>
#include<string.h>
#define SIZE 32
struct Node {
    int id;
    char name[SIZE];
    char lname[SIZE];
    char gender[SIZE];
    char occupation[SIZE];
    int age;
	struct Node* prev;
    struct Node* next;
};
//store the list of records in a circular doubly linked list. Print all entries in the DLL
struct Node* create(struct Node*, FILE*);
void printList(struct Node *head);
void freelist(struct Node *head);
int main()
{
    FILE *fp = NULL;
//	struct Node* newNode, *temp;
    struct Node* head = NULL;
    fp = fopen("club_Members_record.txt", "r");
    if (fp == NULL) {
        printf("Error! Could not read the file.");
        exit(1);
    }
    head = create(head, fp);
    printList(head);
	freelist(head);
    fclose(fp);
    head = NULL;
    return 0;
}
struct Node *create(struct Node *head,  FILE *fp)
{
        head = NULL;
        struct Node mem;
        struct Node* temp = NULL;
		while (fscanf(fp, "%d %s %s %s %s %d", &mem.id, mem.name, mem.lname, mem.gender, mem.occupation, &mem.age) != EOF) {
        	struct Node* newNode;
        	newNode = (struct Node*)malloc(sizeof(struct Node));
        	newNode -> id = mem.id;
        	strcpy(newNode -> name, mem.name);
        	strcpy(newNode->lname, mem.lname);
        	strcpy(newNode -> gender, mem.gender);
        	strcpy(newNode -> occupation, mem.occupation);
        	newNode -> age = mem.age;
        	newNode -> next = NULL;
        	if(head == NULL) {
				head = newNode;
				temp = newNode;
        	} else {
				temp = temp -> next;
				temp -> next = newNode;
				newNode -> prev = temp;
			}
			newNode -> next = head;
		}
        return head;
		//free(newNode);
}
void printList(struct Node *head )
{
    struct Node* temp = head;
    while (temp != NULL) {
        	printf("%d\t", temp -> id);
        	printf("%-10s\t", temp -> name);
        	printf("%-10s\t", temp -> lname);
        	printf("%-10s\t", temp -> gender);
        	printf("%-10s\t", temp -> occupation);
        	printf("%d\n", temp -> age);
        	temp = temp -> next;
                if(temp == head) {
                        break;
                }
        }
}
void freelist(struct Node *head)
{
        struct Node *newNode = head;
		struct Node *temp;
        do {
                temp = newNode;
                newNode = newNode -> next;
                free(temp);
                temp = NULL;
        } while (head != newNode);
}
