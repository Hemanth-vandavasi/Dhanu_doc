#include <stdio.h>
#include <stdlib.h>
#include<string.h>
#define SIZE 32
struct Node {
    int id;
    char name[SIZE];
    char lname[SIZE];
    char gender[SIZE];
    char occupation[SIZE];
    int age;
    struct Node* prev;
    struct Node* next;
};
//struct Node* head = NULL;
struct Node  *create(struct Node *head, FILE *fp);
void deleteAlt(struct Node *head);
void printList(struct Node *head);
void freelist(struct Node *head);
int main()
{
    FILE *fp = NULL;
    struct Node* head = NULL;
    fp = fopen("club_Members_record.txt", "r");
    if (fp == NULL) {
        printf("Error! Could not read the file.");
        exit(1);
    }
    head = create(head, fp);
	deleteAlt(head);
    printList(head);
    fclose(fp);
    freelist(head);
    head = NULL;
    return 0;
}
struct Node *create(struct Node *head,  FILE *fp)
{
    struct Node mem;
    while (fscanf(fp, "%d %s %s %s %s %d", &mem.id, mem.name,mem.lname, mem.gender, mem.occupation, &mem.age) != EOF)  {
    	struct Node* newNode;
    	struct Node* temp = head;
    	newNode = (struct Node*)malloc(sizeof(struct Node));
    	newNode -> id = mem.id;
    	strcpy(newNode -> name, mem.name);
    	strcpy(newNode->lname, mem.lname);
    	strcpy(newNode -> gender, mem.gender);
    	strcpy(newNode -> occupation, mem.occupation);
    	newNode -> age = mem.age;
    	newNode -> next = NULL;
    	if(head == NULL) {
			newNode -> prev = NULL;
        	head = newNode;
    	} else {
			while(temp -> next != NULL) {
				temp = temp -> next;
        	}
        	temp -> next = newNode;
        	newNode -> prev = temp;
     	 }
	}	
    return head;
}
void deleteAlt(struct Node *head)
{
	if (head == NULL)
		return;
	struct Node *temp = head;
    struct Node *newNode = head -> next;
    while(temp != NULL && newNode != NULL) {
		temp -> next = newNode -> next;
        free(newNode);
        temp = temp -> next;
        if (temp != NULL)
			newNode = temp -> next;
	}
}
void printList(struct Node *head)
{
    struct Node* temp = head;
    if (temp == NULL) {
		printf("List is empty!");
    } else {
		while (temp != NULL) {
			printf("%d\t", temp -> id);
            printf("%-10s\t", temp -> name);
            printf("%-10s\t", temp -> lname);
            printf("%-10s\t", temp -> gender);
            printf("%-10s\t", temp -> occupation);
            printf("%d\t", temp -> age);
            temp = temp -> next;
            printf("\n");
       }
    }
}
void freelist(struct Node *head)
{
	struct Node *temp;
    while(head != NULL) {
        temp = head;
        head =  head -> next;
        free(temp);
        temp = NULL;
    }
}
