#include <stdio.h>
#include <stdlib.h>
#include<string.h>
#define SIZE 32
struct Node {
    int id;
    char name[SIZE];
    char lname[SIZE];
    char gender[SIZE];
    char occupation[SIZE];
    int age;
    struct Node* next;
};
//store the list of records in a circular singly linked list. Print all entries in the DLL
struct Node* create(struct Node*, FILE*);
void DeleteAlt(struct Node *head);
void printList(struct Node *head);
void freelist(struct Node *head);
int main()
{
    FILE *fp = NULL;
    struct Node* head = NULL;
    fp = fopen("club_Members_record.txt", "r");
    if (fp == NULL) {
        printf("Error! Could not read the file.");
        exit(1);
    }
    head = create(head, fp);
    printList(head);
//      DeleteAlt(head);
  //  printList(head);
    fclose(fp);
    freelist(head);
    head = NULL;
    return 0;
}
struct Node *create(struct Node *head,  FILE *fp)
{
//    head = NULL;
    struct Node mem;
    struct Node* newNode;
    struct Node* temp = NULL;
    while (fscanf(fp, "%d %s %s %s %s %d", &mem.id, mem.name, mem.lname, mem.gender, mem.occupation, &mem.age) != EOF) {
        newNode = (struct Node*)malloc(sizeof(struct Node));
        newNode -> id = mem.id;
        strcpy(newNode -> name, mem.name);
        strcpy(newNode->lname, mem.lname);
        strcpy(newNode -> gender, mem.gender);
        strcpy(newNode -> occupation, mem.occupation);
        newNode -> age = mem.age;
        newNode -> next = NULL;
        if(head == NULL) {
            head = newNode;
            temp = newNode;
      //      temp -> next = head;
        } else {
            temp -> next = newNode;
            temp = temp->next;
          }
//      temp -> next = head;
//      newNode -> next = head;
//      return head;
        }
        temp -> next = head;
        return head;
//        free(newNode);
}
void DeleteAlt(struct Node* head)
{
//      struct Node* head1 = head;
        if (head == NULL) {
            return;
        }
        struct Node *temp = head;
        struct Node *newNode = head->next;
        while (temp != NULL && newNode != NULL) {
                // Change next link of previous node
                temp -> next = newNode -> next;
                free(newNode);
                newNode = NULL;
                temp = temp -> next;
//              free(temp);
                if (temp != head) {
                      newNode = temp -> next;
            }
//            free(temp);
        }
}
void printList(struct Node *head )
{
    struct Node* temp = head;
    while (temp != NULL ) {
        printf("%d\t", temp -> id);
        printf("%-10s\t", temp -> name);
        printf("%-10s\t", temp -> lname);
        printf("%-10s\t", temp -> gender);
        printf("%-10s\t", temp -> occupation);
        printf("%d\n", temp -> age);
        temp = temp -> next -> next;
                if(temp == head) {
                        break;
        }
//      printf("\n");
        }
}
void freelist(struct Node *head)
{
    struct Node *newNode = head;
    struct Node *temp;
    do {
        temp = newNode;
        newNode = newNode -> next;
        free(temp);
        temp = NULL;
    } while (head != newNode);
}
