#include <stdio.h>
#include <stdlib.h>
#if Q==1
struct employee {
	char *name;
	char gender; 

	float sal;
	struct employee *link;
};

int main()
{
	struct employee *head = malloc(sizeof(struct employee));
	head -> name = "Dhanashri";
	head -> link = NULL;

	struct employee *current = malloc(sizeof(struct employee));
	current -> gender = 'F';
	current -> link = NULL;
	head -> link = current;

	struct employee *current2 = malloc(sizeof(struct employee));
	current2 -> sal = 14000;
	current2 -> link = NULL;
	current -> link = current2;

	printf("%s %c %f\n", head->name, current->gender, current2->sal);
	return 0;
}
#endif

#if Q==2
struct employee {
	char *name;
	char gender;
	float sal;
	struct employee *link;
};

int main()
{
	struct employee *head = malloc(sizeof(struct employee));
//	printf("Enter the name :");
//	scanf("%s", head->name);
	head -> name;
	head -> link = NULL;
	printf("Enter the name :");
	scanf("%s",&head->name);
	

	struct employee *current = malloc(sizeof(struct employee));
//	printf("Enter the gender :");
//	scanf("%c", &current->gender);
	current -> gender;
	current -> link = NULL;
	head -> link = current;
	printf("Enter the gender :");
	scanf("%c", &current->gender);
	

	struct employee *current2 = malloc(sizeof(struct employee));
//	printf("Enter the salary :");
//	scanf("%f", &current2->sal);
	current2 -> sal;
	current2 -> link = NULL;
	current -> link = current2;
	printf("Enter the salary :");
	scanf("%f", &current2->sal);
	

	printf("%s %c %f\n", head->name, current->gender, current2->sal);
	return 0;
}
#endif

#if Q == 3

struct employee {        
	char *name;       
	char gender;       	
	float salary;        
	struct employee *link;
};

void printlist(struct employee* n);
int main()
{
	struct employee *e1 = (struct employee *)malloc(sizeof(struct employee));        
	struct employee *e2 = (struct employee *)malloc(sizeof(struct employee));        
	struct employee *e3 = (struct employee *)malloc(sizeof(struct employee));
	struct employee eptr;        
	eptr.name = (char *)malloc(sizeof(struct employee));        
	// first node        
	e1->name = "dhanashree";        
	e1->gender = 'f';        
	e1->salary = 100000;        
	e1->link = e2;

	//second node       
	e2->name = "vishal;";
	e2->gender = 'm';
	e2->salary = 200000;
	e2->link = e3;
	
	// third node
	e3->name = "ankit";
	e3->gender = 'm';
	e3->salary = 300000;
	e3->link = NULL;
	
	printlist(e1);
	free(e1);
	free(e2);
	free(e3);
	free(eptr.name);
}
void printlist(struct employee* n)
{	
	while (n != NULL) {
		printf("%s %c %f \t", n->name, n->gender, n->salary);
	//      n = n->link;
	 }
}
#endif




