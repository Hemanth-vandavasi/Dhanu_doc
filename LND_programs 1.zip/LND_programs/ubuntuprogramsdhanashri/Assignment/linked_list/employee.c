#include<stdio.h> 
#include<stdlib.h>
#include <stdio_ext.h>

// structure for employee data 
struct employee { 
	int id; 
	char *name;
	char gender;
	float salary; 
	struct employee *ptr; 
}; 
typedef struct employee emp; 
emp *head = NULL;	 
// function to create employee data 
void create() 
{ 
	emp *temp, *curr; 
	temp = (emp*)malloc(sizeof(emp));
//	__fpurge(stdin);
	printf("\nEnter employee id: "); 
	scanf("%d", &temp->id); 
	printf("\nEnter employee name: "); 
	temp->name = (char*) malloc(sizeof(char));
	scanf("%s", temp->name);
	__fpurge(stdin);
	printf("\nEnter employee Gender: ");
	scanf("%c", &temp->gender);
	printf("\nEnter employee salary: "); 
	scanf("%f", &temp->salary); 

	temp->ptr = NULL; 
	if (head == NULL) 
	{ 
		head = temp; 
	} 
	else
	{ 
		curr = head; 
		while (curr->ptr != 0) 
		{ 
			curr = curr->ptr; 
		} 
		curr->ptr = temp; 
	} 
}
// function to display employee data
void display()
{ 
	emp *curr;
	printf("\nEmployee data:\n");																																	
	printf("ID\tName\tGender\tSalary\n"); 
	curr = head; 
	while (curr != NULL) { 
		printf("%d\t %s\t %c\t %.2f\n", curr->id, curr->name, curr->gender, curr->salary); 
		curr = curr->ptr; 
	} 
}
// main function 
int main()
{ 
	int ch; 									
	while (1) 
	{ 
		printf("\nEmployee Database\n"); 
		printf("1. Create\n2. Display\n3. Exit\n"); 
		printf("Enter your choice: "); 
		scanf("%d", &ch); 
		switch (ch) 
		{ 
			case 1:	create(); 
				break; 
			case 2:	display(); 
				break; 
			case 3:	return 0; 
			default:printf("\nInvalid choice!\n"); 
		}
	} 
	return 0; 
}
