#include <stdio.h>
#include <stdlib.h>
#if Q == 1
struct node {
	int data;
	struct node * link;
};
int main() 
{
	struct node *head;
	struct node * newnode;
	struct node * temp;
	int choice;
	
	newnode = (struct node*)malloc(sizeof(struct node));
	printf("Enter data :\n");
	scanf("%d", &newnode -> data);

	newnode -> link = 0;

	if (head == 0) {
		head = temp = newnode;
	}
	else {
		temp -> link = newnode;
		temp = newnode;
	}
	printf("The given data is : %d\n", temp->data); 
	return 0;
}
#endif

#if Q == 2
struct node {
	int data;
	struct node * link;
};
int main() 
{
	struct node *head;
	struct node * newnode;
	struct node * temp;
	int choice;
	
	while (choice) {
		newnode = (struct node*)malloc(sizeof(struct node));
		printf("Enter data :\n");
		scanf("%d", &newnode -> data);

		newnode -> link = 0;

		if (head == 0) {
			head = temp = newnode;
		}
		else {
			temp -> link = newnode;
			temp = newnode;
		}
		printf("Do you want to continue (0,1)\n");
		scanf("%d", &choice);
	}
	temp = head;
	while (temp != 0) {
		printf("The given data is :%d\n", temp -> data);
		temp = temp -> link;
	//	return 0;
	}
//	printf("The given data is :%d\n", newnode->data);
	return 0;
}
#endif
#if Q == 3
struct node {
	int data;
	struct node * link;
};
int main() 
{
	struct node *head;
	struct node * newnode;
	struct node * temp;
	int choice;
	int count = 0;
	
	while (choice) {
		newnode = (struct node*)malloc(sizeof(struct node));
		printf("Enter data :\n");
		scanf("%d", &newnode -> data);

		newnode -> link = 0;

		if (head == 0) {
			head = temp = newnode;
		}
		else {
			temp -> link = newnode;
			temp = newnode;
		}
		printf("Do you want to continue (0,1)\n");
		scanf("%d", &choice);
	}
	temp = head;
	while (temp != 0) {
		printf("The given data is :%d\n", temp -> data);
		temp = temp -> link;
		count++;
//		printf("The count is :%d", count);
	}
	printf("The count is :%d", count);
	return 0;
}
#endif
