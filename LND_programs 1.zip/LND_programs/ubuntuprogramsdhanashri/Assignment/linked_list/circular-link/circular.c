#include <stdio.h>
#include <stdlib.h>
struct node {
    int data;
    struct node *next;
};

void display(struct node *);
struct node *create_node();
struct node *create_list(struct node *);
int count_node(struct node *);

struct node *insert_first(struct node *);
struct node *insert_end(struct node *);
struct node *insert_pos(struct node *);

struct node *del_first(struct node *);
struct node *del_last(struct node *);
struct node *del_pos(struct node *);

//struct node *head = NULL;
int main()
{
        struct node *head = NULL;
    int ch;
    while (1) {
        printf("\n\n");
        printf("Circular linked list operation \n");
        printf("1. Print circular single linked list \n");
        printf("2. Create Linked list \n");
        printf("3. Insert node at begin \n");
        printf("4. Insert node at end position \n");
        printf("5. Insert node at specific position \n");
        printf("6. Delete first node \n");
        printf("7. Delete last node \n");
        printf("8. Delete node specific position \n");
        printf("9. Exit \n");
		printf("<------------------------------------------>");

        printf("\n\n");
            //taking input for choice
        printf("Enter the choice: ");
        scanf("%d", &ch);
        switch(ch) {

                //Display list
        case 1:
                display(head);
            int c = count_node(head);
            printf("%d", c);
            break;

            //Create no of node
            case 2:
                head = create_list(head);
                break;

            //add node begin
            case 3:
                head = insert_first(head);
                break;

            //add node end position
            case 4:
                head = insert_end(head);
                break;

            //Insert node nth position
            case 5:
                head = insert_pos(head);
                break;

            //Delete first node
            case 6:
                head = del_first(head);
                break;

            //Delete last node
            case 7:
                 head = del_last(head);
                break;

                        //Delete node nth position
            case 8:
                head = del_pos(head);
                break;

                        //Exit
            case 9:
                exit(0);

            default:
                printf("Enter wrong choice \n");
                }
        }
    free(head);
    head = NULL;
    return 0;

}
//Delete node nth position
struct node *del_pos(struct node *head)
{
        int pos;
        int index;
        int count;
        printf("Enter the delete position: ");
        scanf("%d", &pos);

        count = count_node(head);

        struct node *temp = head;
        struct node *prev;
        if (head == NULL) {
                printf("List is empty \n");
        } else if (pos == 0) {
                head = del_first(head);
        } else if (temp->next == head ) {
                head  = del_last(head);
        } else if (count > pos) {
                for (index = 0; index < pos; index++) {
                        prev = temp;
                        temp = temp->next;
                }
                prev->next  = temp->next;
                return head;
        } else {
                printf("Invalid index %d \n" ,pos);
        }
	    return head;
}
//Delete last node
struct node *del_last(struct node *head)
{
        if (head == NULL) {
                printf("List is empty \n");
                return 0;
        }

        struct node *prev;
        struct node *temp = head;

        if (temp->next == head) {
        //      head = NULL;
                free(temp);
                temp = NULL;

                return 0;
        } else {
                while (temp->next != head) {
                        prev = temp;
                        temp = temp->next;
                }
                prev->next = head;
                free(temp);
                temp = NULL;

                return head;
        }
//      return head;
}
//Delete first node
struct node *del_first(struct node *head)
{
        if (head == NULL) {
                printf("List is empty \n");
                return NULL;
        }

        struct node *temp = head;
        struct node *last = head;

        if (temp->next == head) {

                free(temp);
                temp = NULL;
                return NULL;
        } else {

                //read last node
                while (last->next != head) {
                        last = last->next;
                }
                head = temp->next;
                last->next = head;
                free(temp);
                temp = NULL;
         return head;
        }
        return head;

}
//Count node
int count_node(struct node *head)
{
        int count  = 1;
        struct node *ptr = head;
        if (head == NULL) {
                return 0;
        }
        while (ptr->next != head) {
                count++;
                ptr = ptr->next;
        }
        return count;
}
//Insert specific position
struct node* insert_pos(struct node *head)
{
        struct node *ptr;
        //Create node
        ptr = create_node();

        int index = 0;
        int pos;

        //tkaing position
        printf("Enter the insert position to insert node: ");
        scanf("%d", &pos);
        struct node *temp = head;
        struct node *temp2;
        while (temp->next != head) {
                if (index == (pos - 1)) {
                        //previous address assign to temp
                        temp2 = temp->next;
                        //new node link with next node
                        ptr->next = temp2;
                        //old node link with new node
                        temp->next = ptr;
                        return head;
                        break;
                } else {
                        temp = temp->next;
                        index++;
                }
        }
        return head;
        //break;
}
//Insert node at end position
struct node *insert_end(struct node *head)
{
        struct node *ptr;
        struct node *temp;
        //create node
        ptr = create_node();

        if (head == NULL) {
                head = ptr;
                ptr->next = head;
        } else {
                temp = head;
                //Read last node
                while (temp->next != head) {
                        temp = temp->next;
                }
                //last node link new node
                temp->next = ptr;
                //new node link with 1st node
                ptr->next = head;
        }
    return head;
}
//Insert first node
struct node *insert_first(struct node *head)
{
        struct node *temp;
        struct node *ptr;
        //Create node
        ptr = create_node();

        if (head == NULL) {
                head = ptr;
                ptr->next = head;
        } else {
                temp = head;
                //Read last node
                while (temp->next != head) {
                        temp = temp->next;
                }
                //new node link with first node
                ptr->next = head;

                //head pointing to new node
                head = ptr;
                //last node link with new address
                temp->next = ptr;

        }
        return head;
}
//Create double linked list
struct node *create_list(struct node *head)
{
        int num;
        int index;
        struct node *ptr;
        //taking no of nodes
        printf("Enter the no of nodes: ");
        scanf("%d", &num);
        for (index = 0; index < num; index++ ) {

                //create node
                ptr = create_node();
                if (head == NULL) {
                        head = ptr;
                        ptr->next = head;
                } else {
                        struct node *temp = head;

                        while (temp->next != head) {
                                temp = temp->next;
                        }
                        temp->next = ptr;
                        ptr->next = head; //Last node pointing to start node
                }

        }
        return head;

}
//Create one node
struct node* create_node()
{
	int ele;
	struct node *new_node;
        //Allocate memory for node
    new_node = (struct node *)malloc(sizeof(struct node));
    if (new_node == NULL) {
        printf("Memory can't be creted \n");
                //return NULL;
        }
    printf("Enter the element: ");
        scanf("%d", &ele);

        new_node->data = ele;
        new_node->next = new_node;

        return new_node;
}
//Print list
void display(struct node *head)
{
	struct node *ptr = head;

    //Check list is empty or not
    if (head == NULL) {
        printf("List is empty \n");
                //return
		} else {
        //List print forword direction
        	printf("Forword List is: ");
        	do {
                        printf("%d ", ptr->data);
            	ptr = ptr->next;
           }while (ptr != head);
        	printf("\n");
       }
}
