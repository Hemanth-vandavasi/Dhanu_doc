#include <stdio.h>
#include <stdlib.h>
struct node* delete(struct node* head)
{
        struct node* temp = head;
        struct node* temp2 = head;
//      struct node* temp3 = head;
        int op = 0;
        int loc;
        int j = 1;
        printf("Delete :\n 1.At Beginning\n2.At End\n3.At Given position\n");
        printf("Enter the choice :");
        scanf("%d", &op);         switch(op) {
                case 1:
                        while (temp->ntail != head) {
                                temp = temp->ntail;
                        }
                        temp2 = temp2->ntail;
                        head->ntail = NULL;
                        temp->ntail = temp2;
                        return temp2;
                        break;
                case 2:
                        while (temp2->ntail != temp) {
                                temp2 = temp2->ntail;
                        }
                        temp2 -> ntail = head;
                        temp-> ntail = NULL;
                        return head;
                        break;
                case 3:
                        printf("Enter the location : ");
                        scanf("%d", &loc);
                        temp = head;
        /*              while(j != loc) {
                                temp = temp->ntail;
                                j++;
                        }
                        temp2 = temp->ntail;
                        j = 1;
                        while (j != (loc - 1)) {
                                temp3 = temp3->ntail;
                                j++;
                        }
                        temp3->ntail = temp2;
                        temp2->ntail = NULL;
                        return head;
                        break; */
                        while(j < loc) {
                                temp2 = temp;
                                temp = temp->ntail;
                                j++;
                        }
                        temp2->ntail = temp->ntail;
                        temp->ntail = NULL;
                        return head;
                        break;
                default:
                        printf("INVALID INPUT\n");
                        break;
        }
}
