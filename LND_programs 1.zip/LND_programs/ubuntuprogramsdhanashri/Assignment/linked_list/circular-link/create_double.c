#include <stdio.h>
#include <stdlib.h>
struct node {
	int data;
	struct node *next;
	struct node *prev;
};
struct node *head;
void display(struct node *head)
{
	struct node *ptr = head;

    //Check list is empty or not
    if (head == NULL) {
        printf("List is empty \n");
                //return
		} else {
        //List print forword direction
        	printf("Forword List is: ");
        	do {
                        printf("%d ", ptr->data);
            	ptr = ptr->next;
           }while (ptr != head);
        	printf("\n");
       }
}
