#include<stdio.h>
#include<stdlib.h>

struct Node{
	int data;
	struct Node *next;
	struct Node *prev;
};
struct Node *head = NULL;
void Insert(int x);
void Print();
void ReversePrint(); 

int main()
{	int i;
	int num;
	int x;
	head = NULL;
	printf("How many numbers?\n");
	scanf("%d", &num);
	for (i = 0; i < num; i++) {
		printf("Enter the number :\n");
		scanf("%d", &x);
		Insert(x);
		Print();
		ReversePrint();
	}
	return 0;
}
void Insert(int x)
{
	struct Node *newnode = (struct Node*)malloc(sizeof(struct Node));
	newnode -> data = x;
	newnode -> next = NULL;
	newnode -> prev = NULL;
	if(head == NULL) {
		head = newnode;
		return;
	}
	struct Node *temp = head;
	while (temp->next != NULL) {
		temp = temp->next;
	}
	temp -> next = newnode;
	
	newnode -> next = NULL;
	newnode -> prev = temp;
	//head = newnode;
}
void Print() 
{
	struct Node *temp = head;
	printf("Forward : ");
	while(temp != NULL) {
		printf(" %d ",temp -> data);
		temp = temp -> next;
	}
	printf("\n");
}
void ReversePrint() 
{
	struct Node *temp = head;
	if(temp == NULL) return;
	while(temp -> next != NULL){
		temp = temp -> next;
	}
	printf("Reverse : ");
	while(temp != NULL){
		printf(" %d ",temp -> data);
		temp = temp -> prev;
	}
	printf("\n");
}

