#include <stdio.h>
#include <stdlib.h>

struct node {
	int data;
	struct node * next;
	struct node * prev;
};
struct node * head;  // declare head pointer globally, pointer to head
struct node * last;
void Insert_at_head(int x);
void display();
void ReversePrint();
//void display();

int main() 
{
	int i;
	int num;
	int x;
	head = NULL;
	last = NULL;
	printf("How many numbers?\n");
	scanf("%d", &num);
	for (i = 0; i < num; i++) {
		printf("Enter the number :\n");
		scanf("%d", &x);
		Insert_at_head(x);
		display();
		ReversePrint();
		//display();
	}
	return 0;
}
void Insert_at_head(int x)
{
//	struct node *temp;
	struct node *head = (struct node*) malloc(sizeof(struct node));
	struct node *newnode = (struct node*)malloc(sizeof(struct node));
	newnode -> data = x;
	newnode -> prev = NULL;
	newnode -> next = NULL;
	last = head;
	if (head == NULL) {
		head = newnode;
		return;
	}
	else {
		head -> prev = newnode;
		newnode -> next = head;
		head = newnode;
	}
//	return newnode;
}
void display()
{
	struct node *temp = head;
	printf("Forward :");
	while (temp != NULL) {
		printf(" %d ", temp -> data);
		temp = temp -> next;
	}
	printf("\n");
}
void ReversePrint() 
{
	struct node * temp = head;
	if (temp == NULL) 
		return;
	while (temp -> next != NULL) {
		temp = temp -> next;
	}
	printf("Reverse :");
	while (temp != NULL) {
		printf("%d", temp -> data);
		temp = temp -> prev;
	}
	printf("\n");
}
