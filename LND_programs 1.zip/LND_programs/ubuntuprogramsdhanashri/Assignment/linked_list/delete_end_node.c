#include <stdio.h>
#include <stdlib.h>
struct node {
	int data;
	struct node * next;
};
struct node * head;
void create(int num);
void Delete(int x);
void Print();
int main()
{	
	head = NULL;   //Intially the list is empty.
	int num;
	int x;
	printf("How many numbers?\n");
	scanf("%d", &num);
	create(num);
	Delete(x);
	Print();
	return 0;
}

void create(int num)
{
	struct node *ptr;
	int index;
	int data;
	for (index = 0; index < num; index++) {
		printf("Enter the data: ");
		scanf("%d", &data);
		ptr = (struct node *)malloc(sizeof(struct node));
		ptr -> data = data;
		ptr -> next = NULL;
		if (head == NULL)	{
		head = ptr;
		} else {
			struct node *temp = head;
			while (temp -> next != NULL) {
				temp = temp -> next;
			}
			temp -> next = ptr;
		}
	}
	printf("List is :\n");
}

void Delete(int x)
{
	struct node * temp = (struct node*) malloc(sizeof(struct node));
	struct node *ptr;
	if(head == NULL)	{
		printf("List is Empty:");
		exit(0);
	}
	else {
		ptr = head;
		while(ptr -> next != NULL) {
			temp = ptr;
			ptr = ptr -> next;
		}
		temp -> next = NULL;
		printf("The deleted element is:%d\n", ptr -> data);
		free(ptr);
	}
}
void Print()
{
	struct node * temp = head;
	printf("After deletion of last node :");
	while (temp != NULL) {
		printf(" %d", temp -> data);
		temp = temp -> next;
	}
	printf("\n");
}

