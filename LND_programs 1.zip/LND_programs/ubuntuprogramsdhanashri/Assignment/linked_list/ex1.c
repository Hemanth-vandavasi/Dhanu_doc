#include <stdio.h>
#include <stdlib.h>
#if Q == 1
struct data {
	int data;
	struct data *link;
};
int main() 
{
	struct data *ptr;
	ptr = malloc(sizeof(struct data));
	ptr -> data = 45;
	ptr -> link = NULL;

	struct data *ptr1;
	ptr1 = malloc(sizeof(struct data));
	ptr1->data = 88;
	ptr1->link = NULL;
	ptr -> link = ptr1;

	printf("Numbers are :%d%d\n", ptr->data, ptr1->data);
	return 0;
}
#endif
#if Q == 2
struct employee {
	char *name;
	char gender;
	float sal;
	struct employee *link;
};
int main()
{
	//int num;
	struct employee e1;
	struct employee *eptr;
	eptr = (struct employee*) malloc(sizeof(struct employee));
//	eptr -> employee;
	eptr -> link = NULL;

	//printf("Enter the number of employee :");
	//scanf("%d", &num);
	printf("Enter the name of employee :");
	scanf("%s\n", e1.name);
	printf("Enter the gender of employee :");
	scanf("%c", &e1.gender);
	printf("Enter the salary of employee :");
	scanf("%f", &e1.sal);

	free(eptr);
	return 0;
}
#endif
