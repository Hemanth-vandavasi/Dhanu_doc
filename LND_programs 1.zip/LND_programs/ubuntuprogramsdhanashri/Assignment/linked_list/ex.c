#include <stdio.h>
#include <stdlib.h>
#include<string.h>
struct Node {
        int id;
    char name[50];
    char lname[50];
    char gender[50];
    char occupation[50];
    int age;
    struct Node* next;
};
//struct Node* head = NULL;
struct Node  *create(struct Node *head, FILE *fp);
void printList(struct Node *head);
void freelist(struct Node *head);
void Sort(struct Node *head);

int main()
{
        FILE *fp = NULL;
    struct Node* head = NULL;
    fp = fopen("club_Members_record.txt", "r");
    if (fp == NULL) {
                printf("Error! Could not read the file.");
        exit(1);
    }
        head = create(head, fp);
  //  printList(head);
    fclose(fp);
   // freelist(head);
//	Sort(head);
	freelist(head);
    head = NULL;
    return 0;
}
struct Node *create(struct Node *head,  FILE *fp)
{
        struct Node mem;
    while (fscanf(fp, "%d %s %s %s %s %d", &mem.id, mem.name,mem.lname, mem.gender, mem.occupation, &mem.age) != EOF)  {
    struct Node* newNode;
	Sort(head);
    newNode = (struct Node*)malloc(sizeof(struct Node));
    newNode -> id = mem.id;
    strcpy(newNode -> name, mem.name);
    strcpy(newNode->lname, mem.lname);
    strcpy(newNode -> gender, mem.gender);
    strcpy(newNode -> occupation, mem.occupation);
    newNode -> age = mem.age;
    newNode -> next = NULL;
    if(head == NULL) {
                head = newNode;
    } else {
                struct Node *temp = NULL;
        temp = head;
        while(temp -> next != NULL) {
                temp = temp -> next;
        }
        temp -> next = newNode;
        }
        }
    return head;
}
void printList(struct Node *head)
{
//      struct Node* temp = head;
//      while (temp != NULL) {
        if (head == NULL) {
                printf("List is empty!");
    } else {
                while (head != NULL) {
//              printf("ID: %d, Name: %s, Gender: %s, Occupation: %s, Age: %d \n", temp->id, temp->name, temp->gender, temp->occupation, temp->age);
                printf("%d\t", head -> id);
                printf("%s\t", head -> name);
                printf("%s\t", head -> lname);
                printf("%s\t", head -> gender);
                printf("%s\t", head -> occupation);
                printf("%d\t", head -> age);
                head = head -> next;
                printf("\n");
       }
    }
}
void freelist(struct Node *head)
{
        struct Node *temp;
    while(head != NULL) {
        temp = head;
        head =  head -> next;
        free(temp);
        temp = NULL;
    }
}
void Sort(struct Node *head)
{
	struct Node *temp;
	//Sorting the data
        if (head->next == NULL) {
            head->next = temp;
		}
        else{
            struct Node *p, *q;
            p = head;
            q = head->next;
            while (q != NULL){
                if ((strcmp(q->name, temp->name) > 0) && (strcmp(q -> lname, temp -> lname) > 0)&& (strcmp(q -> gender, temp -> gender) > 0)
				&&(strcmp(q -> occupation, temp -> occupation) > 0)) {
				p = q;
                q = q->next;
            }
            p->next = temp;
            temp->next = q;
        }
		printf("The sorted list is:\n");
 //   	struct Node *p = head->next;
    	while (p != NULL){
        	printf("%s\n", p->name);
        	p = p->next;
    	}

	}	
}
