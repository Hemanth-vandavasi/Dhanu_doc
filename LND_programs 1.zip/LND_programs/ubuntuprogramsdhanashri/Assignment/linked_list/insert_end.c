#include <stdio.h>
#include <stdlib.h>

struct node
{
        int data;
		struct node *next;
};

void display(struct node *head);
struct node * insert_begin(struct node*, struct node*);
int insert_end(struct node*, struct node*);
int insert_mid(struct node*, struct node*);

int main()
{
	struct node *head;
	struct node *newnode;
	struct node *temp;
	int choice;
	int count = 0;
	head = 0;
	while (choice) {
		newnode = (struct node *) malloc (sizeof(struct node));
		printf("Enter datas for list :");
		scanf("%d", &newnode -> data);
		newnode -> next = 0;
		if (head == 0) {
			head = temp = newnode;
		}else {
			temp -> next = newnode;
			temp = newnode;
		}
		printf("Do you wish to continue for adding data (0,1)?\n");
		scanf("%d", &choice);
		count++;
	}
	printf("Total nodes in the lists are:%d\n",count);
	display(head);
	struct node * new = insert_begin(head, newnode);
	insert_end(new, newnode);
//	insert_mid(new, newnode);
	free (newnode);
	newnode = NULL;
}
void display(struct node *head)
{
	struct node *temp;
	temp = head;
	printf("Nodes are :\n");
	while (temp != NULL) {
		printf("%d\t", temp -> data);
		temp = temp -> next;
	}
}
struct node * insert_begin(struct node *head, struct node *newnode)
{
	struct node * temp;
	newnode = (struct node *) malloc (sizeof(struct node));
	printf("\nEnter the node you want to insert at beginning :");
	scanf("%d", &newnode -> data);
	newnode -> next = head;
	head = newnode;
	printf("After inserting a node at beginning of list : \n");
	while (head != 0) {
		printf("\t%d\t", head -> data);
		head = head -> next;
	}
	printf("\n");
	return newnode;
}
int insert_end(struct node *head, struct node *newnode)
{
	struct node *temp;
	newnode = (struct node *) malloc (sizeof(struct node));
	printf("\nEnter the node you want to insert at end :");
	scanf("%d", &newnode -> data);
	newnode -> next = NULL;
	temp = head;
	while(temp -> next !=0) {
		temp = temp -> next;
	}
	temp -> next = newnode;
	newnode -> next = NULL;
	printf("After inserting a node at end of list : \n");
	temp = head;
	while (temp != 0) {
		printf("%d\t", temp -> data);
		temp = temp -> next;
	}
	printf("\n");
	return 0;
}
/*int insert_mid(struct node *head, struct node *newnode)
{
	int position;
	int i;
	int count = 0;
	struct node *temp;
	newnode = (struct node *) malloc (sizeof(struct node));
	printf("\nEnter the node you want to insert at position :");
	scanf("%d", &position);
*/
