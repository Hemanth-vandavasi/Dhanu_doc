#include <stdio.h>
#include <stdlib.h>
struct node {
	int data;
	struct node *next;
};
struct node * head;
struct node * newnode;
void Insert(int x);
void Print();
int main()
{
	int i;
	int num;
	int x;
	head = NULL;
	printf("How many numbers?\n");
	scanf("%d", &num);
	for (i = 0; i < num; i++) {
		printf("Enter the number :\n");
		scanf("%d",&x );
		Insert(x);
	//	Print();
	}
	Print();
}
void Insert(int x)
{
	struct node * temp = (struct node*) malloc(sizeof(struct node));
	temp -> data = x;
	temp->next = head;
	head = temp ;
}
void Print()
{
	struct node * temp = head;
	printf("List is :");
	while (temp != NULL) {
		printf(" %d", temp -> data);
		temp = temp -> next;
	}
	printf("\n");
}

