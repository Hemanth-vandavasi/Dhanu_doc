#include <stdio.h>
#include <stdlib.h>
struct node {
    int data;
    struct node *next;
};
void insert_beg();
void insert_end();
void Traverse(struct node *head);
struct node *head;
struct node *temp;
struct node *newnode;
int main() {
        int choice;
        int n;
        while(choice) {
            newnode = (struct node*)malloc(sizeof(struct node));
            printf("Enter the data");
            scanf("%d", &newnode->data);
            newnode -> next = NULL;
            if(head == NULL) {
                    head = temp = newnode;
            } else {
                temp -> next = newnode;
                temp = newnode;
            }
			printf("Do you want to continue (0,1)\n");
	     	scanf("%d", &choice);
        }
		insert_beg();
		insert_end();
		Traverse(head);
//		printf("The data is :%d", data);
}
void Traverse(struct node *head) {
    temp = head;
    while(temp != NULL) {
        printf("%d\n", temp -> data);
       temp = temp -> next;
    }
}
void insert_beg() {
	struct node* new = (struct node*)malloc(sizeof(struct node));
	printf("Enter the node for beg:");
	scanf("%d", &new -> data);
	if(head == NULL) {
		head = new;
	} else {
		new-> next = head;
		head = new;
	}
}
void insert_end() {
	struct node* new1 = (struct node*)malloc(sizeof(struct node));
	printf("Enter the data for end :");
	scanf("%d", &new1->data);
	temp = head;
	while(temp -> next != NULL) {
		temp = temp -> next;
	}
	temp -> next = new1;
	new1->next = NULL;
	
}	
