#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define SIZE 50
int my_span(char *str1, char *str2);

int main() {
	char *str1 = NULL;
	char *str2 = NULL;

	str1 = (char*) malloc(SIZE * sizeof(char)); //dyanamic memory allocation
	str2 = (char*) malloc(SIZE * sizeof(char));

	if (NULL == str1 && NULL == str2) {
		printf("Malloc failed !\n");
		exit (0);
	}
	printf("Enter a string for str1 :");
	if (NULL == (fgets(str1, SIZE, stdin))) {
		printf("Fgets failed for str1");
	}
	printf("Enter a string for str2 :");
	if (NULL == (fgets(str2, SIZE, stdin))) {
		printf("Fgets failed for str2");
	}

	*(str1 + (strlen(str1) - 1)) = '\0';
	*(str2 + (strlen(str2) - 1)) = '\0';

	int len = my_span(str1, str2);
//	printf("%s\n", src);
	printf("After string span is :%d\n", len);
	free(str1);
	free(str2);
	str1 = NULL;
	str2 = NULL;
	return 0;
}

int my_span(char *str1, char *str2)
{
	int count = 0;
	char *temp = str2;
	while (*str1 != '\0') {
		while (*str2 != '\0') {
			if (*str1 == *str2) {
				count = count + 1;
				str2 = temp;
				break;
			}
			else  {
				str2++;
			}
		}
		str1++;
	}
	return count;
}
 
 
