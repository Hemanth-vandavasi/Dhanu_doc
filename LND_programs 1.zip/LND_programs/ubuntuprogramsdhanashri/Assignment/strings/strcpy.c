#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define SIZE 50

char* my_string(char *dest, char *src);

int main() {
	char *src = NULL;
	char *dest = NULL;

	src = (char*) malloc(SIZE * sizeof(char)); //dyanamic memory allocation
	dest = (char*) malloc(SIZE * sizeof(char));

	if (NULL == src && NULL == dest) {
		printf("Malloc failed !\n");
	}

	printf("Enter a string %s:", src);
	if (NULL == (fgets(src, SIZE, stdin))) {
		printf("Fgets failed for src");
	}
	*(src + (strlen(src) - 1)) = '\0';
	my_string(dest, src);
	printf("Source string :%s\n", src);
	printf("Destination string :%s\n", dest);
	free(src);
	free(dest);
	src = NULL;
	dest = NULL;
}

char* my_string(char *dest, char *src)
{
	char *temp;
	temp = dest;
	while(*src) {
		*temp++ = *src++;
	}
	return dest;
}
