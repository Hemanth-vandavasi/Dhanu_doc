#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#define SIZE 50
int  str_CompCase(char  *str1, char *str2);

int main() {
	char *str1 = NULL;
	char *str2 = NULL;
	int comp;

	str1 = (char*) malloc(SIZE * sizeof(char)); //dyanamic memory allocation
	str2 = (char*) malloc(SIZE * sizeof(char));
	
	if (NULL == str1 && NULL == str2) {
		printf("Malloc failed !\n");
		exit (0);
	}

	printf("Enter a str1 string :");
	if (NULL == (fgets(str1, SIZE, stdin))) {
		printf("Fgets failed for str1");
	}
	printf("Enter a str2 string :");
	if (NULL == (fgets(str2, SIZE, stdin))) {
		printf("Fgets failed for str2");
	}
	*(str1 + (strlen(str1) - 1)) = '\0';
	*(str2 + (strlen(str2) - 1)) = '\0';


	comp = str_CompCase(str1, str2);
	if (comp > 0)
	printf("The string str1 is greater than string str2 \n");
	else if (comp < 0)
	printf("The string str1 is less than string str2 \n");
	else 
	printf("The string str1 is equal to string str2 \n");

	free(str1);
	free(str2);
	str1 = NULL;
	str2 = NULL;
	return 0;
}

int str_CompCase(const char *str1, const char *str2)
{
	unsigned char *s1 = (unsigned char*) str1;
	unsigned  char *s2 = (unsigned char*) str2;
	while (tolower(*s1) == tolower(*s2++)) {
		if (*s1++ == '\0') {
			return 0;
		}
	}
	return (tolower(*s1) - tolower(*--s2));
}
