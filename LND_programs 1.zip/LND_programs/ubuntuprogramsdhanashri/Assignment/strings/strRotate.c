#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define SIZE 50
int  str_Rotate(char  *str, char *rstr);

int main() {
	char *str = NULL;
	char *rstr = NULL;

	str = (char*) malloc(SIZE * sizeof(char)); //dyanamic memory allocation
	rstr = (char*) malloc(SIZE * sizeof(char));
	
	if (NULL == str && NULL == rstr) {
		printf("Malloc failed !\n");
		exit (0);
	}

	printf("Enter a str string :");
	if (NULL == (fgets(str, SIZE, stdin))) {
		printf("Fgets failed for str");
	}
	printf("Enter a rstr string :");
	if (NULL == (fgets(rstr, SIZE, stdin))) {
		printf("Fgets failed for rstr");
	}
	*(str + (strlen(str) - 1)) = '\0';
	*(rstr + (strlen(rstr) - 1)) = '\0';
	 int res = str_Rotate(str, rstr);
//	printf("%s", rstr);
	if (res > 0) {
		printf("Strings are rotated eachother \n");
	}
	else {
		printf("Strings are not rotated \n");
	}
	free(str);
	free(rstr);
	str = NULL;
	rstr = NULL;
}

int str_Rotate(char *str, char *rstr)
{
	int n = strlen(str);
	int flag = 0;
	if (n != strlen(rstr)) {
		return -1;
	}
	for (int pos = 0; pos < n; pos++) {
		for (int i = 0; flag = 0, i < n; i++) {
			if (rstr[(pos + i) % n] != str[i]) {
				flag = 1;
				break;
			}
		}
		if (flag == 0) {
			return pos;
		}
	}
	return -1;
}
