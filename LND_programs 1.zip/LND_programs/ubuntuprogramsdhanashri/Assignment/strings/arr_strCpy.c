#include <stdio.h>
#include <string.h>
#define SIZE 10
//void String_cpy(char arr[]);

int main() {
	int src[SIZE];
	int dest[SIZE];
	int i;
	int size;
	printf("Enter the size of array :");
	scanf("%d", &size);
	printf("Enter the source string :\n");
	for(i = 0; i < size; i++) {
		scanf("%d", &src[i]);
	}
	for(i = 0; i < size; i++) {
		dest[i] = src[i];
	}
	printf("destination array:");
	for(i = 0; i < size; i++) {
		printf("%d ", dest[i]);
	}
	return 0;
}
		
