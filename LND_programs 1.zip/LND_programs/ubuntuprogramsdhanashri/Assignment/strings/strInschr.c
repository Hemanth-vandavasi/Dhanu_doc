#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define SIZE 50
char* my_strinschr(char *str, const char c, int num);

int main() 
{
	char *str = NULL;
	char c;
	int num;
//	int count = 0;
	str = (char*) malloc(SIZE * sizeof(char)); // dyanamic memory allocation
	if (NULL == str) {
		printf("Malloc failed !\n");
		exit (0);
	}
	printf("Enter a string:");
	if (NULL == (fgets(str, SIZE, stdin))) {
		printf("Fgets failed for str");
	}
	*(str +(strlen(str) - 1)) = '\0';
	
	printf("Enter the char to insert in string :");
	scanf("%ci\n", &c);
	printf("Enter the location where char to insert:");
	scanf("%d", &num);
	my_strinschr(str, c, num);
 	printf("Modified string :%s\n", str); 
//	count << str << end;
	free(str);
	str = NULL;
	return 0;
}
char* my_strinschr(char *str, const char c, int num)
{	
/*	int len = strlen(str);
	int i;
	for (i = len; i >= num; i--) {
		*(str + i) = *(str + (i - 1));
	}
	*(str + (num -1)) = c;
	return str;*/
	while(*str != '\0') {
		if(*str == num) {
			*str = c;
		}
		*str++;
		return str;
	}
}
