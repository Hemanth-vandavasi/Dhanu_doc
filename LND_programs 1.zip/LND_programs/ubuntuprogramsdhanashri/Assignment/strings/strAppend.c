#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define SIZE 50

char* my_strappend(char *dest, char *src);

int main() {
	char *src = NULL;
	char *dest = NULL;

	src = (char*) malloc(SIZE * sizeof(char)); //dyanamic memory allocation
	dest = (char*) malloc(SIZE * sizeof(char));

	if (NULL == src && NULL == dest) {
		printf("Malloc failed !\n");
		exit (0);
	}
	printf("Enter a string for src :");
	if (NULL == (fgets(src, SIZE, stdin))) {
		printf("Fgets failed for src");
	}
	printf("Enter a string for dest :");
	if (NULL == (fgets(dest, SIZE, stdin))) {
		printf("Fgets failed for dest");
	}

	*(src + (strlen(src) - 1)) = '\0';
	*(dest + (strlen(dest) - 1)) = '\0';

	my_strappend(dest, src);
//	printf("%s\n", src);
	printf("Append String: %s%s\n", src, dest);
	free(src);
	free(dest);
	src = NULL;
	dest = NULL;
}

char* my_strappend(char *dest, char *src)
{
	char *temp = dest;
	while (*temp != '\0') {
		temp++;
	}	
	while (*src !='\0' ) {
		*temp = *src;
		src++;
		temp++;
	}
	*temp = '\0';
	return temp;
/*	while(*src != '\0') {
        src++;
    }
    while(*dest != '\0') {
        *src++ = *dest++ ;
       // *src++;
       // *dest++;
    }
    *src = '\0';
    return src;
*/
}
