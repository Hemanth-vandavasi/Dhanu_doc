#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define SIZE 50
char* my_squeeze(char *str);

int main() 
{
	char *str = NULL;
//	int count = 0;
	str = (char*) malloc(SIZE * sizeof(char)); // dyanamic memory allocation
	if (NULL == str) {
		printf("Malloc failed !\n");
		exit (0);
	}
	printf("Enter a string:");
	if (NULL == (fgets(str, SIZE, stdin))) {
		printf("Fgets failed for str");
	}
	*(str +(strlen(str) - 1)) = '\0';

	my_squeeze(str);
 	printf("The final string after removing all similar character : %s\n", str); 
//	count << str << end;
	free(str);
	str = NULL;
	return 0;
}
char* my_squeeze(char *str)
{	
/*	int i;
	int j;
	int k;
//	int count = 0;
	for (i = 0; i < strlen(str); i++) {
		for (j = i + 1; str[j] != '\0'; j++) {
			if (str[j] == str[i]) {
				for (k = j; str[k] != '\0'; k++) {
					str[k] = str[k + 1];
		//			count++;
				}
			}
		}
	}*/
	char* temp1 = str;
	char* temp2 = str;
	while (*temp1)
	{
		*temp2 = *temp1;
		temp1++;
		printf("%s\n", temp1);
	
		if ((*temp1 != *temp2) || (*temp1 == '\0')) {
			temp2++;
		}
	}
	*temp2 = '\0';
	return str;
}
