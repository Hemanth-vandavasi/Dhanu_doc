#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define SIZE 50
int str_Palindrome(char *str);

int main() {
	char *str = NULL;

	str = (char*) malloc(SIZE * sizeof(char)); // dyanamic memory allocation
	if (NULL == str) {
		printf("Malloc failed !\n");
	}
	printf("Enter a string:");
	if (NULL == (fgets(str, SIZE, stdin))) {
		printf("Fgets failed for str");
	}
	*(str +(strlen(str) - 1)) = '\0';

	 str_Palindrome(str);
	 if( str_Palindrome(str))
	 printf("string is palindrome \n");
	 else
	 printf("string is not palindrome \n");
  
	free(str);
	str = NULL;
}
 int str_Palindrome(char *str)
 {
 /*	int i;
	int c = 0;
	int n;
	n = strlen(str);
	for(i = 0;i < n/2; i++) {
		if(str[i] == str[n-i-1])
		c++;						 
	}
	if(c == i)
	return 1;
	else
	return 0;*/
	int index = 0;
	int len = strlen(str) - 1;
	while (index <= len) {
		if (*(str + index) == *(str + len)){
			index++;
			len--;
		}
		else {
			return 0;
		}
	}
	return 1;
}

