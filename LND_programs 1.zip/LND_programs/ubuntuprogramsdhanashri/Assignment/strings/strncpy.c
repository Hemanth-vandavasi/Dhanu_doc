#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define SIZE 50

char *my_string(char *dest, const char *src, int n);

int main() {
	char *src = NULL;
	char *dest = NULL;
	int n;

	src = (char*) malloc(SIZE * sizeof(char)); //dyanamic memory allocation
	dest = (char*) malloc(SIZE * sizeof(char));

	if (NULL == src || NULL == dest) {
		printf("Malloc failed !\n");
	}

	printf("Enter a string %s:", src);
	if (NULL == (fgets(src, SIZE, stdin))) {
		printf("Fgets failed for src");
	}
	printf("Enter a number of string you want to copy :");
	scanf("%d", &n);
	*(src + (strlen(src) - 1)) = '\0';
	my_string(dest, src, n);
	printf("Source string is :%s\n", src);
	printf("Destination string is : %s\n", dest);
	free(src);
	free(dest);
	src = NULL;
	dest = NULL;
}

char *my_string(char *dest, const char *src, int n)
{
/*	int i;
	for (i = 0; i < n; i++) {
			dest[i] = src[i];
		}
			return dest;*/
	int i = 0;
    while(i < n && *src != '\0'){
        *dest++ = *src++;
        i++;
    }
    *dest = '\0';
    return dest;
}
