#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define SIZE 50
int my_strindex(char *str, char c);

int main() {
	char *str = NULL;
	char c;
	int temp;
	str = (char*) malloc(SIZE * sizeof(char)); // dyanamic memory allocation
	if (NULL == str) {
		printf("Malloc failed !\n");
		exit (0);
	}
	printf("Enter a string:");
	if (NULL == (fgets(str, SIZE, stdin))) {
		printf("Fgets failed for str");
	}
	*(str +(strlen(str) - 1)) = '\0';
	//strindex(str, c);
	printf("Enter a character to be searched :");
	scanf("%c", &c);	
  	temp = my_strindex(str, c);
 	if(temp >= 0) {
		printf("found at index %d\n" , temp);
	} else { 
		printf("not found\n");
	}
	free(str);
	str = NULL;
	return 0;
}
int my_strindex(char *str, char c)
{
	int index = 0;
//    int i = 0;
    while(*str != '\0'){
        if(*str == c){
            return index;
            break;
        }
        index++;
		str++;
    }
	return 0;
}
