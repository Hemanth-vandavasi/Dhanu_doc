#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define SIZE 50
char* strrev(char *str);

int main() {
	char *str = NULL;

	str = (char*) malloc(SIZE * sizeof(char)); // dyanamic memory allocation
	if (NULL == str) {
		printf("Malloc failed !\n");
	}
	printf("Enter a string:");
	if (NULL == (fgets(str, SIZE, stdin))) {
		printf("Fgets failed for str");
	}
	*(str +(strlen(str) - 1)) = '\0';

	 strrev(str);
 	printf("Reversed string is : %s\n", str); 
	free(str);
	str = NULL;
}
char* strrev(char *str)
{
/*	int i = 0;
	int len = strlen(str);
	int j = 0;
	char temp;

	for (i = 0, j = len - 1; i < j; i++, j--) {
		temp = str[i];
		str[i] = str[j];
		str[j] = temp;
	}
	return str;*/
	char *temp;
	char temp2;
//	int len;
	temp = (str + (strlen(str)) - 1);
//	temp = len - 1;
	while(temp > str) {
		temp2 = *str;
		*str = *temp;
		*temp = temp2;
		temp--;
		str++;
	}
	return str;
}
