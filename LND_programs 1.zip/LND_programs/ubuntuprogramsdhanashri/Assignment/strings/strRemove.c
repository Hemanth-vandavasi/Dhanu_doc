#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define SIZE 50
char* mystr_Remove(char *str, char *rstr);

int main() 
{
	char *str = NULL;
	char *rstr = NULL;
	//int len;
//	int rem;

	str = (char*) malloc(SIZE * sizeof(char)); // dyanamic memory allocation
	rstr = (char*) malloc(SIZE * sizeof(char));

	if (NULL == str && NULL == rstr) {
		printf("Malloc failed !\n");
		exit (0);
	}

	printf("Enter a string:");
	if (NULL == (fgets(str, SIZE, stdin))) {
		printf("Fgets failed for str");
	}
	printf("Remove the substring :");
	if (NULL == (fgets(rstr, SIZE, stdin))) {
		printf("Fgets failed for rstr");
	}

	*(str + (strlen(str) - 1)) = '\0';
	*(rstr + (strlen(str) - 1)) = '\0';
	mystr_Remove(str, rstr);

	//printf("Remove the substring :%d\n",rem);
//	scanf("%d", &rem);
//	mystr_Remove(str, rstr);
 	printf("Modified string is : %s\n", str); 

	free(str);
	free(rstr);
	str = NULL;
	rstr = NULL;
	return 0;
}
char* mystr_Remove(char *str, char *rstr)
{
	int i;
	int j;
	int len = strlen(str);
	printf("%d",len);
	for (i = 0; i < len; i++) {
		if (str[i] == *rstr) {
			for (j = i; j < len; j++) {
				str[j] = str[j + 1];
			}
			len--;
			i++;
		
		}
	//	str++;
	}
//	return str;

}
