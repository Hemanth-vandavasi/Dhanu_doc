#include <stdio.h>
#include <string.h>

char* my_strCat(char *src1, char *src2);

int main() {
	char *src1 = NULL;
	char *src2 = NULL;
	src1 = (char*) malloc(SIZE * sizeof(char)); // Dyanamic memory location
	src2 = (char*) malloc(SIZE * sizeof(char));
	if (NULL == src1 && NULL == src2) {
		printf("Malloc failed! :");
		exit (0);
	}
	printf("Enter the first string -: \n");
	if (NULL == (fgets(src1, SIZE, stdin))) {
		printf("Fgets failed for src1");
	}
	printf("Enter the second string -: \n");
	if (NULL == (fgets(src2, SIZE, stdin))) {
		printf("Fgets failed for src2");
	}
	*(src1 + (strlen(src1)) - 1) = '\0';
	*(src2 + (strlen(src2)) - 1) = '\0';
	printf("Concatenated string is :%s\n", my_strCat(src1, src2


