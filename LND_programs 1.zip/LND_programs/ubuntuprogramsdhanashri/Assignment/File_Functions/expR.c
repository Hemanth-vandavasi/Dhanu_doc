#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdio_ext.h>
struct employee {
	char name[20];
	int age;
	int id;
	int salary;
	}emp;
int main() 
{
	FILE *fd;
//	int i;
//	int num;
	fd = fopen("Data", "r");
	if (fd == NULL) {
		printf("File not found");
		exit(1);
	}
/*	printf("Enter no. of records :");
	scanf("%d", &num); 
	for (i = 0; i < num; i++) {
		__fpurge(stdin);
		printf("Enter Emp_name :%d", i + 1);
		fgets(emp.name, 20, stdin);
		*(emp.name + (strlen(emp.name) - 1)) = '\0';
		//scanf("%s\n", emp.name);
		printf("Enter age :%d\n", i + 1);
		scanf("%d", &emp.age);
		printf("Enter Emp_id :%d\n", i + 1);
		scanf("%d", &emp.id);
		printf("Enter salary :%d\n", i + 1);
		scanf("%d", &emp.salary);
		fwrite(&emp, sizeof(emp), 1, fd);
		}*/	
	fseek(fd, 0, SEEK_SET);
//	printf("\nname\tage\tid\tsalary\n");
	while (fread(&emp, sizeof(emp), 1, fd) == 1) {
		printf("%s\t", emp.name);
		printf("%d\t", emp.age);
		printf("%d\t", emp.id);
		printf("%d\t", emp.salary);
	}
	fclose(fd);
	return 0;
}

