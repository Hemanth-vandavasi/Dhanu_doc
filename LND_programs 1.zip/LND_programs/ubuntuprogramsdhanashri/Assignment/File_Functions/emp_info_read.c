#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdio_ext.h>
struct employee {
	char name[20];
	int age;
	int id;
	int salary;
	};
int main() 
{
	FILE *fd;
	int i;
	int num;
	struct employee emp;
//	fd = fopen("Emp_Data", "w");
//	e = (struct emp*) malloc(sizeof(emp));
	fd = fopen("Emp_Data", "rb");
	if (fd == NULL) {
		printf("File not found");
		exit(1);
	}
	
	fseek(fd, 0, SEEK_SET);
	//printf("\nname\tage\tid\tsalary\n");
	while (fread(&emp, sizeof(emp), 1, fd) == 1) {
		printf("%s\t", emp.name);
		printf("%d\t", emp.age);
		printf("%d\t", emp.id);
		printf("%d\t", emp.salary);
	}
	fclose(fd);
	return 0;
}
