#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdio_ext.h>
struct employee {
	char name[20];
	int age;
	int id;
	int salary;
	};
int main() 
{
	FILE *fd;
//	int i;
//	int num;
	struct employee *emp;
//	fd = fopen("Emp_Data", "w");
	emp = (struct employee*) malloc(sizeof(struct employee));
	fd = fopen("Emp_Data", "wb");
	if (fd == NULL) {
		printf("File not found");
		exit(1);
	}
	__fpurge(stdin);
	printf("Enter Emp_name :");
//__fpurge(stdin);
//fgets(e->name, 20, stdin);
	scanf("%s", emp->name);
	printf("Enter age :");
	scanf("%d", &emp->age);
	printf("Enter Emp_id ");
	scanf("%d", &emp->id);
	printf("Enter salary :");
	scanf("%d", &emp->salary);
	fwrite(emp, sizeof(struct employee), 1, fd);	
	fclose(fd);
	return 0;
}

