#include <stdio.h>
#include <stdlib.h>

int main() {
	FILE *fd;
	int count = 0;
	int word = 0;
	char ch;
	fd = fopen("File.text", "a+");
	if (fd == NULL) {
		printf("File not found");
		exit(1);
	}
	while ((ch = fgetc(fd)) != EOF) {
		putchar(ch);
		if (ch == ' ' || ch == '\n') {
			word = 0;
		} else {
			if (!word) 
			count++;
			word = 1;
		}
	}
	printf(" Word Count is :%d\n", count);
	fclose(fd);
	return 0;
}
