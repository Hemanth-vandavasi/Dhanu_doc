#include <stdio.h>
main (int argc, char * argv [5]) {
	int i;
	printf("argc=%d\n",argc);
	for(i = 0; i < argc; i++)
		printf("argv[%d]=%s\n",i ,argv[i]);
}
