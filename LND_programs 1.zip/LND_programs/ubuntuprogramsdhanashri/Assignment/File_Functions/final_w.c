#include <stdlib.h>
#include <string.h>
#include<stdio_ext.h>
struct employee
{
        char name[50];
        int id;
        int age;
        int salary;
}; int main
{
        FILE *fp = NULL;
        struct employee *emp;
        fp = fopen("employee.txt","w");
        if(fp == NULL)
        {
                printf("Error opening file");
                exit(1);
        }
        emp = (struct employee*)malloc(4 * sizeof( struct employee)); 
        printf("Enter employee name:");
        fgets(emp->name, 20, stdin);
        *(emp->name + (strlen(emp->name) - 1)) = '\0';
         printf("Enter employee id : ");
        scanf("%d",&emp->id);
        __fpurge(stdin);      
	   printf("Enter employee age : ");
        scanf("%d",&emp->age);
        __fpurge(stdin);     
    printf("Enter employee salary : ");
        scanf("%d",&emp->salary);
        __fpurge(stdin); 
        fwrite(emp,sizeof(struct employee),1,fp);       
  fclose(fp);
//      free(emp);
        return 0;
}
