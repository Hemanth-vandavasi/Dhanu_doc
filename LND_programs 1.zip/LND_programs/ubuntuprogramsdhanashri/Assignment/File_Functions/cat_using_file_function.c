#include <stdio.h>
#include <stdlib.h>

int main() {
	FILE *fd;
	char ch;
//	int count = 0;
	fd = fopen("File.text", "a+");
	if (fd == NULL) {
		printf("File not found");
		exit(1);
	}
	while ((ch = fgetc(fd)) != EOF) {
		putchar(ch);
//		count++;
	}
//	printf("%d", count);
	fclose(fd);
	return 0;
}
