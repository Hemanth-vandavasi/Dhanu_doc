#include<stdio.h>
#if Q == 1
int main()
{
	unsigned char ch1 = 63;
	unsigned char ch2 = 28;
	unsigned char res = (ch1 & ch2);

	printf("The result :%d\n", res);
	return 0;
}
#endif

#if Q == 2
int main()
{
	unsigned char ch1 = 63;
	unsigned char ch2 = 28;
	unsigned char ch3 = 25;

	unsigned char res = (ch1 & ch2) | ch3;
	printf("The result : %d\n", res);
}
#endif

#if Q == 3
int main() 
{
	unsigned char ch1 = 63;
	unsigned char ch2 = 28;
	unsigned char ch3 = 25;

	unsigned char res = (ch1 & ch2) & ch3;
	printf("The result : %d\n", res);
	return 0;
}
#endif

#if Q == 4
int main() {
	unsigned short num1 = 512;
	unsigned short num2 = 786;

	unsigned short res1 = num1 ^ num2;
	unsigned short res2 = num1 & num2;

	printf("The result of exclusive or and addition :\n %d\n %d\n", res1, res2);
	return 0;
}
#endif

#if Q == 5
int main() {	
	unsigned char num1 = 63;
	unsigned char num2 = 28;
	
	printf("The right shift for num1 and left shift for num2 : \n %d\n %d\n", num1 << 4, num2 >> 2);
	return 0;
}
#endif
#if Q == 6
int main() {
	unsigned char num1 = 63;
	unsigned char num2 = 28;
	char res = (num1 & num2) & (num1 | num2);

	printf("The result : %d\n", res);
	return 0;
}
#endif
