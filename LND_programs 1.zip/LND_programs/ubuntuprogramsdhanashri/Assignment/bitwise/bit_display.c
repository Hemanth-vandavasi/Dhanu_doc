#include <stdio.h>

#if Q == 1
char dec_bin(unsigned char num);
int main() {
	unsigned char num;
	printf("Enter number:");
	scanf("%hhd", &num);
	dec_bin(num);
	return 0;
}

char dec_bin(unsigned char num)
{
	for ( int i = 7; i >= 0; i--) {
		int temp = num >> i;
		if (temp & 1) {
			printf("1");
		}
		else {
			printf("0");
		}
	}
}
#endif
