#include <stdio.h>
int clear_leftmost_setbit(unsigned int n);
int main() 
{ 
	unsigned int n; 
	printf("Enter the no:");
	scanf("%d", &n);

	printf("%d\n", clear_leftmost_setbit(n)); 
	unsigned int res =  clear_leftmost_setbit(n);

	for(int i = 1 << 7; i > 0; i = i / 2) {
		(res & i) ? printf("1") : printf("0");
	}
	
	return 0;
}
int clear_leftmost_setbit(unsigned int n) 
{ 
	int temp = (n ^ (1 << 7)); 
	return temp;
}
