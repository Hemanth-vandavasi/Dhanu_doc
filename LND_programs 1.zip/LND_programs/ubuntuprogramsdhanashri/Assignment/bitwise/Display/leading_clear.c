#include<stdio.h>
void display(unsigned int);
unsigned int count_leading_clear_bits( unsigned int);

int main()
{
    unsigned int res;
        unsigned int num1;
        printf("Enter a number -\n");
        scanf("%d", &num1);
        display(num1);
        res = count_leading_clear_bits(num1);
        printf("Count of leading clear bits in a number - %d \n", res);
        return 0;
}

void display(unsigned int num)
{
        int i = 16;
        printf("Binary represintation of number -\n");
        while(i) {
                if(num & 0X8000) {
                        printf("1 ");
                } else {
                        printf("0 ");
                }
                num = num << 1;
                i--;
        }
        printf("\n");
}

unsigned int count_leading_clear_bits( unsigned int num)
{
        unsigned int count = 0;
        int i = 16;
    while(i) {
        if(num & 0X8000) {
                break;
        } else {
                count++;
        }
                num = num << 1;
        i--;
    }
	return count;
}
