#include <stdio.h>

int set_bitcount(int num);
int clear_bitcount(int num);

int main() {
	unsigned int num;
	unsigned int set_count;
	unsigned int clear_count;
	printf("Enter the number: ");
	scanf("%u", &num);
	set_count = set_bitcount(num);
	clear_count = clear_bitcount(num);
	
	printf("The number of bits set in %u = %u\n", num, set_count);
	printf("The number of bits cleared in %u = %u\n", num, clear_count);

	return 0;
}
int set_bitcount(int num)
{
	int count = 0;
	int i;
	for(i = 0; i <= 7; i++) {
		if((num & (1 << i)) != 0)
		count++;
	}
	return count;
}
int clear_bitcount(int num)
{
	int count = 0;
	int i;
	for(i = 0; i <= 7; i++) {
		if((num & (1 << i)) == 0)
		count++;
	}
	return count;
}
