#include <stdio.h>
#define test_set_bit(num, pos) ((num) |= (1 << (pos)))

int main() {
	unsigned int num;
	unsigned int pos;

	printf("Enter the num :");
	scanf("%d", &num);

	printf("Enter the Position :");
	scanf("%d", &pos);
	
	unsigned int res = test_set_bit(num, pos); // macro declaration
//	num = (num) | (1 << (pos)); //  set a postion and do left shift of 1 number and do or opertor between them.

	printf("The result is :%d\n", num);
	for (int i = 1 << 7; i > 0; i = i / 2) {
		(res & i) ? printf("1") : printf("0");
    } 
	return 0;
}


