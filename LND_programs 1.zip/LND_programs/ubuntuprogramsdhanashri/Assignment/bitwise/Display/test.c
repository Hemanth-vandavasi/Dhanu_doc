#include <stdio.h>
int main() {
	char ch = 159;
	printf("%d", ch);
}
