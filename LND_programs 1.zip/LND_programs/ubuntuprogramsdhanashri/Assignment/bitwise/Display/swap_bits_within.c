#include <stdio.h>
//Function Declaration
unsigned int my_bit_swap(unsigned int num, unsigned int src, unsigned int dest);

// Main Function
int main() {
	unsigned int num;
	int src;
	int dest;
	printf("Enter the num :");
	scanf("%d", &num);

	printf("Enter the Position of Source :");// choose source position in a binary num
	scanf("%d", &src);

	printf("Enter the Postion of Destination :");// choose destination position in a same binary num
	scanf("%d", &dest);
	unsigned int res = my_bit_swap(num, src, dest);
	
	printf("%d\n", res); //Function call
	for (int i = 1 << 7; i > 0; i = i / 2) {
		(res & i) ? printf("1") : printf("0");
	}
	return 0;
}
// Function defination
unsigned int my_bit_swap(unsigned int num, unsigned int src, unsigned int dest)
{
	unsigned int dest_bit = (num >> dest) & 1;//any num right shift by choosing destination and do & operator by 1
	unsigned int src_bit = (num >> src) & 1;//any num rignt shift by choosing source and do & operator by 1
	unsigned int temp = (src_bit ^ dest_bit);//above source bit XOR operator with destination bit

	temp = (temp << src) | (temp << dest);//temp value of src left shift by choosing src postion
	//temp value of dest left shift by choosing dest postion 
	// then do or operation between them
	unsigned int result = num ^ temp;//above temp and num do XOR opertaion

	return result;
}
