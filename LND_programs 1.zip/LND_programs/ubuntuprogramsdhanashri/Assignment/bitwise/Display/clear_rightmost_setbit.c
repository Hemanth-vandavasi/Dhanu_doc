#include <stdio.h>
int clear_rightmost_setbit(unsigned int n);
int main() 
{ 
	unsigned int n; 
	printf("Enter the no:");
	scanf("%d", &n);
	printf("%d\n", clear_rightmost_setbit(n));
	unsigned int res =  clear_rightmost_setbit(n);

	for(int i = 1 << 7; i > 0; i = i / 2) {
		(res & i) ? printf("1") : printf("0");
	}
	
	return 0;
}
int clear_rightmost_setbit(unsigned int n) 
{ 
	int temp = (n ^ 1); 
	return temp;
} 
