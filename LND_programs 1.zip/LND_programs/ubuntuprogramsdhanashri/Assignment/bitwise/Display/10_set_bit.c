#include<stdio.h>
void display(unsigned int);

unsigned int set_bits(unsigned int, unsigned int, unsigned int, unsigned int);

int main()
{
        unsigned int num1;
                unsigned int res;
                unsigned int num2;
                unsigned int pos;
                unsigned int num_n;
        printf("Enter a source number -\n");
        scanf("%d", &num1);
        display(num1);
                printf("Enter a destinaton number -\n");
                scanf("%d", &num2);
                display(num2);
                printf("Enter a  number bits -\n");
                scanf("%d", &num_n);
                printf("Enter a  bit position -\n");
                scanf("%d", &pos);
                res = set_bits(num2, pos, num_n, num1);
                display(res);
        return 0;
}

void display(unsigned int num)
{
        int i = 16;
        while(i) {
                if(num & 0X8000) {
                        printf("1 ");
                } else {
                        printf("0 ");
                }
                num = num << 1;
                i--;
        }
        printf("\n");
}
unsigned int set_bits(unsigned int dnum, unsigned int pos,unsigned int num_n, unsigned int snum)
{
        return dnum & ~(~(~0 << num_n) << (pos+1-num_n)) | ( snum & (~(~0<<num_n)) << (pos+1-num_n));
}
