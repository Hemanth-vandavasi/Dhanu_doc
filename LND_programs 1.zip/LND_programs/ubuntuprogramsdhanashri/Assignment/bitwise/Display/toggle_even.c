#include<stdio.h>

void display(unsigned int);
unsigned int toggle_even_bits( unsigned int );
int main()
{
        unsigned int num1;
        unsigned int res;

        printf("Enter a source number-\n");
        scanf("%d", &num1);
        display(num1);

        printf("Result - Toggle of even positions\n");
        res = toggle_even_bits(num1);
        display(res);


        return 0;
}

void display(unsigned int num)
{
        int i = 8 ;
        while(i) {
                if(num & 0x80) {
                        printf("1 ");
                } else {
                        printf("0 ");
                }
                num = num << 1;
                i--;
        }
        printf("\n");
}

unsigned int toggle_even_bits( unsigned int num)
{
        num = num ^ 0xAAAA;
        return num;
}
