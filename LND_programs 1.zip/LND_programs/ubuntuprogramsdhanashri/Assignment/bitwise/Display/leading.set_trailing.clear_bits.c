#include <stdio.h>
// function declaration
void Display(unsigned int num);
unsigned int count_leading_set_bits(unsigned int num);
unsigned int count_leading_clear_bits(unsigned int num);
unsigned int count_trailing_set_bits(unsigned int num);
unsigned int count_trailing_clear_bits(unsigned int num);
// main function
int main() {
	unsigned int num;
	printf("Enter the number :");
	scanf("%u", &num);
	unsigned int res =  count_leading_set_bits(num);
	unsigned int res1 = count_leading_clear_bits(num);
	unsigned int res2 = count_trailing_set_bits(num);
	unsigned int res3 = count_trailing_clear_bits(num);

	printf("%d\n", count_leading_set_bits(num));
	printf("%d\n", count_leading_clear_bits(num));
	printf("%d\n", count_trailing_set_bits(num));
	printf("%d\n", count_trailing_clear_bits(num));
	return 0;
}

unsigned int count_leading_set_bits(unsigned int num)
{
	int count = 0;
	while (num != 0) {
		num = num >> 1;
		count++;
	}
	return count;
	Display(num);
}
unsigned int count_leading_clear_bits(unsigned int num)
{
	int count = 0;
	while ((num & 1) == 0) {
		num = num >> 1;
		count++;
	}
	return count;
	Display(num);
}
unsigned int count_trailing_set_bits(unsigned int num)
{
	int count = 0;
	while ((num & 1) == 1) {
		num = num >> 1;
		count++;
	}
	return count;
	Display(num);
}
unsigned int count_trailing_clear_bits(unsigned int num)
{
	int count = 0;
	while (num != 0) {
		num = num >> 1;
		count++;
	}
	return count;
	Display(num);
}
void Display(unsigned int num) 
{
	int i =0;
	while(i) {
		if(num & 0x80) {
			printf(" 1");
		} else {
			printf(" 0");
		}
		num = num << 1;
		i--;
	}
}
