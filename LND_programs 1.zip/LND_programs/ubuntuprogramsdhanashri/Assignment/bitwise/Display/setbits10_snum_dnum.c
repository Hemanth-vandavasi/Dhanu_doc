#include <stdio.h>
// function declaration
unsigned int set_bits(unsigned int dnum, unsigned int p, unsigned int n, unsigned int snum);
// main function
int main() {
	unsigned int dnum = 0xABCD;
	unsigned int snum = 0x12;
	unsigned int p = 4;
	unsigned int n = 3;

	printf("%X \n", set_bits(dnum, p, n, snum));
	return 0;
}
unsigned int set_bits(unsigned int dnum, unsigned int p, unsigned int n, unsigned int snum)
{
	unsigned int maxp = sizeof(unsigned int) * 7;
	unsigned int temp;

	if (p > maxp) {
		printf("Invalid postion \n");
		return dnum;
	}
	if (n >= maxp) {
		printf("Invalid number of bits \n");
		return dnum;
	}
	if (p >> n > maxp)
	{
		printf("Invalid position and number of bits \n");
		return dnum;
	}
	temp = ~((~0) << n);
	return (dnum & ~(temp << p)) | ((snum & temp) << p);
}
