#include <stdio.h>
// function declaration
unsigned int left_rotate_bits(unsigned int num, unsigned int n);
unsigned int right_rotate_bits(unsigned int num, unsigned int n);

//main function
int main() {
	unsigned int num;
	unsigned int n;
	printf("Enter the no. :\n");
	scanf("%d", &num);
	printf("Enter the no. of bits to shift :\n");
	scanf("%d", &n);
	for (int i = 1 << 7; i > 0; i = i / 2) {
		(num & i) ? printf("1") : printf("0");
	}
	unsigned int res = left_rotate_bits(num, n);
	unsigned int res1 = right_rotate_bits(num, n);

	printf("After left rotation bits are :%d\n", res);
	for (int i = 1 << 7; i > 0; i = i / 2) {
		(res & i) ? printf("1") : printf("0");
	}
	printf("\n");
	printf("After right rotation bits are :%d\n", res1);
	for (int i = 1 << 7; i > 0; i = i / 2) {
		(res1 & i) ? printf("1") : printf("0");
	}
	printf("\n");
	return 0;
}
//function defination
unsigned int left_rotate_bits(unsigned int num, unsigned int n)
{
	int i;
	/*for (i = 0; i < n; i++) {
		unsigned int first_bit = num & (1 << 8);
		num = num << 1;
		num = num | (first_bit >> 8);
	}*/
	num = (num << n) | (num >> (8 - n));
	return num;
}
unsigned int right_rotate_bits(unsigned int num, unsigned int n)
{
	int i;
/*	for (i = 0; i < n; i++) {
		unsigned int last_bit = num & (1 >> 8);
		num = num >> 1;
		num = num | (last_bit << 8);
	}
	return num;*/
	 return (num >> n) | (num << (8 - n));
}
