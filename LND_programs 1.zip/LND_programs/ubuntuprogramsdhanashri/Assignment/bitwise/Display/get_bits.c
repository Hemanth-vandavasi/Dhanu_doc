#include <stdio.h>

 

#define get_bits(snum, p, n) ((snum >> (p - n + 1)) & (~(~0 << n)))

 

int main()
{
    unsigned int snum, p, n;
    printf("Enter a number: ");
    scanf("%u", &snum);
    printf("Enter the starting position of the field: ");
    scanf("%u", &p);
    printf("Enter the number of bits: ");
    scanf("%u", &n);

 

    printf("The field is: %u\n", get_bits(snum, p, n));

 

    return 0;
}
