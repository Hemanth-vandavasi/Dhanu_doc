#include <stdio.h>
#define MAX(x, y) ((x > y) ? x : y)
// function declaration
int min_no(int num1, int num2);
int max_no(int num1, int num2);
// main function
int main() {
	int num1;
	int num2;

	printf("Enter the num1 :");
	scanf("%d", &num1);
	printf("Enter the num2 :");
	scanf("%d", &num2);

	printf("Minimum of %d and %d is :\n", num1, num2);
	printf("%d\n", min_no(num1, num2));

	printf("Maximum of %d and %d is :\n", num1, num2);
	printf("%d\n", max_no(num1, num2));
	return 0;
}
// Function defination to find minimum of x and y
int min_no(int num1, int num2)
{
	return num2 ^ ((num1 ^ num2) & -(num1 < num2));
}
//function defination to find maximum of x and y
int max_no(int num1, int num2)
{
	return num1 ^ ((num1 ^ num2) & -(num1 < num2));
}
