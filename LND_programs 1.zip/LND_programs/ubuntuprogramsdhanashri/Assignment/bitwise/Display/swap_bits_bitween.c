#include <stdio.h>
// function declaration
int swap_bit_between(unsigned int snum, unsigned int dnum, unsigned int s, unsigned int d);
int binary(unsigned int snum);
int dbinary(unsigned int dnum);
// main function
int main() {
	unsigned int snum;
	unsigned int dnum;
	unsigned int s;
	unsigned int d;
	printf("Enter the source no snum :");
	scanf("%d", &snum);
	printf("Enter the src position to swap :");
	scanf("%d", &s);
	printf("Enter the destination no. :");
	scanf("%d", &dnum);
	printf("Enter the dest position to swap :");
	scanf("%d", &d);

	binary(snum);
	dbinary(dnum);
 	swap_bit_between(snum, dnum, s, d);
	return 0;
}
// function defination
int binary(unsigned int snum)
{
	int i;
	for (i = 0; i < 8; i++) {
		if (snum & 0x80) {
			printf("1");
		}
		else {
			printf("0");
		}
	snum <<= 1;
	}
	printf("\n");
}
int dbinary(unsigned int dnum)
{
	int i;
	for (i = 0; i < 8; i++) {
		if (dnum & 128) {
			printf("1");
		}
		else {
			printf("0");
		}
	dnum <<= 1;
	}
	printf("\n");
}
int swap_bit_between(unsigned int snum, unsigned int dnum, unsigned int s, unsigned int d)
{
	if (((snum & (1 << s))>>s) == ((dnum & (1 << d))>>d)) {
		printf("The swapping is not required");
	}
	else {
		snum ^= (1 << s);
		dnum ^= (1 << d);
		printf("The decimal no. after swapping is : %d %d \n", snum, dnum);
		binary(snum);
		dbinary(dnum);
	}
}
